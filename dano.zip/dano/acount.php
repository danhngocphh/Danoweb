<?php session_start(); 
require './database/DataProvider.php';
$conn = OpenCon();
$current_url = $_SERVER['REQUEST_URI'];
?>


<?php
	// session_start();

	// if (!isset($_SESSION['access_token'])) {
  //   // header('Location: login.php');
	// 	header('Location: ../index.php');
	// 	exit();
	// }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Dano - Website bán đồng hồ</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="robots" content="all,follow" />
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="css/font-awesome.min.css" />
    <!-- Bootstrap Select-->
    <link rel="stylesheet" href="css/bootstrap-select.min.css" />
    <!-- Price Slider Stylesheets -->
    <link rel="stylesheet" href="css/nouislider.css" />
    <!-- Custom font icons-->
    <link rel="stylesheet" href="fonts/custom-fonticons.css" />
    <!-- Google fonts - Poppins-->
    <link rel="stylesheet" href="./fonts/Poppins.css" />
    <!-- owl carousel-->
    <link rel="stylesheet" href="css/owl.carousel.css" />
    <link rel="stylesheet" href="css/owl.theme.default.css" />
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet" />
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css" />
    <!-- Favicon-->
    
    <!-- Modernizr-->
    <script src="js/modernizr.custom.79639.js"></script>
    <!-- Tweaks for older IEs-->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script
    ><![endif]-->
  </head>
  <body>
    <!-- navbar-->
    <header class="header">
      <!-- Tob Bar-->
      <div class="top-bar">
        <div class="container-fluid">
          <div class="row d-flex align-items-center">
            <div class="col-lg-6 hidden-lg-down text-col">
              <ul class="list-inline">
                <li class="list-inline-item">
                  <i class="icon-telephone"></i>0123456789
                </li>
                <li class="list-inline-item">
                  Miễn phí vận chuyển cho đơn hàng từ 500.000 VNĐ
                </li>
              </ul>
            </div>
            <div class="col-lg-6 d-flex justify-content-end">
              <!-- Language Dropdown-->
              
              <!-- Currency Dropdown-->
              <div class="dropdown show">
                <li class="list-inline-item">
                  <?php 
       if (isset($_SESSION['currUser']))
       {
           echo '
            Xin chào <a id="userdetails" href="./acount.php" class="user-link">'.$_SESSION['currUser'].' </a> | ';
           echo '&nbsp<a href="user/logout.php">Đăng xuất</a>';
       }
       else
       {
              if (isset($_SESSION['familyName']))
              {
                  echo 'Xin chào '.$_SESSION['familyName'].'  | ';
                  echo '&nbsp<a href="user/logout.php">Đăng xuất</a>';


                  $username   = $_SESSION['givenName'];
                  $password   = md5($_SESSION['id']);
                  $email      = $_SESSION['email'];
                  $fullname   = $_SESSION['givenName'].' '.$_SESSION['familyName'];
                  $phone      = "";
                  $sex        = $_SESSION['gender'];
                  // $string = $_SESSION['email'];
                  // $pass = md5($_SESSION['id']);
                  // $conn = OpenCon();
                  // $sql2 = mysqli_query ( $conn ,"SELECT * FROM member WHERE email = '$_SESSION['email']'");
                  $sql3 = mysqli_query ( $conn ,"SELECT email FROM member Where email = '$email' ");
                  // echo "<script> alert($sql3) </script>";
                  if (mysqli_num_rows($sql3) == 0)
                  {
                    // echo "<script> alert('dsdsdsdsdsdsd') </script>";
                    $addmember = mysqli_query($conn,"
                    INSERT INTO `member` (`name`, `email`, `phone`, `username`, `password`, `roleuser`, `created`, `lockuser`) VALUES ('{$fullname}', '{$email}', '{$phone}', '{$username}', '{$password}', '2', '0', '0');
                    ");
                  }
                  $sql4 = mysqli_query ( $conn ,"SELECT * FROM member Where email='$email'");
                  $row = mysqli_fetch_assoc($sql4);
                  $_SESSION['currId'] = $row['id'];
                  $_SESSION['User'] = $row['name'];
                  $_SESSION['currUser'] = $row['name'];
                  $_SESSION['currName'] = $row['username'];
                  $_SESSION['Phone'] = $row['phone'];
                  $_SESSION['Add'] = $row['address'];
                  $_SESSION['currEmail'] = $row['email'];
              }
              else
              {
                  echo' <a id="userdetails" href="./user/dangnhap.php" class="user-link"
                  >Đăng nhập</a>   |   <a id="userdetails" href="./user/dangky.php" class="user-link"
                  >Đăng ký</a>';
              }
       }
?>
                </li>
              </div>
            </div>
          </div>
        </div>
      </div>
      <nav class="navbar navbar-expand-lg">
        <div class="search-area">
          <div
            class="search-area-inner d-flex align-items-center justify-content-center"
          >
            <div class="close-btn"><i class="icon-close"></i></div>
            <form action="#">
              <div class="form-group">
                <input
                  type="search"
                  name="search"
                  id="search"
                  placeholder="Nhập tên sản phẩm bạn muốn tìm"
                />
                <button type="submit" class="submit">
                  <i class="icon-search"></i>
                </button>
              </div>
            </form>
          </div>
        </div>
        <div class="container-fluid">
          <!-- Navbar Header  --><a href="index.php" class="navbar-brand"
            ><img src="img/logo.png" alt="..."
          /></a>
          <button
            type="button"
            data-toggle="collapse"
            data-target="#navbarCollapse"
            aria-controls="navbarCollapse"
            aria-expanded="false"
            aria-label="Toggle navigation"
            class="navbar-toggler navbar-toggler-right"
          >
            <i class="fa fa-bars"></i>
          </button>
          <!-- Navbar Collapse -->
          <div id="navbarCollapse" class="collapse navbar-collapse">
            <ul class="navbar-nav mx-auto">
              
              <li class="nav-item">
                <a href="./?catch=men" class="nav-link">đồng hồ nam</a>
              </li>
              <li class="nav-item">
                <a href="./?catch=women" class="nav-link">đồng hồ nữ</a>
              </li>
              <li class="nav-item">
                <a href="./?catch=couple" class="nav-link">đồng hồ đôi</a>
              </li>
              <!-- Megamenu-->
              <li class="nav-item dropdown">
                <a
                  id="navbarDropdownMenuLink"
                  href="./?catch=thuonghieu"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                  class="nav-link"
                  >thương hiệu<i class="fa fa-angle-down"></i
                ></a>
                <ul
                  aria-labelledby="navbarDropdownHomeLink"
                  class="dropdown-menu"
                >

                <?php


                $rowscheck = mysqli_query($conn,"
                SELECT * FROM trademark WHERE hide = 0
                ");

                while ( $row = mysqli_fetch_assoc($rowscheck)) {
                  echo ' 

                  <li>
                    <a href="./?catch=thuonghieu&id='.$row['id'].'" class="dropdown-item">'.$row['name'].'</a>
                  </li>


                  ';
                  # code...
                }

                   
                 

                ?>
                  
                </ul>
              </li>
              
              <!-- Multi level dropdown end-->
              <li class="nav-item">
                <a href="./?catch=contact" class="nav-link">liên hệ</a>
              </li>
            </ul>
            <div
              class="right-col d-flex align-items-lg-center flex-column flex-lg-row"
            >
              <!-- Search Button-->
              <div class="search"><i class="icon-search"></i></div>
              <!-- User Not Logged - link to login page-->
              <div class="user">










               
              </div>
              <!-- Cart Dropdown-->
              <div class="cart dropdown show">
                <a
                  id="cartdetails"
                  href="https://example.com"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                  class="dropdown-toggle"
                  ><i class="icon-cart"></i>
                  <div class="cart-no">
                    <?php 
                        $sl = 0;
                        if (isset($_SESSION["products"]))
                        {
                          // $dem=0;
                          foreach ($_SESSION["products"] as $cart_itm)
                          {
                              $product_id = $cart_itm["id"];
                              $sql1 = "SELECT * FROM product WHERE id IN ('$product_id') LIMIT 1";
                              
                              // $results1 = DataProvider::executeQuery($sql1);

                              // $conn = OpenCon();
                              $results1 = mysqli_query ( $conn ,$sql1);
                              
                              $obj = mysqli_fetch_array($results1);
                              $sl += $cart_itm["qty"]; 
                              // echo $sl;
                          }
                          echo $sl;
                        }
                        // echo $cart_itm["qty"];
                        else
                        echo("0");
                    ?>
                  </div></a
                ><a href="cart.html" class="text-primary view-cart"
                  >View Cart</a
                >
                <div aria-labelledby="cartdetails" class="dropdown-menu">
                  <!-- cart item-->
               <?php 

      if((!isset($_SESSION['currUser'])) && (!isset($_SESSION['familyName'])))
      {
        echo 'Vui lòng đăng nhập ';
      }
      else
      {
            if(isset($_SESSION["products"]))
            // if(1 == 1)
            {
                $current_url = $_SERVER['REQUEST_URI'];
                $total = 0;
              echo '<div class="dropdown-item cart-product">';
                $cart_items = 0;
                foreach ($_SESSION["products"] as $cart_itm)
                {
                  $product_id = $cart_itm["id"];
                  $sql1 = "SELECT * FROM product WHERE id IN ('$product_id') LIMIT 1";
                  
                  // $results1 = DataProvider::executeQuery($sql1);

                  // $conn = OpenCon();
                  $results1 = mysqli_query ( $conn ,$sql1);
                  
                  $obj = mysqli_fetch_array($results1);


                  echo '</br>
                            <div class="d-flex align-items-center">
                              
                              <div class="img">
                                <img
                                  src="images/'.$obj['image'].'"
                                  alt="..."
                                  class="img-fluid"
                                />
                              </div>
                              <div class="details d-flex justify-content-between">
                                <div class="text">
                                  <a href="./?catch=chitiet&chitiet='.$obj['id'].'"><strong>'.$cart_itm["name"].'</strong></a
                                  ><small>Số lượng: '.$cart_itm["qty"].' </small
                                  ><span class="price"> Giá: '.number_format($cart_itm["price"], 0, ',', '.').' đ</span>
                                </div>
                                <a href="cart/cart.php?removep='.$cart_itm["id"].'&return_url='.$current_url.'"  class="delete" onclick="return confirm("Bạn có chắc chắn xóa không ?")"
                                  ><i class="fa fa-trash-o"></i
                                ></a>
                              </div>
                            </div>
                          
                          ';
                          $subtotal = ($cart_itm["price"]*$cart_itm["qty"]);
                          $total = ($total + $subtotal);
              }

              echo '</div>
              <!-- total price-->
                          <div
                            class="dropdown-item total-price d-flex justify-content-between"
                          >
                            <span>Tổng</span
                            ><strong class="text-primary">'.number_format($total, 0, ',', '.').' đ</strong>
                          </div>
                          <!-- call to actions-->
                          <div class="dropdown-item CTA d-flex">
                            <a href="./?catch=cart" class="btn btn-template wide"
                              >Giỏ hàng</a
                            ><a href="./?catch=checkout" class="btn btn-template wide"
                              >Mua hàng</a
                            >
                          </div>';





                    
                  
                
            }else{
                echo 'Giỏ hàng trống';
                
            }
      }
?>
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </nav>
    </header>
    <script>
function confirmDelete(delUrl) {
  if (confirm("Bạn có chắc chắn xóa không ?")) {
    document.location = delUrl;
  }
}
</script>
<!-- <div class="container _2uaMPO">
    <div class="userpage-sidebar">
        <div class="user-page-brief">
            <a class="user-page-brief__avatar" scr="">
                <div class="shopee-avatar">
                    <img src="shopee-avatar__img"/>
                </div>
            </a>
            <div class="user-page-brief__right">
                sds
                <div class="user-page-brief__username">
                    dsd
                </div>
            </div>
        </div>
        <div class="userpage-sidebar-menu">
            <div class="userpage-sidebar-menu-entry userpage-sidebar-menu-entry--highlight">
                <div class="userpage-sidebar-menu-entry__icon">
                        sds
                </div>
            </div>
        </div>
    </div>
    <div class="lm_m-4">
        dsd
    </div>
</div> -->

<div class="container _2uaMPO">
   <div class="userpage-sidebar">
      <div class="user-page-brief">
         <a class="user-page-brief__avatar">
            <div class="shopee-avatar">
               <div class="shopee-avatar__placeholder">
                  <svg class="shopee-svg-icon icon-headshot" enable-background="new 0 0 15 15" viewBox="0 0 15 15" x="0" y="0">
                     <g>
                        <circle cx="7.5" cy="4.5" fill="none" r="3.8" stroke-miterlimit="10"></circle>
                        <path d="m1.5 14.2c0-3.3 2.7-6 6-6s6 2.7 6 6" fill="none" stroke-linecap="round" stroke-miterlimit="10"></path>
                     </g>
                  </svg>
               </div>
               <img class="shopee-avatar__img" src="images/user.png">
            </div>
         </a>
         <div class="user-page-brief__right">
            <div class="user-page-brief__username">
                <?php
                    echo $_SESSION['currUser'];
                ?>
            </div>
            <!-- <div>
               <a class="user-page-brief__edit" href="/user/account/profile/">
                  <svg width="12" height="12" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg" style="margin-right: 4px;">
                     <path d="M8.54 0L6.987 1.56l3.46 3.48L12 3.48M0 8.52l.073 3.428L3.46 12l6.21-6.18-3.46-3.48" fill="#9B9B9B" fill-rule="evenodd"></path>
                  </svg>
                  Sửa hồ sơ
               </a>
            </div> -->
         </div>
      </div>
      <div class="userpage-sidebar-menu">
         <div class="stardust-dropdown">
            <div class="stardust-dropdown__item-header">
               <a class="userpage-sidebar-menu-entry" href="">
                  <!-- <div class="userpage-sidebar-menu-entry__icon" style="background-color: rgb(255, 193, 7);">
                     <svg class="shopee-svg-icon user-page-sidebar-icon icon-headshot" enable-background="new 0 0 15 15" viewBox="0 0 15 15" x="0" y="0">
                        <g>
                           <circle cx="7.5" cy="4.5" fill="none" r="3.8" stroke-miterlimit="10"></circle>
                           <path d="m1.5 14.2c0-3.3 2.7-6 6-6s6 2.7 6 6" fill="none" stroke-linecap="round" stroke-miterlimit="10"></path>
                        </g>
                     </svg>
                  </div> -->
                  <!-- <div class="userpage-sidebar-menu-entry__text">Tài khoản của tôi</div> -->
               </a>
            </div>
            <!-- <div class="stardust-dropdown__item-body" style="opacity: 0;">
               <div class="userpage-sidebar-menu__subsection"><a class="_17BcjA" href="/user/account/profile"><span class="_2ilxaJ">Hồ sơ</span></a><a class="_17BcjA" href="/user/account/payment"><span class="_2ilxaJ">Ngân hàng</span></a><a class="_17BcjA" href="/user/account/address"><span class="_2ilxaJ">Địa chỉ</span></a><a class="_17BcjA" href="/user/account/password"><span class="_2ilxaJ">Thêm mật khẩu</span></a></div>
            </div> -->
         </div>
         <a class="userpage-sidebar-menu-entry userpage-sidebar-menu-entry--highlight" href="">
            <!-- <div class="userpage-sidebar-menu-entry__icon" style="background-color: rgb(68, 181, 255);">
               <svg class="shopee-svg-icon user-page-sidebar-icon " enable-background="new 0 0 15 15" viewBox="0 0 15 15" x="0" y="0" style="fill: rgb(255, 255, 255);">
                  <g>
                     <rect fill="none" height="10" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" width="8" x="4.5" y="1.5"></rect>
                     <polyline fill="none" points="2.5 1.5 2.5 13.5 12.5 13.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10"></polyline>
                     <line fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="6.5" x2="10.5" y1="4" y2="4"></line>
                     <line fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="6.5" x2="10.5" y1="6.5" y2="6.5"></line>
                     <line fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="6.5" x2="10.5" y1="9" y2="9"></line>
                  </g>
               </svg>
            </div> -->
            <!-- <div class="userpage-sidebar-menu-entry__text">Đơn Mua</div> -->
         </a>
         <div class="stardust-dropdown">
            <div class="stardust-dropdown__item-header">
               <!-- <a class="userpage-sidebar-menu-entry" href="/user/notifications/">
                  <div class="userpage-sidebar-menu-entry__icon" style="background-color: rgb(238, 77, 45);">
                     <svg class="shopee-svg-icon user-page-sidebar-icon " enable-background="new 0 0 15 15" viewBox="0 0 15 15" x="0" y="0">
                        <g>
                           <path d="m12 10.2 1.5 2h-12l1.5-2v-7.4c0-.5.5-1 1-1h7c .6 0 1 .5 1 1z" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10"></path>
                           <path d="m6 2c0-.8.7-1.5 1.5-1.5s1.5.7 1.5 1.5" fill="none" stroke-miterlimit="10"></path>
                           <path d="m5.8 13.5c.4.6 1 1 1.8 1s1.4-.4 1.8-1z"></path>
                        </g>
                     </svg>
                  </div>
                  <div class="userpage-sidebar-menu-entry__text">Thông báo</div>
               </a> -->
            </div>
            <!-- <div class="stardust-dropdown__item-body">
               <div class="userpage-sidebar-menu__subsection"><a class="_17BcjA" href="/user/notifications/order"><span class="_2ilxaJ">Cập nhật đơn hàng</span></a><a class="_17BcjA" href="/user/notifications/promotion"><span class="_2ilxaJ">Khuyến mãi</span></a><a class="_17BcjA" href="/user/notifications/activity"><span class="_2ilxaJ">Hoạt động</span></a><a class="_17BcjA" href="/user/notifications/flashsale"><span class="_2ilxaJ">Flash Sale của Shop</span></a><a class="_17BcjA" href="/user/notifications/ads"><span class="_2ilxaJ">Đấu Thầu Từ Khóa</span></a><a class="_17BcjA" href="/user/notifications/wallet"><span class="_2ilxaJ">Cập nhật Ví</span></a><a class="_17BcjA" href="/user/notifications/shopee"><span class="_2ilxaJ">Cập nhật Shopee</span></a></div>
            </div> -->
         </div>
         <!-- <a class="userpage-sidebar-menu-entry" href="/user/voucher-wallet/">
            <div class="userpage-sidebar-menu-entry__icon" style="background-color: rgb(255, 119, 97);">
               <svg class="shopee-svg-icon user-page-sidebar-icon voucher-wallet-icon icon-voucher" height="11" viewBox="0 0 12 11" width="12">
                  <g fill="none" fill-rule="evenodd" transform=F
                     <path d="m1.24401059 7.40822892c-.18616985.27925478-.2855145.60736785-.2855145.94299033v.69678422c0 .33137085.26862915.6.6.6h8.88300781c.3313709 0 .6-.26862915.6-.6v-7.6515625c0-.33137085-.2686291-.6-.6-.6h-8.88300781c-.33137085 0-.6.26862915-.6.6v.69678422c0 .33562248.09934465.66373556.2855145.94299034l.52041449.78062172c.2774581.41618716.42551633.90519026.42551633 1.40538497 0 .50019472-.14805823.98919781-.42551633 1.40538497z" stroke="#fff"></path>
                     <path d="m5.64815848 3.46301463h3.69433594v.85253907h-3.69433594zm0 1.53930664h3.69433594v.85253907h-3.69433594zm0 1.53930664h3.69433594v.85253907h-3.69433594zm-2.02308873-3.07861328h.85253907v.85253907h-.85253907zm0 1.53930664h.85253907v.85253907h-.85253907zm0 1.53930664h.85253907v.85253907h-.85253907z" fill="#fff"></path>
                  </g>
               </svg>
            </div>
            <div class="userpage-sidebar-menu-entry__text">Ví Voucher</div>
         </a> -->
         <!-- <a class="userpage-sidebar-menu-entry" href="/user/coin/">
            <div class="userpage-sidebar-menu-entry__icon" style="background-color: rgb(255, 174, 4);">
               <svg class="shopee-svg-icon user-page-sidebar-icon " enable-background="new 0 0 15 15" viewBox="0 0 15 15" x="0" y="0">
                  <path d="m7.5 1c3.6 0 6.5 2.9 6.5 6.5s-2.9 6.5-6.5 6.5-6.5-2.9-6.5-6.5 2.9-6.5 6.5-6.5m0-1c-4.1 0-7.5 3.4-7.5 7.5s3.4 7.5 7.5 7.5 7.5-3.4 7.5-7.5-3.4-7.5-7.5-7.5z" stroke="none"></path>
                  <path d="m9.7 3.7c-1.2-.8-2.9-1-4-.1-1.2 1-1.1 2.5 0 3.4.8.6 1.7.7 2.6 1.2 1.2.7 1.7 2.2 0 2.7-1.1.3-2.2-.1-3.1-.8-.5-.4-1 .5-.5.9 1.2.8 2.7 1.3 4.1.8 1.2-.4 2-1.7 1.5-2.9-.4-1.1-1.7-1.6-2.7-2-.4-.1-.7-.2-1-.5-1.2-.9-.6-2.4.9-2.4.6 0 1.2.2 1.7.6.5.3 1-.5.5-.9z" stroke="none"></path>
               </svg>
            </div>
            <div class="userpage-sidebar-menu-entry__text">Shopee Xu</div>
         </a> -->
      </div>
   </div>
   <div class="lm_m-4">
      <div class="purchase-list-page__wrapper" role="main">
         <div class="purchase-list-page__tabs-container">
            <div class="purchase-list-page__tab purchase-list-page__tab--selected"><span class="purchase-list-page__tab-label"><h5>Thông tin các đơn hàng</h3></span></div>
            <!-- <div class="purchase-list-page__tab purchase-list-page__tab--selected"><span class="purchase-list-page__tab-label"></span></div>
            <div class="purchase-list-page__tab purchase-list-page__tab--selected"><span class="purchase-list-page__tab-label"></span></div>
            <div class="purchase-list-page__tab purchase-list-page__tab--selected"><span class="purchase-list-page__tab-label"></span></div>
            <div class="purchase-list-page__tab purchase-list-page__tab--selected"><span class="purchase-list-page__tab-label"></span></div> -->
         </div>
         <!-- <div class="purchase-list-page__search-bar">
            <svg width="19px" height="19px" viewBox="0 0 19 19">
               <g id="Search-New" stroke-width="1" fill="none" fill-rule="evenodd">
                  <g id="my-purchase-copy-27" transform="translate(-399.000000, -221.000000)" stroke-width="2">
                     <g id="Group-32" transform="translate(400.000000, 222.000000)">
                        <circle id="Oval-27" cx="7" cy="7" r="7"></circle>
                        <path d="M12,12 L16.9799555,16.919354" id="Path-184" stroke-linecap="round" stroke-linejoin="round"></path>
                     </g>
                  </g>
               </g>
            </svg>
            <input autocomplete="off" placeholder="Tìm kiếm theo Tên Shop, ID đơn hàng hoặc Tên Sản phẩm" value="">
         </div> -->
         <div class="purchase-list-page__empty-page-wrapper">
            <?php
                $conn = OpenCon();
                // echo $_SESSION['currUser'];
                $id_user = $_SESSION['currId'];
                $sql = mysqli_query ( $conn ,"SELECT * FROM detail_order Where user_id = '$id_user' ORDER BY id DESC");
                if (mysqli_num_rows($sql) != 0)
                {

                    echo '<div class="basket">
                                    <div class="basket-holder">
                                        <div class="basket-header">
                                            <div class="row">
                                                <div class="col-5">Sản phẩm</div>
                                                <div class="col-3">Tổng tiền</div>
                                                <div class="col-4">tình trạng đơn hàng</div>
                                                
                                            </div>
                                        </div>';
                    while ($row = mysqli_fetch_assoc($sql))
                    {
                        $product_name = $row['product_name'];
                        $sql1 = mysqli_query ( $conn ,"SELECT * FROM product Where name = '$product_name'");
                        while ($row1 = mysqli_fetch_assoc($sql1))
                        {
                            $image = $row1['image'];
                        }
                        echo '
                        
                                
                                        <div class="basket-body">
                                        <!-- Product-->
                                        <div class="item">
                                            <div class="row d-flex align-items-center">
                                                <div class="col-5">
                                                    <div class="d-flex align-items-center">
                                                    Mã đơn hàng: '.$row['transaction_id'].'&emsp;&emsp;<br>
                                                    <img
                                                        src="images/'.$image.'"
                                                        alt="..."
                                                        class="img-fluid"
                                                        />
                                                    <div class="title">
                                                        <a href="./?catch=chitiet&chitiet='.$row['product_id'].'">
                                                            <h6></h6>
                                                        </a
                                                            >
                                                    </div>
                                                    </div>
                                                </div>
                                                <div class="col-3"><span>'.number_format($row['amount'], 0, ',', '.').' vnd</span></div>
                                                <div class="col-4"> 
                                                    <span>';
                                                    if ($row['status'] == '3')
                                                    {
                                                        echo 'Đang xử lý &emsp;&emsp;&emsp;   <img src="images/xuly.png"/>';
                                                    }
                                                    if ($row['status'] == '2')
                                                    {
                                                        echo 'Đang giao &emsp;&emsp;&emsp;   <img src="images/giaohang.png"/>';
                                                    }
                                                    if ($row['status'] == '1')
                                                    {
                                                        echo 'Đã thanh toán&emsp;&emsp;&emsp;   <img src="images/thanhtoan.png"/>';
                                                    }
                                                    if ($row['status'] == '0')
                                                    {
                                                        echo 'Đã hủy &emsp;&emsp;&emsp;&emsp;&emsp;   <img src="images/huy.jpg"/>';
                                                    }
                                            echo'   </span>
                                                </div>
                                            </div>
                                        </div>
                                        </div>
                                    ';
                        // echo 'Mã đơn hàng: '.$row['transaction_id'].'<br>';
                        // echo 'Tên đơn hàng: '.$row['product_name'];
                        // $product_name = $row['product_name'];
                        // $sql1 = mysqli_query ( $conn ,"SELECT * FROM product Where name = '$product_name'");
                        // while ($row1 = mysqli_fetch_assoc($sql1))
                        // {
                        //     $image = $row1['image'];
                        // }
                        // // echo $image;
                        // echo '<img src="images/'.$image.'"/>';
                        // echo 'Đơn giá: '.$row['amount'];
                        // echo 'Tình trang đơn hàng: ';
                        // if ($row['status'] == '3')
                        // {
                        //     echo 'Đơn hàng đang được xử lý';
                        // }
                        // if ($row['status'] == '2')
                        // {
                        //     echo 'Đơn hàng đang được giao';
                        // }
                        // if ($row['status'] == '1')
                        // {
                        //     echo 'Đơn hàng đã được thanh toán';
                        // }
                        // if ($row['status'] == '0')
                        // {
                        //     echo 'Đơn hàng đã được hủy';
                        // }
                        // $row['']
                    }
                    echo '</div>
                    </div>';
                }
                else
                {
                    echo '
                    <div class="purchase-empty-order__container">
                    <div class="purchase-empty-order__icon"><img src="images/buon.jpg"/> </div>
                    <div class="purchase-empty-order__text"> Chưa có đơn hàng </div>
                    </div>';
                }
            ?>
            <?php
                // echo '
                // <section class="shopping-cart">
                //     <div class="container">
                //         <div class="basket">
                //             <div class="basket-holder">
                //                 <div class="basket-header">
                //                 <div class="row">
                //                     <div class="col-5">Sản phẩm</div>
                //                     <div class="col-2">Giá</div>
                //                     <div class="col-2">Số lượng</div>
                //                     <div class="col-2">Tổng tiền</div>
                //                     <div class="col-1 text-center">Xóa</div>
                //                 </div>
                //                 </div>
                //                 <div class="basket-body">
                //                 <!-- Product-->
                //                 <div class="item">
                //                     <div class="row d-flex align-items-center">
                //                         <div class="col-5">
                //                             <div class="d-flex align-items-center">
                //                             <img
                //                                 src="images/'.$image.'"
                //                                 alt="..."
                //                                 class="img-fluid"
                //                                 />
                //                             <div class="title">
                //                                 <a href="?catch=chitiet&chitiet='.$row['product_id'].'">
                //                                     <h6></h6>
                //                                 </a
                //                                     >
                //                             </div>
                //                             </div>
                //                         </div>
                //                         <div class="col-2"><span></span></div>
                //                         <div class="col-2"> <span>&emsp;&emsp;&emsp;&emsp;</span>
                //                         </div>
                //                         <div class="col-2"><span></span></div>
                //                         <div class="col-1 text-center">
                //                             <i class="delete fa fa-trash"></i>
                //                         </div>
                //                     </div>
                //                 </div>
                //                 </div>
                //             </div>
                //         </div>
                //     </div>
                // </section>';
            ?>
            <!-- <div class="purchase-empty-order__container">
               <div class="purchase-empty-order__icon"> </div>
               <div class="purchase-empty-order__text"> Chưa có đơn hàng </div>
            </div> -->
         </div>
         <div></div>
      </div>
   </div>
</div>
<style>
._2uaMPO {
    display: -webkit-box;
    display: -webkit-flex;
    /* display: -moz-box;
    display: -ms-flexbox; */
    display: flex;
    padding: 1.25rem 0 3.125rem;
}
.userpage-sidebar {
    display: block;
    width: 180px;
    -webkit-flex-shrink: 0;
    /* -ms-flex-negative: 0; */
    flex-shrink: 0;
}
.user-page-brief {
    display: -webkit-box;
    display: -webkit-flex;
    /* display: -moz-box;
    display: -ms-flexbox; */
    display: flex;
    padding: 15px 0;
    border-bottom: 1px solid #efefef;
}
.user-page-brief__right {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    /* -moz-box-flex: 1;
    -ms-flex: 1; */
    flex: 1;
    display: -webkit-box;
    display: -webkit-flex;
    /* display: -moz-box;
    display: -ms-flexbox; */
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    /* -moz-box-orient: vertical;
    -moz-box-direction: normal;
    -ms-flex-direction: column; */
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    /* -moz-box-pack: center;
    -ms-flex-pack: center; */
    justify-content: center;
    padding-left: 15px;
    overflow: hidden;
}
.user-page-brief__username {
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    font-weight: 600;
    margin-bottom: 5px;
    color: #333;
}
.user-page-brief__edit {
    color: #888;
    text-transform: capitalize;
    text-decoration: none;
}
.userpage-sidebar-menu {
    list-style: none;
    padding: 0;
    margin: 27px 0 0;
    cursor: pointer;
}
.lm_m-4 {
    position: relative;
    -webkit-box-flex: 1;
    -webkit-flex-grow: 1;
    /* -moz-box-flex: 1;
    -ms-flex-positive: 1; */
    flex-grow: 1;
    /* width: 980px; */
    /* -moz-box-sizing: border-box; */
    box-sizing: border-box;
    margin-left: 1.6875rem;
    min-width: 0;
    max-width: 1000px;
    background: #fff;
    box-shadow: 0 1px 2px 0 rgba(0,0,0,.13);
    border-radius: .125rem;
}
.purchase-list-page__wrapper {
    background-color: #f5f5f5;
    box-shadow: 0 0 0 1px #f5f5f5;
}
.purchase-list-page__tab, .purchase-list-page__tabs-container {
    overflow: hidden;
    display: -webkit-box;
    display: -webkit-flex;
    /* display: -moz-box;
    display: -ms-flexbox; */
    display: flex;
}
.purchase-list-page__search-bar {
    display: -webkit-box;
    display: -webkit-flex;
    /* display: -moz-box;
    display: -ms-flexbox; */
    display: flex;
    background: #eaeaea;
    padding: .75rem 0;
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.05);
    border-radius: 2px;
    color: #555;
}
.purchase-list-page__empty-page-wrapper {
    width: 100%;
    height: 37.5rem;
    margin-top: .75rem;
}
.purchase-list-page__tab--selected {
    color: #9055a2;
    border-bottom: 2px solid #9055a2;
}
.purchase-list-page__tab {
    cursor: pointer;
    -webkit-user-select: none;
    /* -moz-user-select: none;
    -ms-user-select: none; */
    user-select: none;
    font-size: 1rem;
    line-height: 1.1875rem;
    padding: 1rem 0;
    color: rgba(0,0,0,.8);
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    /* -moz-box-flex: 1;
    -ms-flex: 1; */
    flex: 1;
    -webkit-box-align: center;
    -webkit-align-items: center;
    /* -moz-box-align: center;
    -ms-flex-align: center; */
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    /* -moz-box-pack: center;
    -ms-flex-pack: center; */
    justify-content: center;
}
.purchase-empty-order__text {
    color: #9055a2;
    font-size: 1rem;
    line-height: 1.0625rem;
}
.purchase-empty-order__container {
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.05);
    border-radius: .125rem;
    overflow: hidden;
    background: #fff;
    width: 100%;
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: -moz-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    /* -moz-box-orient: vertical;
    -moz-box-direction: normal;
    -ms-flex-direction: column; */
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    /* -moz-box-pack: center;
    -ms-flex-pack: center; */
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    /* -moz-box-align: center;
    -ms-flex-align: center; */
    align-items: center;
}
</style>