


<?php if (! isset($_GET['catch']))
    {
        include('action/search.php');
        
        
    } else {    
        $page = $_GET['catch'];  
        switch($page)
        {
            case 'men':
               include('action/men.php');
                break;  
            case 'women':
                include('action/women.php');
                break; 
            case 'couple':
                include('action/couple.php');
                break; 
            case 'user':
                include('user/index.php');
                break;            
            case 'chitiet':
                include('action/detail.php');
                break; 
             case 'contact':
                include('action/contact.php');
                break; 
            case 'searchnc':
                include('action/searchnc.php');
                break; 
            case 'cart':
                include('action/cart.php');
                break; 
            case 'checkout':
                include('action/checkout.php');
                break; 
            case 'thuonghieu':
                include('action/thuonghieu.php');
                break; 
            

                    }
    }
?>

