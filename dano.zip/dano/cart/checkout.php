<?php
require '../database/DataProvider.php';

session_start();
$conn = OpenCon();


?>


 <?php 

     
   //  if(isset($_SESSION["products"]))
   //  {
        
        
   //     echo '<div class="dropdown-item cart-product">';
       
   //      foreach ($_SESSION["products"] as $cart_itm)
   //      {
   //         $product_id = $cart_itm["id"];
   //         $sql1 = "SELECT * FROM product WHERE id IN ('$product_id') LIMIT 1";
   //       //   $results1 = DataProvider::executeQuery($sql1);

   //         $results1 = mysqli_query ( $conn ,"$sql1");

     
   //         $obj = mysqli_fetch_array($results1);

   //         $tam = $obj['total'] - $cart_itm["qty"];

   //         $sql2 = "UPDATE product SET view='$tam'  WHERE id IN ('$product_id')";	
   //         $results2 = mysqli_query($conn,"$sql2");
   //       // $results2 = DataProvider::executeQuery($sql2);


   //       }
   //   }
  ?>





<?php

         
         $id = $_SESSION['currId'];
         $total = $_SESSION["total"];
         $email = $_SESSION["currEmail"];

         $hoten = $_POST['first-name'];
         $sdt = $_POST['sdt'];
         $diachi = $_POST['diachi'];
         $hinhthuc = $_POST['hinhthuc'];
         $ghichu = $_POST['ghichu'];



         $today = date("Y/m/d");
        

         $sql1 = "UPDATE member SET name='$hoten', phone='$sdt', address='$diachi' WHERE id IN ('$id')";
         // echo $id;
         $results1 = mysqli_query($conn, $sql1);
         // $quan = $_GET['quan'];
         // $phuong = $_GET['phuong'];
         // $duong = $_GET['duong'];
         // $hinhthuc = $_GET['hinhthuc'];
         // $total = $_SESSION["total"];


         // $sql1 = "UPDATE ttgiaohang SET hoten='$hoten', sdt='$sdt', thanhpho='$thanhpho', quan='$quan', phuong='$phuong', duong='$duong' WHERE username IN ('$username')";	

         // $addmember = mysqli_query($conn,"");
         $query = "INSERT INTO `transaction` (`status`, `user_id`, `user_name`, `user_email`, `user_phone`, `amount`, `payment`, `payment_info`, `message`, `created`) VALUES ('0','{$id}','{$hoten}','{$email}','{$sdt}','{$total}','{$hinhthuc}','','{$ghichu}','{$today}')";
         
         $results2 = mysqli_query($conn, $query);

         $query = "

         SELECT
         *
      FROM transaction
      WHERE 1


         ";
         
         $results2 = mysqli_query($conn, $query);

         while ($row = mysqli_fetch_array($results2)) {

                     $transaction_id = $row['id'];

            # code...
         }

         





         if(isset($_SESSION["products"]))
       {
        
        
      
       
        foreach ($_SESSION["products"] as $cart_itm)
        {



           $product_id = $cart_itm["id"];
           $product_name=$cart_itm["name"];
           $qty=$cart_itm["qty"];
           $amount=$cart_itm["price"];
            $user_id = $_SESSION['currId'];



           $query = "INSERT INTO `detail_order` (`transaction_id`, `product_id`, `product_name`, `qty`, `amount`, `status`, `user_id`) VALUES ('{$transaction_id}','{$product_id}','{$product_name}','{$qty}','{$amount}','3','{$user_id}')";
         
         $results3 = mysqli_query($conn, $query);



           
          

         }
     }






         //         //echo $query;
         //         DataProvider::executeQuery($query);

?>

<
<?php

// $results1 = DataProvider::executeQuery($sql1);
// echo "Dano - Website bán đồng hồ</br></br>";     
// echo "Thanh toán thành công</br>";

// echo "</br>Họ và tên: ".$hoten;
// echo "</br>Số điện thoại: ".$sdt;
// echo "</br>Tỉnh/Thành phố: ".$thanhpho;
// echo "</br>Quận/Huyện: ".$quan;
// echo "</br>Phường/ Xã: ".$phuong;
// echo "</br>Tòa nhà/ Tên đường: ".$duong;
// echo "</br>Phương thức thanh toán: ".$hinhthuc;
// echo "</br>Tổng tiền: ".$total;echo " đ";
?>
<?php 

      
   //  if(isset($_SESSION["products"]))
   //  {
        
      
        
   //      foreach ($_SESSION["products"] as $cart_itm)
   //      {
   //         $product_id = $cart_itm["id"];
   //         $sql1 = "SELECT * FROM dongho WHERE madh IN ('$product_id') LIMIT 1";
   //         $results1 = DataProvider::executeQuery($sql1);
     
   //         $obj = mysql_fetch_array($results1);

   //         echo "</br>Sản phẩm: ".$cart_itm["name"];
   //      }
   //  }

?>
<?php

 header("Location: ../acount.php" );







?>