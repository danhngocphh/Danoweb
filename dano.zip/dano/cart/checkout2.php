<?php
require '../database/DataProvider.php';
session_start();



?>


 <?php 

     
    if(isset($_SESSION["products"]))
    {
        
        
       echo '<div class="dropdown-item cart-product">';
       
        foreach ($_SESSION["products"] as $cart_itm)
        {
           $product_id = $cart_itm["id"];
           $sql1 = "SELECT * FROM dongho WHERE madh IN ('$product_id') LIMIT 1";
           $results1 = DataProvider::executeQuery($sql1);
     
           $obj = mysql_fetch_array($results1);

           $tam = $obj['soluong'] - $cart_itm["qty"];

           $sql2 = "UPDATE dongho SET soluong='$tam'  WHERE madh IN ('$product_id')";	
			$results2 = DataProvider::executeQuery($sql2);

         }
     }
  ?>





<?php


$username = $_SESSION['currUser'];
$hoten = $_GET['first-name'];
$sdt = $_GET['sdt'];
$thanhpho = $_GET['thanhpho'];
$quan = $_GET['quan'];
$phuong = $_GET['phuong'];
$duong = $_GET['duong'];
$hinhthuc = $_GET['hinhthuc'];
$total = $_SESSION["total"];

$kko = "INSERT INTO `dano`.`ttgiaohang` (`username`,`hoten`, `sdt`, `thanhpho`, `quan`, `phuong`, `duong`) VALUES ('{$username}','{$hoten}','{$sdt}','{$thanhpho}','{$quan}','{$phuong}','{$duong}')";




$query = "INSERT INTO `dano`.`hoadon` (`hoten`, `sdt`, `thanhpho`, `quan`, `phuong`, `duong`, `phuongthuc`, `tongtien`) VALUES ('{$hoten}','{$sdt}','{$thanhpho}','{$quan}','{$phuong}','{$duong}','{$hinhthuc}','{$total}')";
        //echo $query;
        DataProvider::executeQuery($query);

?>



<?php

$results1 = DataProvider::executeQuery($sql1);
$re = DataProvider::executeQuery($kko);
echo "Dano - Website bán đồng hồ</br></br>";     
echo "Thanh toán thành công</br>";

echo "</br>Họ và tên: ".$hoten;
echo "</br>Số điện thoại: ".$sdt;
echo "</br>Tỉnh/Thành phố: ".$thanhpho;
echo "</br>Quận/Huyện: ".$quan;
echo "</br>Phường/ Xã: ".$phuong;
echo "</br>Tòa nhà/ Tên đường: ".$duong;
echo "</br>Phương thức thanh toán: ".$hinhthuc;
echo "</br>Tổng tiền: ".$total;echo " đ";
?>
<?php 

      
    if(isset($_SESSION["products"]))
    {
        
      
        
        foreach ($_SESSION["products"] as $cart_itm)
        {
           $product_id = $cart_itm["id"];
           $sql1 = "SELECT * FROM dongho WHERE madh IN ('$product_id') LIMIT 1";
           $results1 = DataProvider::executeQuery($sql1);
     
           $obj = mysql_fetch_array($results1);

           echo "</br>Sản phẩm: ".$cart_itm["name"];
        }
    }

?>
<?php

echo '</br>';
echo '</br>';
echo '<a href="cart.php?emptycart=1&return_url=../index.php" class="btn btn-template wide">Về trang chủ</a>';




?>