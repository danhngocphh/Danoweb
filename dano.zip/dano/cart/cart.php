<?php
session_start(); //Bắt đầu session
require '../database/DataProvider.php'; //include config file
 if(!isset($_SESSION['currUser']) && (!isset($_SESSION['familyName'])))
      {
        // $return_url   = $_GET["return_url"]; 
        // echo "Bạn phải đăng nhập để tiếp tục</br>";
        // echo '<a href="../user/dangnhap.php" class="btn btn-template wide shop-now"
        //           >Đăng nhập<i class="icon-bag"> </i
        //         ></a>&nbsp;'; 
        // echo '<a href="'.$return_url.'" class="btn btn-template wide shop-now"
        //           >Trở về<i class="icon-bag"> </i
        //         ></a>';
        echo "<script> alert('Tài khoản này của bạn đã bị khóa') </script>";
        header ('location: ../user/dangnhap.php');
      }
      else
      {
//Xóa giỏ hàng bằng cách hủy SESSION
if(isset($_GET["emptycart"]) && $_GET["emptycart"]==1)
{
    $return_url = $_GET["return_url"]; //return url
    unset($_SESSION['products']);

    header('Location:'.$return_url);
}
 
//Thêm sản phẩm vào giỏ hàng
if(isset($_GET["type"]) && $_GET["type"]=='add')
{
    $product_id   = $_GET["product_id"]; //product id
    $product_qty  = $_GET["product_qty"]; //số lượng
    $return_url   = $_GET["return_url"]; // url trả về
    
    //Giới hạn sản phẩm
    if($product_qty > 10){
        die('<div align="center">Ví dụ này không quá 10 sản phẩm</div>');
    }
 
    //Lấy thông tin chi tiết sản phẩm bằng product_id
    $sql1 = "SELECT * FROM product WHERE id IN ('$product_id') LIMIT 1";
    // $results1 = DataProvider::executeQuery($sql1);
    $conn = OpenCon();
    $result1 = mysqli_query ( $conn ,$sql1);
     
    $obj = mysqli_fetch_array($result1);

    
    if ($result1) { //Kiểm tra có dữ liệu hay không
        
        //Chuẩn bị array(mảng) để lưu thông tin sản phẩm 
        $new_product = array(array('name'=>$obj["name"], 'id'=>$product_id, 'qty'=>$product_qty, 'price'=>$obj["price"], 'image'=>$obj["image"]));
        
        if(isset($_SESSION["products"])) //Hàm kiểm tra nếu có sản phẩm trong giỏ hàng rồi thì cập nhật lại
        {

            $found = false; //Thiết lập mặc định ban đầu biến kiểm tra sản phẩm tồn tại thành false
            
            foreach ($_SESSION["products"] as $cart_itm) //vòng lặp mảng SESSION 
            {
                if($cart_itm["id"] == $product_id){ //sản phẩm đã tồn tại trong mảng
 
                    $product[] = array('name'=>$cart_itm["name"], 'id'=>$cart_itm["id"], 'qty'=>$cart_itm["qty"]+1, 'price'=>$cart_itm["price"],'image'=>$cart_itm["image"]);

                    $found = true; // Thiết lập biến kiểm tra sản phẩm tồn tại thành true
                }else{
                    //item doesn't exist in the list, just retrive old info and prepare array for session var
                    $product[] = array('name'=>$cart_itm["name"], 'id'=>$cart_itm["id"], 'qty'=>$cart_itm["qty"], 'price'=>$cart_itm["price"],'image'=>$cart_itm["image"]);
                }
            }
            
            if($found == false) //Không tìm thấy sản phẩm trong giỏ hàng
            {
                //Thêm mới sản phẩm vào mảng
                $_SESSION["products"] = array_merge($product, $new_product);
            }else{
                //Tìm thấy sản phẩm đã có trong mảng SESSION nên chỉ cập nhật lại số lượng(QTY)
                $_SESSION["products"] = $product;
            }
            
        }else{
            //Tạo biến SESSION mới hoàn toàn nếu không có sản phẩm nào trong giỏ hàng
            $_SESSION["products"] = $new_product;
        }
        header('Location:'.$return_url);
    }
    
    //Trở về lại trang cũ
    header('Location:'.$return_url);
    
}
 
//Xóa sản phẩm trong giỏ hàng
if(isset($_GET["removep"]) && isset($_GET["return_url"]) && isset($_SESSION["products"]))
{
    $product_id   = $_GET["removep"]; //Lấy product_id để xóa
    $return_url   = $_GET["return_url"]; //lấy url hiện tại
 
    
    foreach ($_SESSION["products"] as $cart_itm) //Vòng lặp biến SESSION
    {
        if($cart_itm["id"]!=$product_id){ //Lọc lại giỏ hàng, sản phẩm nào trùng product_id muốn xóa sẽ bị loại bỏ
            $product[] = array('name'=>$cart_itm["name"], 'id'=>$cart_itm["id"], 'qty'=>$cart_itm["qty"], 'price'=>$cart_itm["price"],'image'=>$cart_itm["image"]);
        }
        
        //Tạo mới biến SESSION lưu giỏ hàng
        $_SESSION["products"] = $product;
    }
    
    //Trở về lại trang cũ
    header('Location:'.$return_url);
}


}
?>