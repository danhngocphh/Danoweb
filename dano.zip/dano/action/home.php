<?php 

echo '
<!-- Hero Section-->
    <section class="hero hero-home no-padding">
      <!-- Hero Slider-->
      <div class="owl-carousel owl-theme hero-slider">
        <div
          style="background: url(img/hero-bg.jpg);"
          class="item d-flex align-items-center has-pattern"
        >
          
        </div>
        <div
          style="background: url(img/hero-bg-2.jpg);"
          class="item d-flex align-items-center"
        >
          
        </div>
        <div
          style="background: url(img/hero-bg-3.jpg);"
          class="item d-flex align-items-center"
        >
          <div class="container">
            <div class="row">
              <div class="col-lg-6 text-white">
                <h1></br></br>Buy watches</h1>
                <p class="lead">The smart choice of men
                  
                </p>
                <a href="?catch=men" class="btn btn-template wide shop-now"
                  >Shop Now<i class="icon-bag"> </i
                ></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>';
?>

<?php

$current_url = base64_encode($_SERVER['REQUEST_URI']);//return url

$sql = "SELECT * FROM product WHERE catalog_id IN ('1')";


$result = mysqli_query ($conn, $sql);  


//tieu de  nam<!-- Men's Collection -->
echo '
    <section class="men-collection gray-bg">
      <div class="container">
        <header class="text-center">
          <h2 class="text-uppercase">
            <small>danh mục</small>';echo "đồng hồ nam";
          echo'</h2>
        </header>
        <!-- Products Slider-->
        <div class="owl-carousel owl-theme products-slider">';    
// <!-- item-->   
        
        
    
$current_url = $_SERVER['REQUEST_URI'];

for ($i=0; $i < 7 ; $i++)  {
    

         $row = mysqli_fetch_assoc($result);

        
        
        
        
        echo '<div class="item">
            <div class="product is-gray">
              <div
                class="image d-flex align-items-center justify-content-center"
              >
                <img
                  src="images/'.$row["image"].'"
                  alt="product"
                  class="img-fluid"
                />
                <div
                  class="hover-overlay d-flex align-items-center justify-content-center"
                >
                  <div
                    class="CTA d-flex align-items-center justify-content-center"
                  >
                    <a href="cart/cart.php?type=add&product_id='.$row["id"].'&product_qty=1&return_url='.$current_url.'" class="add-to-cart"
                      ><i class="fa fa-shopping-cart"></i></a
                    ><a href="?catch=chitiet&chitiet='.$row["id"].'" class="visit-product active" 
                      ><i class="icon-search"></i>Chi tiết</a
                    >
                  </div>
                </div>
              </div>
              <div class="title">
                <a href="?catch=chitiet&chitiet='.$row["id"].'">
                  <h3 class="h6 text-uppercase no-margin-bottom">
                    '.$row["name"].'
                  </h3></a
                ><span class="price abc">'.number_format($row["price"], 0, ',', '.').'₫</span>
              </div>
            </div>
          </div>';
         
        }

  echo "</div>
      </div>
    </section>";
        
       
   
   



?>

<?php


$sql = "SELECT * FROM product WHERE catalog_id IN ('2')";


$result = mysqli_query ($conn, $sql);  


//tieu de  nam<!-- Men's Collection -->
echo '
    <section class="women-collection">
      <div class="container">
        <header class="text-center">
          <h2 class="text-uppercase">
            <small>danh mục</small>';echo "đồng hồ nữ";
          echo'</h2>
        </header>
        <!-- Products Slider-->
        <div class="owl-carousel owl-theme products-slider">';    
// <!-- item-->   
        
        
    

for ($i=0; $i < 7 ; $i++)  {
    

         $row = mysqli_fetch_assoc($result);

        
        
        
        
        echo '<div class="item">
            <div class="product is-gray">
              <div
                class="image d-flex align-items-center justify-content-center"
              >
                <img
                  src="images/'.$row["image"].'"
                  alt="product"
                  class="img-fluid"
                />
                <div
                  class="hover-overlay d-flex align-items-center justify-content-center"
                >
                  <div
                    class="CTA d-flex align-items-center justify-content-center"
                  >
                    <a href="cart/cart.php?type=add&product_id='.$row["id"].'&product_qty=1&return_url='.$current_url.'" class="add-to-cart"
                      ><i class="fa fa-shopping-cart"></i></a
                    ><a href="?catch=chitiet&chitiet='.$row["id"].'" class="visit-product active"
                      ><i class="icon-search"></i>Chi tiết</a
                    >
                  </div>
                </div>
              </div>
              <div class="title">
                <a href="?catch=chitiet&chitiet='.$row["id"].'">
                  <h3 class="h6 text-uppercase no-margin-bottom">
                    '.$row["name"].'
                  </h3></a
                ><span class="price abc">'.number_format($row["price"], 0, ',', '.').'₫</span>
              </div>
            </div>
          </div>';
         
        }

  echo "</div>
      </div>
    </section>";
        
       
   
   



?>

<?php


$sql = "SELECT * FROM product WHERE catalog_id IN ('3')";


$result = mysqli_query ($conn, $sql);  

//tieu de  nam<!-- Men's Collection -->
echo '
    <section class="men-collection gray-bg">
      <div class="container">
        <header class="text-center">
          <h2 class="text-uppercase">
            <small>danh mục</small>';echo "đồng hồ đôi";
          echo'</h2>
        </header>
        <!-- Products Slider-->
        <div class="owl-carousel owl-theme products-slider">';    
// <!-- item-->   
        
        
    

for ($i=0; $i < 6 ; $i++)  {
    

         $row = mysqli_fetch_assoc($result);

        
        
        
        
        echo '<div class="item">
            <div class="product is-gray">
              <div
                class="image d-flex align-items-center justify-content-center"
              >
                <img
                  src="images/'.$row["image"].'"
                  alt="product"
                  class="img-fluid"
                />
                <div
                  class="hover-overlay d-flex align-items-center justify-content-center"
                >
                  <div
                    class="CTA d-flex align-items-center justify-content-center"
                  >
                    <a href="cart/cart.php?type=add&product_id='.$row["id"].'&product_qty=1&return_url='.$current_url.'" class="add-to-cart"
                      ><i class="fa fa-shopping-cart"></i></a
                    ><a href="?catch=chitiet&chitiet='.$row["id"].'" class="visit-product active"
                      ><i class="icon-search"></i>Chi tiết</a
                    >
                  </div>
                </div>
              </div>
              <div class="title">
                <a href="?catch=chitiet&chitiet='.$row["id"].'">
                  <h3 class="h6 text-uppercase no-margin-bottom">
                    '.$row["name"].'
                  </h3></a
                ><span class="price abc">'.number_format($row["price"], 0, ',', '.').'₫</span>
              </div>
            </div>
          </div>';
         
        }

  echo "</div>
      </div>
    </section>";
        
       
   
   



?>

<style>
  .abc {
    font-weight: bold;
    color: #9055a2;
}
</style>