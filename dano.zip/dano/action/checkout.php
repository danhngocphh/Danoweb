<? session_start(); ?>
<!-- Hero Section-->
    <section class="hero hero-page gray-bg padding-small">
      <div class="container">
        <div class="row d-flex">
          <div class="col-lg-9 order-2 order-lg-1">
            <h1>Mua hàng</h1>
            <p class="lead"></p>
          </div>
          <div class="col-lg-3 text-right order-1 order-lg-2">
            <ul class="breadcrumb justify-content-lg-end">
              <li class="breadcrumb-item"><a href="index.php">Trang chủ</a></li>
              <li class="breadcrumb-item active">Mua hàng</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <!-- Checkout Forms-->
    <section class="checkout">
      <div class="container">
        <div class="row">
          <div class="col-lg-8">
            
            

                  <?php
                  $vga = 0;
                  $conn = OpenCon();
                  if(isset($_SESSION['currUser']))
      {
        $username = $_SESSION['currUser'];
        $id = $_SESSION['currId'];
        // echo $id;

      } 
      if (isset($_SESSION['familyName']))
      {
        $id = $_SESSION['currId'];
        // echo $id;
      }


      $sql2 = "SELECT * FROM member WHERE id = '$id'";
      $result1 = mysqli_query ( $conn ,$sql2);
			if(mysqli_num_rows($result1) == 1)
			{
					
          // $row = mysqli_fetch_assoc($sql2);
          while ($row = mysqli_fetch_array($result1))

            {
              
              echo '<div class="tab-content">
              <div id="address" class="active tab-block">
                 <form action="cart/checkout.php" method="POST"> 
                  <!-- Invoice Address-->
                  <div class="block-header mb-5">
                    <h5>ĐỊA CHỈ NHẬN HÀNG</h5>
                  </div>
             

                  <div class="row">
                    <div class="form-group col-md-6">
                      <label for="firstname" class="form-label"
                        >Họ và tên</label
                      >
                      <input
                        id="hoten"
                        required=""
                        type="text"
                        name="first-name"
                        placeholder=""
                        class="form-control"
                        value="'.$row['name'].'"
                      />
                    </div>
                    <div class="form-group col-md-6">
                      <label for="lastname" class="form-label">Số điện thoại</label>
                      <input
                        id="sdt"
                        required=""
                        type="num"
                        pattern="[0-9]{10,11}"
                        name="sdt"
                        placeholder=""
                        class="form-control"
                        value="'.$row['phone'].'"
                      />
                    </div>
                    <div class="form-group col-md-8">
                      <label for="email" class="form-label"
                        >Địa chỉ</label
                      >
                      <input
                        id="diachi"
                        required=""
                        type="text"
                        name="diachi"
                        placeholder=""
                        class="form-control"
                        value="'.$row['address'].'"
                      />
                    </div>
                    <div class="form-group col-md-8">
                      <label for="email" class="form-label"
                        >Ghi chú</label
                      >
                      <input
                        id="ghichu"
                        type="text"
                        name="ghichu"
                        placeholder=""
                        class="form-control"
                        value=""
                      />
                    </div>
                    
                    <div class="form-group col-md-6">
                      <label for="company" class="form-label">Hình thức thanh toán: </label>
                      <select name="hinhthuc">
                      <option value="Tiền mặt">Tiền mặt</option>
                      <option value="Trực tuyến">Trực tuyến</option>
      
                      </select>
                    </div>
                    </div>
                  <!-- /Shipping Address-->
                  <div
                    class="CTAs d-flex justify-content-between flex-column flex-lg-row"
                  >
                    <a
                      href="?catch=cart"
                      class="btn btn-template-outlined wide prev"
                    >
                      <i class="fa fa-angle-left"></i>Quay lại giỏ hàng</a
                    >
                    <button class="btn btn-template wide next" type="submit" value="Mua hàng" name="mua">Mua hàng<i class="fa fa-angle-right"></i
                    ></button> 


                    
                  </div>
                      </form>
                    </div>
                  </div>
                </div>';
                
              }
      }
      else
      {

        echo '<div class="tab-content">
              <div id="address" class="active tab-block">
                 <form action="cart/checkout2.php" method="GET"> 
                  <!-- Invoice Address-->
                  <div class="block-header mb-5">
                    <h5>ĐỊA CHỈ NHẬN HÀNG</h5>
                  </div>
             

                  <div class="row">
                    <div class="form-group col-md-6">
                      <label for="firstname" class="form-label"
                        >Họ và tên</label
                      >
                      <input
                        id="hoten"
                        type="text"
                        name="first-name"
                        placeholder=""
                        class="form-control"
                        value=""
                      />
                    </div>
                    <div class="form-group col-md-6">
                      <label for="lastname" class="form-label">Số điện thoại</label>
                      <input
                        id="sdt"
                        type="tel"
                        name="sdt"
                        placeholder=""
                        class="form-control"
                        value=""
                      />
                    </div>
                    <div class="form-group col-md-6">
                      <label for="email" class="form-label"
                        >Tỉnh/Thành phố</label
                      >
                      <input
                        id="thanhpho"
                        type="text"
                        name="thanhpho"
                        placeholder=""
                        class="form-control"
                        value=""
                      />
                    </div>
                    <div class="form-group col-md-6">
                      <label for="street" class="form-label">Quận/Huyện</label>
                      <input
                        id="quan"
                        type="text"
                        name="quan"
                        placeholder=""
                        class="form-control"
                        value=""
                      />
                    </div>
                    
                    
                    <div class="form-group col-md-6">
                      <label for="phone-number" class="form-label"
                        >Phường/ Xã</label
                      >
                      <input
                        id="phuong"
                        type="text"
                        name="phuong"
                        placeholder=""
                        class="form-control"
                        value=""
                      />
                    </div>
                    <div class="form-group col-md-6">
                      <label for="company" class="form-label">Tòa nhà/ Tên đường</label>
                      <input
                        id="duong"
                        type="text"
                        name="duong"
                        placeholder=""
                        class="form-control"
                        value=""
                      />
                    </div>
                    <div class="form-group col-md-6">
                      <label for="company" class="form-label">Hình thức thanh toán: </label>
                      <select name="hinhthuc">
                      <option value="truc tuyen">Trực tuyến</option>
                      <option value="tien mat">Tiền mặt</option>
      
                      </select>
                    </div>
                    </div>
                  <!-- /Shipping Address-->
                  <div
                    class="CTAs d-flex justify-content-between flex-column flex-lg-row"
                  >
                    <a
                      href="?catch=cart"
                      class="btn btn-template-outlined wide prev"
                    >
                      <i class="fa fa-angle-left"></i>Quay lại giỏ hàng</a
                    >
                    <button class="btn btn-template wide next" type="submit" value="Mua hàng" name="mua">Mua hàng<i class="fa fa-angle-right"></i
                    ></button> 


                    
                  </div>
                </form>
              </div>
            </div>
          </div>';
      }



      // $sql = mysqli_query ( $conn ,"SELECT * FROM transaction WHERE user_name = '$username'");
			// if(mysqli_num_rows($sql) == 1)
			// {}
                  // $sql1 = "SELECT * FROM ttgiaohang WHERE username IN ('$username') LIMIT 1";
        //           $sql1 = "SELECT * FROM transaction WHERE user_name IN ('$username') LIMIT 1";
        //           $result1 = mysqli_query ( $conn ,$sql1);
        // // $result1 = DataProvider::executeQuery($sql1);      
        // while ($row = mysqli_fetch_array($result1))

        //     {
              
        //       echo '<div class="tab-content">
        //       <div id="address" class="active tab-block">
        //          <form action="cart/checkout.php" method="GET"> 
        //           <!-- Invoice Address-->
        //           <div class="block-header mb-5">
        //             <h5>ĐỊA CHỈ NHẬN HÀNG</h5>
        //           </div>
             

        //           <div class="row">
        //             <div class="form-group col-md-6">
        //               <label for="firstname" class="form-label"
        //                 >Họ và tênn</label
        //               >
        //               <input
        //                 id="hoten"
        //                 type="text"
        //                 name="first-name"
        //                 placeholder=""
        //                 class="form-control"
        //                 value="'.$row['hoten'].'"
        //               />
        //             </div>
        //             <div class="form-group col-md-6">
        //               <label for="lastname" class="form-label">Số điện thoại</label>
        //               <input
        //                 id="sdt"
        //                 type="tel"
        //                 name="sdt"
        //                 placeholder=""
        //                 class="form-control"
        //                 value="'.$row['sdt'].'"
        //               />
        //             </div>
        //             <div class="form-group col-md-6">
        //               <label for="email" class="form-label"
        //                 >Tỉnh/Thành phố</label
        //               >
        //               <input
        //                 id="thanhpho"
        //                 type="text"
        //                 name="thanhpho"
        //                 placeholder=""
        //                 class="form-control"
        //                 value="'.$row['thanhpho'].'"
        //               />
        //             </div>
        //             <div class="form-group col-md-6">
        //               <label for="street" class="form-label">Quận/Huyện</label>
        //               <input
        //                 id="quan"
        //                 type="text"
        //                 name="quan"
        //                 placeholder=""
        //                 class="form-control"
        //                 value="'.$row['quan'].'"
        //               />
        //             </div>
                    
                    
        //             <div class="form-group col-md-6">
        //               <label for="phone-number" class="form-label"
        //                 >Phường/ Xã</label
        //               >
        //               <input
        //                 id="phuong"
        //                 type="text"
        //                 name="phuong"
        //                 placeholder=""
        //                 class="form-control"
        //                 value="'.$row['phuong'].'"
        //               />
        //             </div>
        //             <div class="form-group col-md-6">
        //               <label for="company" class="form-label">Tòa nhà/ Tên đường</label>
        //               <input
        //                 id="duong"
        //                 type="text"
        //                 name="duong"
        //                 placeholder=""
        //                 class="form-control"
        //                 value="'.$row['duong'].'"
        //               />
        //             </div>
        //             <div class="form-group col-md-6">
        //               <label for="company" class="form-label">Hình thức thanh toán: </label>
        //               <select name="hinhthuc">
        //               <option value="truc tuyen">Trực tuyến</option>
        //               <option value="tien mat">Tiền mặt</option>
      
        //               </select>
        //             </div>
        //             </div>
        //           <!-- /Shipping Address-->
        //           <div
        //             class="CTAs d-flex justify-content-between flex-column flex-lg-row"
        //           >
        //             <a
        //               href="?catch=cart"
        //               class="btn btn-template-outlined wide prev"
        //             >
        //               <i class="fa fa-angle-left"></i>Quay lại giỏ hàng</a
        //             >
        //             <button class="btn btn-template wide next" type="submit" value="Mua hàng" name="mua">Mua hàng<i class="fa fa-angle-right"></i
        //             ></button> 


                    
        //           </div>
        //         </form>
        //       </div>
        //     </div>
        //   </div>';
        //   $vga = 1;
        // }
        // if ( $vga == 1 ) {}
        //   else{
        //    echo '<div class="tab-content">
        //       <div id="address" class="active tab-block">
        //          <form action="cart/checkout2.php" method="GET"> 
        //           <!-- Invoice Address-->
        //           <div class="block-header mb-5">
        //             <h5>ĐỊA CHỈ NHẬN HÀNG</h5>
        //           </div>
             

        //           <div class="row">
        //             <div class="form-group col-md-6">
        //               <label for="firstname" class="form-label"
        //                 >Họ và tên</label
        //               >
        //               <input
        //                 id="hoten"
        //                 type="text"
        //                 name="first-name"
        //                 placeholder=""
        //                 class="form-control"
        //                 value=""
        //               />
        //             </div>
        //             <div class="form-group col-md-6">
        //               <label for="lastname" class="form-label">Số điện thoại</label>
        //               <input
        //                 id="sdt"
        //                 type="tel"
        //                 name="sdt"
        //                 placeholder=""
        //                 class="form-control"
        //                 value=""
        //               />
        //             </div>
        //             <div class="form-group col-md-6">
        //               <label for="email" class="form-label"
        //                 >Tỉnh/Thành phố</label
        //               >
        //               <input
        //                 id="thanhpho"
        //                 type="text"
        //                 name="thanhpho"
        //                 placeholder=""
        //                 class="form-control"
        //                 value=""
        //               />
        //             </div>
        //             <div class="form-group col-md-6">
        //               <label for="street" class="form-label">Quận/Huyện</label>
        //               <input
        //                 id="quan"
        //                 type="text"
        //                 name="quan"
        //                 placeholder=""
        //                 class="form-control"
        //                 value=""
        //               />
        //             </div>
                    
                    
        //             <div class="form-group col-md-6">
        //               <label for="phone-number" class="form-label"
        //                 >Phường/ Xã</label
        //               >
        //               <input
        //                 id="phuong"
        //                 type="text"
        //                 name="phuong"
        //                 placeholder=""
        //                 class="form-control"
        //                 value=""
        //               />
        //             </div>
        //             <div class="form-group col-md-6">
        //               <label for="company" class="form-label">Tòa nhà/ Tên đường</label>
        //               <input
        //                 id="duong"
        //                 type="text"
        //                 name="duong"
        //                 placeholder=""
        //                 class="form-control"
        //                 value=""
        //               />
        //             </div>
        //             <div class="form-group col-md-6">
        //               <label for="company" class="form-label">Hình thức thanh toán: </label>
        //               <select name="hinhthuc">
        //               <option value="truc tuyen">Trực tuyến</option>
        //               <option value="tien mat">Tiền mặt</option>
      
        //               </select>
        //             </div>
        //             </div>
        //           <!-- /Shipping Address-->
        //           <div
        //             class="CTAs d-flex justify-content-between flex-column flex-lg-row"
        //           >
        //             <a
        //               href="?catch=cart"
        //               class="btn btn-template-outlined wide prev"
        //             >
        //               <i class="fa fa-angle-left"></i>Quay lại giỏ hàng</a
        //             >
        //             <button class="btn btn-template wide next" type="submit" value="Mua hàng" name="mua">Mua hàng<i class="fa fa-angle-right"></i
        //             ></button> 


                    
        //           </div>
        //         </form>
        //       </div>
        //     </div>
        //   </div>';



        // }
      
        ?>
     
            
      
    <?php 

      
    if(isset($_SESSION["products"]))
    {
        $current_url = $_SERVER['REQUEST_URI'];
        $total = 0;
      
        $cart_items = 0;
        foreach ($_SESSION["products"] as $cart_itm)
        {
           $product_id = $cart_itm["id"];
          //  $sql1 = "SELECT * FROM dongho WHERE madh IN ('$product_id') LIMIT 1";
           $sql1 = "SELECT * FROM product WHERE id IN ('$product_id') LIMIT 1";

           $results1 = mysqli_query($conn,$sql1);
          //  $results1 = DataProvider::executeQuery($sql1);
     
           $obj = mysqli_fetch_array($results1);

           $subtotal = ($cart_itm["price"]*$cart_itm["qty"]);
          $total = ($total + $subtotal);
        }



echo '
          <div class="col-lg-4">
            <div class="block-body order-summary">
              <h6 class="text-uppercase">Thông tin đơn hàng</h6>
              <p>
                
              </p>
              <ul class="order-menu list-unstyled">
                <li class="d-flex justify-content-between">
                  <span>Giá sản phẩm </span><strong>'.number_format($total, 0, ',', '.').' đ</strong>
                </li>
                <li class="d-flex justify-content-between">
                  <span>Phí vận chuyển</span><strong>0 đ</strong>
                </li>
                <li class="d-flex justify-content-between">
                  <span>Khuyến mãi</span><strong>-0 đ</strong>
                </li>
                <li class="d-flex justify-content-between">
                  <span>Tổng tiền</span
                  ><strong class="text-primary price-total">'.number_format($total, 0, ',', '.').' đ</strong>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>';
  }
  $_SESSION["total"] = $total;
  ?>