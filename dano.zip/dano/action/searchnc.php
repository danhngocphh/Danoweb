<?php require_once 'Paginationnc.php'; ?>
<?php 
require '../database/DataProvider.php';
$conn = OpenCon();




?>

<?php session_start(); 

$current_url = $_SERVER['REQUEST_URI'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Dano - Website bán đồng hồ</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="robots" content="all,follow" />
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="../css/bootstrap.min.css" />
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="../css/font-awesome.min.css" />
    <!-- Bootstrap Select-->
    <link rel="stylesheet" href="../css/bootstrap-select.min.css" />
    <!-- Price Slider Stylesheets -->
    <link rel="stylesheet" href="../css/nouislider.css" />
    <!-- Custom font icons-->
    <link rel="stylesheet" href="../fonts/custom-fonticons.css" />
    <!-- Google fonts - Poppins-->
    <link rel="stylesheet" href="../fonts/Poppins.css" />
    <!-- owl carousel-->
    <link rel="stylesheet" href="../css/owl.carousel.css" />
    <link rel="stylesheet" href="../css/owl.theme.default.css" />
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="../css/style.default.css" id="theme-stylesheet" />
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="../css/custom.css" />
    <!-- Favicon-->
    
    <!-- Modernizr-->
    <script src="../js/modernizr.custom.79639.js"></script>

  </head>
  <body>
    <!-- navbar-->
    <header class="header">
      <!-- Tob Bar-->
      <div class="top-bar">
        <div class="container-fluid">
          <div class="row d-flex align-items-center">
            <div class="col-lg-6 hidden-lg-down text-col">
              <ul class="list-inline">
                <li class="list-inline-item">
                  <i class="icon-telephone"></i>0123456789
                </li>
                <li class="list-inline-item">
                  Miễn phí vận chuyển cho đơn hàng từ 500.000 VNĐ
                </li>
              </ul>
            </div>
            <div class="col-lg-6 d-flex justify-content-end">
              <!-- Language Dropdown-->

              <!-- Currency Dropdown-->
              <div class="dropdown show">
                <li class="list-inline-item">
                  <?php 
                  if (isset($_SESSION['currUser']) && $_SESSION['currUser']){
                   echo 'Xin chào '.$_SESSION['currUser'].'  | ';
                   echo '&nbsp<a href="user/logout.php">Đăng xuất</a>';
                 }
                 else{
                   echo' <a id="userdetails" href="./user/dangnhap.php" class="user-link"
                   >Đăng nhập</a>   |   <a id="userdetails" href="./user/dangky.php" class="user-link"
                   >Đăng ký</a>';
                 }
                 ?>
               </li>
             </div>
           </div>
         </div>
       </div>
     </div>
     <nav class="navbar navbar-expand-lg">
      <div class="search-area">
        <div
        class="search-area-inner d-flex align-items-center justify-content-center"
        >
        <div class="close-btn"><i class="icon-close"></i></div>
        <form action="#">
          <div class="form-group">
            <input
            type="search"
            name="search"
            id="search"
            placeholder="Nhập tên sản phẩm bạn muốn tìm"
            />
            <button type="submit" class="submit">
              <i class="icon-search"></i>
            </button>
          </div>
        </form>
      </div>
    </div>
    <div class="container-fluid">
      <!-- Navbar Header  --><a href="../index.php" class="navbar-brand"
      ><img src="../img/logo.png" alt="..."
      /></a>
      <button
      type="button"
      data-toggle="collapse"
      data-target="#navbarCollapse"
      aria-controls="navbarCollapse"
      aria-expanded="false"
      aria-label="Toggle navigation"
      class="navbar-toggler navbar-toggler-right"
      >
      <i class="fa fa-bars"></i>
    </button>
    <!-- Navbar Collapse -->
    <div id="navbarCollapse" class="collapse navbar-collapse">
      <ul class="navbar-nav mx-auto">

        <li class="nav-item">
          <a href="?catch=men" class="nav-link">đồng hồ nam</a>
        </li>
        <li class="nav-item">
          <a href="?catch=women" class="nav-link">đồng hồ nữ</a>
        </li>
        <li class="nav-item">
          <a href="?catch=couple" class="nav-link">đồng hồ đôi</a>
        </li>
        <!-- Megamenu-->

        <!-- Multi level dropdown end-->
        <li class="nav-item">
          <a href="?catch=contact" class="nav-link">liên hệ</a>
        </li>
      </ul>
      <div
      class="right-col d-flex align-items-lg-center flex-column flex-lg-row"
      >
      <!-- Search Button-->
      <div class="search"><i class="icon-search"></i></div>
      <!-- User Not Logged - link to login page-->
      <div class="user">











      </div>
      <!-- Cart Dropdown-->
      <div class="cart dropdown show">
        <a
        id="cartdetails"
        href="#"
        data-toggle="dropdown"
        aria-haspopup="true"
        aria-expanded="false"
        class="dropdown-toggle"
        ><i class="icon-cart"></i>
        <div class="cart-no">1</div></a
        ><a href="cart.html" class="text-primary view-cart"
        >View Cart</a
        >
        <div aria-labelledby="cartdetails" class="dropdown-menu">
          <!-- cart item-->
          <?php 

          if(!isset($_SESSION['currUser']))
          {
            echo 'Vui lòng đăng nhập ';
          }
          else
          {
            if(isset($_SESSION["products"]))
            {
              $current_url = $_SERVER['REQUEST_URI'];
              $total = 0;
              echo '<div class="dropdown-item cart-product">';
              $cart_items = 0;
              foreach ($_SESSION["products"] as $cart_itm)
              {
               $product_id = $cart_itm["id"];
               $sql1 = "SELECT * FROM product WHERE id IN ('$product_id') LIMIT 1";

               $result2 = mysqli_query ( $conn , $sql1);
               $obj = mysqli_fetch_assoc($result2);
               $rowcount=mysqli_num_rows($result2);
               echo $rowcount;


               echo '</br>
               <div class="d-flex align-items-center">

               <div class="img">
               <img
               src="images/'.$obj['image'].'"
               alt="..."
               class="img-fluid"
               />
               </div>
               <div class="details d-flex justify-content-between">
               <div class="text">
               <a href="?catch=chitiet&chitiet='.$obj['id'].'"><strong>'.$cart_itm["name"].'</strong></a
               ><small>Số lượng: '.$cart_itm["qty"].' </small
               ><span class="price"> Giá: '.$cart_itm["price"].' đ</span>
               </div>
               <a href="cart/cart.php?removep='.$cart_itm["id"].'&return_url='.$current_url.'" class="delete"
               ><i class="fa fa-trash-o"></i
               ></a>
               </div>
               </div>

               ';
               $subtotal = ($cart_itm["price"]*$cart_itm["qty"]);
               $total = ($total + $subtotal);
             }

             echo '</div>
             <!-- total price-->
             <div
             class="dropdown-item total-price d-flex justify-content-between"
             >
             <span>Tổng</span
             ><strong class="text-primary">'.$total.' đ</strong>
             </div>
             <!-- call to actions-->
             <div class="dropdown-item CTA d-flex">
             <a href="?catch=cart" class="btn btn-template wide"
             >Giỏ hàng</a
             ><a href="?catch=checkout" class="btn btn-template wide"
             >Mua hàng</a
             >
             </div>';








           }else{
            echo 'Giỏ hàng trống';
          }
        }
        ?>

      </div>
    </div>
  </div>
</div>
</div>
</nav>
</header>

<?php



?>
<?php if (! isset($_GET['searchByName']))
{



} else 



{    
  $page = $_GET['searchByName'];  
  $min = $_GET['searchByPriceFrom'];  
  $max = $_GET['searchByPriceTo'];
  $catalog = $_GET['catalog'];   
  echo'<!-- Hero Section-->
  <section class="hero hero-page gray-bg padding-small">
  <div class="container">
  <div class="row d-flex">
  <div class="col-lg-9 order-2 order-lg-1">
  <h1>TÌM KIẾM NÂNG CAO</h1>
  <p class="lead text-muted">

  </p>
  </div>
  <div class="col-lg-3 text-right order-1 order-lg-2">
  <ul class="breadcrumb justify-content-lg-end">
  <li class="breadcrumb-item"><a href="../index.php">Trang chủ</a></li>
  <li class="breadcrumb-item active">TÌM KIẾM NÂNG CAO</li>
  </ul>
  </div>
  </div>
  </div>
  </section>
  <main>
  <div class="container">
  <div class="row">
  <!-- Sidebar-->
  <div class="sidebar col-xl-3 col-lg-4 sidebar">

  <div class="block">
  <h6 class="text-uppercase">Tìm kiếm nâng cao</h6>
  <div id="slider-snap"></div>
  <form  class="jsx-1387603744 search-form" ><div class="jsx-1387603744"><div class="jss190"><label class="jss205 jss194 jss199 jss202" data-shrink="false">Tìm theo tên:</label><div class="jss225 jss212 jss216 jss226 jss213"><input name="searchByName" class="jss235 jss220" aria-invalid="false" type="text" value="'.$page.'"></div></br></div><div class="jss190"><label class="jss205 jss194 jss199 jss202" data-shrink="false">Chọn loại đồng hồ:</label><div class="jss225 jss212 jss216 jss226 jss213"><select name= "catalog" >
  <option value="1">&nbsp;&nbsp;&nbsp;Đồng hồ nam</option>
  <option value="2">&nbsp;&nbsp;&nbsp;Đồng hồ nữ</option>   
  <option value="3">&nbsp;&nbsp;&nbsp;Đồng hồ đôi</option>                                               

  </select></br></br></div></div></div><div class="jsx-1387603744"><div class="jsx-1387603744">Tìm theo giá:</div><div class="jss190" style="width: 100px;"><label class="jss205 jss209 jss194 jss199 jss202 jss201" data-shrink="true">Từ</label><div class="jss225 jss212 jss216 jss226 jss213"><input onkeypress=" return isNumberKey(event)" name="searchByPriceFrom" id="min" class="jss235 jss220" aria-invalid="false" type="text" value="'.$min.'"></div></div><div class="jss190" style="width: 100px;"><label class="jss205 jss209 jss194 jss199 jss202 jss201" data-shrink="true">Đến</label><div class="jss225 jss212 jss216 jss226 jss213"><input onkeypress=" return isNumberKey(event)" name="searchByPriceTo" id="max" class="jss235 jss220" aria-invalid="false" type="text" value="'.$max.'"></div></div></div></br><button tabindex="0" class="jss27 jss1 jss12 jss13 jss15 jss16" type="submit"><span class="jss2">Tìm kiếm</span><span class="jss253"></span></button>






  </form>

  </div>


  </div>
  <div class="products-grid col-xl-9 col-lg-8 sidebar-left">
  ';
  if($_GET['searchByPriceFrom'] == '')
  {
    $min = 0;
  }
  if($_GET['searchByPriceTo'] == '')
  {
    $max = 1000000000000;
  }


        // BƯỚC 2: TÌM TỔNG SỐ RECORDS
  $sql2 = "SELECT count(id) as totall from product WHERE name LIKE '%$page%' AND price >= $min AND price <= $max AND catalog_id IN ('$catalog')";

  $result2 = mysqli_query($conn ,$sql2);

  $row2 = mysqli_fetch_assoc($result2);


  $total_records = $row2['totall'];



        // BƯỚC 3: TÌM LIMIT VÀ CURRENT_PAGE
  $current_page = isset($_GET['trang']) ? $_GET['trang'] : 1;
  $limit = 9;


        // BƯỚC 4: TÍNH TOÁN TOTAL_PAGE VÀ START
        // tổng số trang

  $total_page = ceil($total_records / $limit);

        // Giới hạn current_page trong khoảng 1 đến total_page
  if ($current_page > $total_page){
    $current_page = $total_page;
  }
  else if ($current_page < 1){
    $current_page = 1;
  }

        // Tìm Start
  $start = ($current_page - 1) * $limit;



        // BƯỚC 5: TRUY VẤN LẤY DANH SÁCH TIN TỨC
        // Có limit và start rồi thì truy vấn CSDL lấy danh sách tin tức

  echo '<header class="d-flex justify-content-between align-items-start">
  <span class="visible-items"
  >Kết quả tìm được <strong>'.$total_records.'</strong> sản phẩm.</span
  >

  </header><div class="row">';
  if ($total_records == 0)
  {

  }
  else{

    $sql3 = "SELECT * FROM product WHERE price >= $min AND price <= $max AND name LIKE N'%$page%' AND catalog_id IN ('$catalog') LIMIT $start, $limit  ";

    $result3 = mysqli_query($conn ,$sql3);


    while ($row = mysqli_fetch_assoc($result3))

    {

      {

        echo '<div class="item col-xl-4 col-md-6">
        <div class="product is-gray">
        <div
        class="image d-flex align-items-center justify-content-center"
        >

        <img
        src="images/'.$row["image"].'"
        alt="product"
        class="img-fluid"
        />
        <div
        class="hover-overlay d-flex align-items-center justify-content-center"
        >
        <div
        class="CTA d-flex align-items-center justify-content-center"
        >
        <a href="../?catch=chitiet&chitiet='.$row["id"].'" class="visit-product active"
        ><i class="icon-search"></i>Chi tiết</a
        >
        </div>
        </div>
        </div>
        <div class="title">
        <small class="text-muted">Đồng hồ</small
        ><a href="detail.html">
        <h3 class="h6 text-uppercase no-margin-bottom">
        '.$row["name"].'
        </h3></a
        ><span class="price text-muted">'.$row["price"].'₫</span>
        </div>
        </div>
        </div>';


        

      }
    }






  }

  echo '</div>';
  $config = [
    'total' => $total_records, 
    'limit' => $limit,
    'full' => true,
    'querystring' => 'trang'
  ];
  $page = new Pagination($config);
  echo $page->getPagination();
  echo "</div>";

  echo "
  </div></div>
  </main>";
  $page = null;   
}
?>


<?php 
include "../widget/footer.php";
?>

<body>


  <!-- JavaScript files-->
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/jquery.cookie.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/owl.carousel2.thumbs.min.js"></script>
  <script src="js/bootstrap-select.min.js"></script>
  <script src="js/nouislider.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/masonry.pkgd.min.js"></script>
  <script src="js/imagesloaded.pkgd.min.js"></script>
  <!-- masonry -->
  <script>
    $(function() {
      var $grid = $('.masonry-wrapper').masonry({
        itemSelector: '.item',
        columnWidth: '.item',
        percentPosition: true,
        transitionDuration: 0
      });

      $grid.imagesLoaded().progress(function() {
        $grid.masonry();
      });
    });
  </script>
  <!-- Main Template File-->
  <script src="js/front.js"></script>
</body>


</html>