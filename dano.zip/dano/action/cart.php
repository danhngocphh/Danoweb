



<!-- Hero Section-->
    <section class="hero hero-page gray-bg padding-small">
      <div class="container">
        <div class="row d-flex">
          <div class="col-lg-9 order-2 order-lg-1">
            <h1>Giỏ hàng</h1>
            <p class="lead text-muted">
              
            </p>
          </div>
          <div class="col-lg-3 text-right order-1 order-lg-2">
            <ul class="breadcrumb justify-content-lg-end">
              <li class="breadcrumb-item"><a href="index.html">Trang chủ</a></li>
              <li class="breadcrumb-item active">Giỏ hàng</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <!-- Shopping Cart Section-->
    <section class="shopping-cart">
      <div class="container">
        <div class="basket">
          <div class="basket-holder">
            <div class="basket-header">
              <div class="row">
                <div class="col-5">Sản phẩm</div>
                <div class="col-2">Giá</div>
                <div class="col-2">Số lượng</div>
                <div class="col-2">Tổng tiền</div>
                <div class="col-1 text-center">Xóa</div>
              </div>
            </div>  
            <div class="basket-body">
              
              <!-- Product-->
 <?php 

      
    if(isset($_SESSION["products"]))
    {
        $current_url = $_SERVER['REQUEST_URI'];
        $total = 0;
      
        $cart_items = 0;
        foreach ($_SESSION["products"] as $cart_itm)
        {
           $product_id = $cart_itm["id"];
           $sql1 = "SELECT * FROM product WHERE id IN ('$product_id') LIMIT 1";
           $results1 = mysqli_query($conn, $sql1);
     
           $obj = mysqli_fetch_array($results1);

           $subtotal = ($cart_itm["price"]*$cart_itm["qty"]);
          $total = ($total + $subtotal);
           echo '<div class="item">
                <div class="row d-flex align-items-center">
                  <div class="col-5">
                    <div class="d-flex align-items-center">
                      <img
                        src="images/'.$obj['image'].'"
                        alt="..."
                        class="img-fluid"
                      />
                      <div class="title">
                        <a href="?catch=chitiet&chitiet='.$obj['id'].'">
                          <h6>'.$cart_itm["name"].'</h6>
                          </a
                        >
                      </div>
                    </div>
                  </div>
                  <div class="col-2"><span>'.$cart_itm["price"].' đ</span></div>
                  <div class="col-2"> <span>&emsp;&emsp;'.$cart_itm["qty"].'&emsp;&emsp;</span>
                    
                      
                      
                        
                      
                  
                  </div>
                  <div class="col-2"><span>'.$subtotal.' đ</span></div>
                  <div class="col-1 text-center">
                    <a href="cart/cart.php?removep='.$cart_itm["id"].'&return_url='.$current_url.'" class="delete"
                                  ><i class="fa fa-trash-o"></i
                                ></a>
                  </div>
                </div>
              </div>';
                  
      }

      echo '</div>
          </div>
        </div>
      </div>
      <div class="container">
        <div
          class="CTAs d-flex align-items-center justify-content-center justify-content-md-end flex-column flex-md-row"
        > Tổng tiền: '.$total.' đ &emsp;
          <a href="?catch=checkout" class="btn btn-template wide">Mua hàng</a>
        </div>
      </div>
    </section>';





            
           
        
    }else{
       
    
  }
?>


              
            