<!-- <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous"> -->
<link rel='stylesheet prefetch' href='https://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css'>
<?php



/**
 * Pagination basic created by toidicode.com
 *
 * @package Pagination basic
 * @author  ThanhTai - ToiDiCodeTeam
 * @copyright   Copyright (c) 2017, Toidicode Team. (http://toidicode.com/)
 * @link    https://toidicode.com
 * @since   Version 1.0.0
 * @filesource
 */
class Pagination
{
     
    /**
     * Biến config chứa tất cả các cấu hình
     *
     * @var array
     */
    private $config = [
        'total' => 0, // tổng số mẩu tin
        'limit' => 0, // số mẩu tin trên một trang
        'full' => true, // true nếu hiện full số page, flase nếu không muốn hiện false
        'querystring' => 'page' // GET id nhận page
    ];

    

    /**
     * khởi tạo
     *
     * @param array $config
     */


    public function __construct($config = [])
    {
        // kiểm tra xem trong config có limit, total đủ điều kiện không
        if (isset($config['limit']) && $config['limit'] < 0 || isset($config['total']) && $config['total'] < 0) {
            // nếu không thì dừng chương trình và hiển thị thông báo.
            die('limit và total không được nhỏ hơn 0');
        }
        // Kiểm tra xem config có querystring không
        if (!isset($config['querystring'])) {
            //nếu không để mặc định là page
            $config['querystring'] = 'page';
        }
        $this->config = $config;
    }

    /**
     * Lấy ra tổng số trang
     *
     * @return int
     */
    private function gettotalPage()
    {
        return ceil($this->config['total'] / $this->config['limit']);

    }

    /**
     * Lấy ra trang hiện tại
     *
     * @return int
     */
    private function getCurrentPage()
    {
        // kiểm tra tồn tại GET querystring và có >=1 không
        if (isset($_GET[$this->config['querystring']]) && (int)$_GET[$this->config['querystring']] >= 1) {
            // Nếu có kiểm tra tiếp xem nó có lớn hơn tổn số trang không.
            if ((int)$_GET[$this->config['querystring']] > $this->gettotalPage()) {
                // nếu lớn hơn thì trả về tổng số page
                return (int)$this->gettotalPage();
            } else {
                // còn không thì trả về số trang
                return (int)$_GET[$this->config['querystring']];
            }

        } else {
            // nếu không có querystring thì nhận mặc định là 1
            return 1;
        }
    }

    /**
     * lấy ra trang phía trước
     *
     * @return string
     */
    private function getPrePage()
    {
        // nếu trang hiện tại bằng 1 thì trả về null
        if ($this->getCurrentPage() === 1) {
            return;
        } else {
            // còn không thì trả về html code
            return '<li class="page-item"><a href="' . '?catch=chitiet&chitiet='.$_GET["chitiet"]. '&' . $this->config['querystring'] . '=' . ($this->getCurrentPage() - 1) . '" aria-label="Previous" class="page-link" ><span aria-hidden="true">Prev</span></a></li>';
        }
    }

    /**
     * Lấy ra trang phía sau
     *
     * @return string
     */
    private function getNextPage()
    {
        // nếu trang hiện tại lơn hơn = totalpage thì trả về rỗng
        if ($this->getCurrentPage() >= $this->gettotalPage()) {
            return;
        } else {
            // còn không thì trả về HTML code
            return '<li class="page-item"><a href="' . '?catch=chitiet&chitiet='.$_GET["chitiet"]. '&' . $this->config['querystring'] . '=' . ($this->getCurrentPage() + 1) . '" aria-label="Previous" class="page-link" ><span aria-hidden="true">Next</span></a></li>';
        }
    }

    /**
     * Hiển thị html code của page
     *
     * @return string
     */
    public function getPagination()
    {
      echo '<br>';
        // tạo biến data rỗng
        $data = '';
        // kiểm tra xem người dùng có cần full page không.
        if (isset($this->config['full']) && $this->config['full'] === false) {
            // nếu không thì
            $data .= ($this->getCurrentPage() - 3) > 1 ? '<li>...</li>' : '';

            for ($i = ($this->getCurrentPage() - 3) > 0 ? ($this->getCurrentPage() - 3) : 1; $i <= (($this->getCurrentPage() + 3) > $this->gettotalPage() ? $this->gettotalPage() : ($this->getCurrentPage() + 3)); $i++) {
                if ($i === $this->getCurrentPage()) {
                    $data .= '<li class="page-item" ><a href="#" class="page-link active">' . $i . '</a></li>';
                } else {
                    $data .= '<li class="page-item"><a href="' . '?catch=chitiet&chitiet='.$_GET["chitiet"]. '&' . $this->config['querystring'] . '=' . $i . '" aria-label="Previous" class="page-link">' . $i . '</a></li>';
                }
            }

            $data .= ($this->getCurrentPage() + 3) < $this->gettotalPage() ? '<li>...</li>' : '';
        } else {
            // nếu có thì
            for ($i = 1; $i <= $this->gettotalPage(); $i++) {
                if ($i === $this->getCurrentPage()) {
                    $data .= '<li class="page-item" ><a href="#" class="page-link active">' . $i . '</a></li>';
                } else {
                    $data .= '<li class="page-item"><a href="' .'?catch=chitiet&chitiet='.$_GET["chitiet"]. '&' . $this->config['querystring'] . '=' . $i . '" aria-label="Previous" class="page-link">' . $i . '</a></li>';
                }
            }
        }

        return '<nav
              aria-label="page navigation example"
              class="d-flex justify-content-center"
            >
              <ul class="pagination pagination-custom">' . $this->getPrePage() . $data . $this->getNextPage() . '</ul></nav>';
    }
}


?>
<div class="container_01">
<?php
    
    
    // include '../database/DataProvider.php';
    // include 'couple.php';
    
    $conn = OpenCon();
    

    $sql = "SELECT * FROM product";
    $sql2 = "SELECT * FROM product";

    // $sql = "SELECT * FROM dongho";
    // $sql2 = "SELECT * FROM chitietdh";
    // $sql = "SELECT * FROM product";
    // $sql2 = "SELECT * FROM chitietdh";


    $result = mysqli_query ( $conn ,$sql);
    $result2 = mysqli_query ( $conn ,$sql2);

 if (! isset($_GET['chitiet']))
    {
        



    } else {    
        $page = $_GET['chitiet'];
        while ($row = mysqli_fetch_array($result))
        {
            if($page == $row['id'])
            {
              // echo '<!-- Hero Section-->
              // <section class="hero hero-page gray-bg padding-small">
              //   <div class="container">
              //     <div class="row d-flex">
              //       <div class="col-lg-9 order-2 order-lg-1">
              //         <h1>'.$row["name"].'</h1>
              //       </div>
              //       <div class="col-lg-3 text-right order-1 order-lg-2">
              //         <ul class="breadcrumb justify-content-lg-end">
              //           <li class="breadcrumb-item"><a href="index.php">Trang chủ</a></li>
                        
              //           <li class="breadcrumb-item active">'.$row["name"].'</li>
              //         </ul>
              //       </div>
              //     </div>
              //   </div>
              // </section>';
              echo '
              <section class="product-details">
                <div class="container">
                  <div class="row">
                    <div class="product-images col-lg-6">
                      <div data-slider-id="1" class="owl-carousel items-slider owl-drag">
                        <div class="item">
                          <img src="images/'.$row["image"].'" alt="watches" />
                        </div>
                        
                      </div>
                    </div>
                    <div class="details col-lg-6 boderexam1">
                    <div class="block-body order-summary">
                      <h1>'.$row["name"].'</h1>
                      <div
                        class="d-flex align-items-center justify-content-between flex-column flex-sm-row"
                      >
                        <ul class="price list-inline no-margin">
                          <li class="list-inline-item current">'.number_format($row["price"], 0, ',', '.').' ₫ </li>
                          
                        </ul>
                        <div class="review d-flex align-items-center">
                          
                          <span class="text-muted">Còn lại: '.$row["total"].'</span>
                        </div>
                      </div>';
                      $bien = $row["id"];
                      if ($row["catalog_id"] == '1')
                      {
                        $url = '../?catch=men';
                      }
                      elseif ($row["catalog_id"] == '0') {
                        $url = '../?catch=women';
                      }
                      elseif ($row["catalog_id"] == '2') {
                        $url = '../?catch=couple';
                      }

                        echo '<p>
                      '.$row["description"].'
                          </p>
                          
                          <ul class="CTAs list-inline">
                            <li class="list-inline-item">
                              <a href="cart/cart.php?type=add&product_id='.$bien.'&product_qty=1&return_url='.$url.'" class="btn btn-template wide">
                                <i class="icon-cart"></i>Thêm vào giỏ hàng</a
                              >
                            </li>
                            
                          </ul>
                        </div>
                      </div>
                    </div>
                    </div>
                  </section>';
                  

                  // echo '<div class="float_left_02"><img src="images/thongtinchitiet.png" width="800px" /><br />'
                          // echo '<div class="float_left_02">
                          //         <div class="block-header mb-5">
                          //           <h5>THÔNG TIN CHI TIẾT</h5>
                          //         </div><br/>';
                          // echo '<div class="block-body">';
                          // echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><br><strong>NĂNG LƯỢNG</strong></td><td width="290px" ><br>'.$row["ennergy"].'</td></tr></tr></table><img src="images/ngang.png" width="600px"/>';
                          // echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>CHẤT LIỆU DÂY</strong></td><td width="290px" >'.$row["strap_material"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
                          // echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>CHẤT LIỆU MẶT KÍNH</strong></td><td width="290px" >'.$row["glass_material"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
                          
                          // echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>HÌNH DẠNG MẶT SỐ</strong></td><td width="290px" >'.$row["face_shape"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
                          // echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>KÍCH THƯỚC MẶT SỐ</strong></td><td width="290px" >'.$row["size_face"].'</td></tr> </table><img src="images/ngang.png" width="600px"/>';
                          // echo ' <table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>MÀU MẶT SỐ</strong></td><td width="290px" >'.$row["color_face"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
                          // echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>MỨC CHÓNG NƯỚC</strong></td><td width="290px" >'.$row["waterproof"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
                          // echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>THƯƠNG HIỆU</strong></td><td width="290px" text-transform: capitalize;>'.$row["trademark"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
                          // echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><STRONG>XUẤT XỨ</STRONG></td><td width="290px" >'.$row["origin"].'</td></tr></table><img src="images/ngang.png" width="600px"/></div>';
                          
                          // echo '</div>';
                          echo '
                          <div class="page-product__content">
                          <div class="page-product__content--left">
                              <div class="block-header mb-5">
                                <h5>THÔNG TIN CHI TIẾT</h5>
                              </div>';
                              
                                echo '<div class="block-body">';
                                echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><br><strong>NĂNG LƯỢNG</strong></td><td width="290px" ><br>'.$row["ennergy"].'</td></tr></tr></table><img src="images/ngang.png" width="600px"/>';
                                echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>CHẤT LIỆU DÂY</strong></td><td width="290px" >'.$row["strap_material"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
                                echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>CHẤT LIỆU MẶT KÍNH</strong></td><td width="290px" >'.$row["glass_material"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
                                
                                echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>HÌNH DẠNG MẶT SỐ</strong></td><td width="290px" >'.$row["face_shape"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
                                echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>KÍCH THƯỚC MẶT SỐ</strong></td><td width="290px" >'.$row["size_face"].'</td></tr> </table><img src="images/ngang.png" width="600px"/>';
                                echo ' <table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>MÀU MẶT SỐ</strong></td><td width="290px" >'.$row["color_face"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
                                echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>MỨC CHÓNG NƯỚC</strong></td><td width="290px" >'.$row["waterproof"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
                                echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>THƯƠNG HIỆU</strong></td><td width="290px" text-transform: capitalize;>'.$row["trademark"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
                                echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><STRONG>XUẤT XỨ</STRONG></td><td width="290px" >'.$row["origin"].'</td></tr></table><img src="images/ngang.png" width="600px"/></div>';
                           echo '   
                              </div>
                              <div class="page-product__content--right">';
                            echo '<div>Top sản phẩm bán chạy</div>
                              
                                  ';
                              echo '
                          </div>
                      </div>';
                         

                          echo '<div class="mono"></div>';
                  // echo '</div>';

                  
             
              }
        }
//         $row2 = mysqli_fetch_array($result2);
       
//             if($page <= 116)
//             {
//                  echo '<p>
//               '.$row2["description"].'
//             </p>
            
//             <ul class="CTAs list-inline">
//               <li class="list-inline-item">
//                 <a href="cart/cart.php?type=add&product_id='.$bien.'&product_qty=1&return_url='.$url.'" class="btn btn-template wide">
//                   <i class="icon-cart"></i>Thêm vào giỏ hàng</a
//                 >
//               </li>
              
//             </ul>
//           </div>
//         </div>
//       </div>
//     </section>';

//     // echo '<div class="float_left_02"><img src="images/thongtinchitiet.png" width="800px" /><br />'
//             echo '<div class="float_left_02">
//                     <div class="block-header mb-5">
//                       <h5>THÔNG TIN CHI TIẾT</h5>
//                     </div><br/>';
//             echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><br><strong>NĂNG LƯỢNG</strong></td><td width="290px" ><br>'.$row2["ennergy"].'</td></tr></tr></table><img src="images/ngang.png" width="600px"/>';
//             echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>CHẤT LIỆU DÂY</strong></td><td width="290px" >'.$row2["strap_material"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
//             echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>CHẤT LIỆU MẶT KÍNH</strong></td><td width="290px" >'.$row2["glass_material"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
            
//             echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>HÌNH DẠNG MẶT SỐ</strong></td><td width="290px" >'.$row2["face_shape"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
//             echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>KÍCH THƯỚC MẶT SỐ</strong></td><td width="290px" >'.$row2["size_face"].'</td></tr> </table><img src="images/ngang.png" width="600px"/>';
//             echo ' <table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>MÀU MẶT SỐ</strong></td><td width="290px" >'.$row2["color_face"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
//             echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>MỨC CHÓNG NƯỚC</strong></td><td width="290px" >'.$row2["waterproof"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
//             echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>THƯƠNG HIỆU</strong></td><td width="290px" text-transform: capitalize;>'.$row2["trademark"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
//             echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><STRONG>XUẤT XỨ</STRONG></td><td width="290px" >'.$row2["origin"].'</td></tr></table><img src="images/ngang.png" width="600px"/></div>';
            
//               echo '<div class="mono"></div>';


    
//     echo '<section class="related-products">
//       <div class="container">
//         <header class="text-center">
//           <h2>CÓ LẼ BẠN SẼ THÍCH</h2>
//         </header>
//         <div class="row">
//           <!-- item-->
//           <div class="item col-lg-3">
//             <div class="product is-gray">
//               <div
//                 class="image d-flex align-items-center justify-content-center"
//               >
//                 <img src="images/nam1.jpg" alt="..." class="img-fluid" />
//                 <div
//                   class="hover-overlay d-flex align-items-center justify-content-center"
//                 >
//                   <div
//                     class="CTA d-flex align-items-center justify-content-center"
//                   >
//                     <a href="?catch=chitiet&chitiet=1" class="visit-product active"
//                       ><i class="icon-search"></i>Chi tiết</a
//                     >
//                   </div>
//                 </div>
//               </div>
//               <div class="title">
//                 <a href="#">
//                   <h3 class="h6 text-uppercase no-margin-bottom">
//                     ĐỒNG HỒ LOUIS ERARD 1
//                   </h3></a
//                 ><span class="price">
// 10990000 ₫ </span>
//               </div>
//             </div>
//           </div>
//           <!-- item-->
//           <div class="item col-lg-3">
//             <div class="product is-gray">
//               <div
//                 class="image d-flex align-items-center justify-content-center"
//               >
//                 <img src="images/nam8.jpg" alt="..." class="img-fluid" />
//                 <div
//                   class="hover-overlay d-flex align-items-center justify-content-center"
//                 >
//                   <div
//                     class="CTA d-flex align-items-center justify-content-center"
//                   >
//                     <a href="?catch=chitiet&chitiet=8" class="visit-product active"
//                       ><i class="icon-search"></i>Chi tiết</a
//                     >
//                   </div>
//                 </div>
//               </div>
//               <div class="title">
//                 <a href="#">
//                   <h3 class="h6 text-uppercase no-margin-bottom">
//                     ĐỒNG HỒ CASIO 1
//                   </h3></a
//                 ><span class="price">14590000 ₫ </span>
//               </div>
//             </div>
//           </div>
//           <!-- item-->
//           <div class="item col-lg-3">
//             <div class="product is-gray">
//               <div
//                 class="image d-flex align-items-center justify-content-center"
//               >
//                 <img src="images/nu2.jpg" alt="..." class="img-fluid" />
//                 <div
//                   class="hover-overlay d-flex align-items-center justify-content-center"
//                 >
//                   <div
//                     class="CTA d-flex align-items-center justify-content-center"
//                   >
//                     <a href="?catch=chitiet&chitiet=42" class="visit-product active"
//                       ><i class="icon-search"></i>Chi tiết</a
//                     >
//                   </div>
//                 </div>
//               </div>
//               <div class="title">
//                 <a href="#">
//                   <h3 class="h6 text-uppercase no-margin-bottom">
//                     ĐỒNG HỒ CITIZEN 1
//                   </h3></a
//                 ><span class="price">
// 12000000 ₫ </span>
//               </div>
//             </div>
//           </div>
//           <!-- item-->
//           <div class="item col-lg-3">
//             <div class="product is-gray">
//               <div
//                 class="image d-flex align-items-center justify-content-center"
//               >
//                 <img src="images/doi1.jpg" alt="..." class="img-fluid" />
//                 <div
//                   class="hover-overlay d-flex align-items-center justify-content-center"
//                 >
//                   <div
//                     class="CTA d-flex align-items-center justify-content-center"
//                   >
//                     <a href="?catch=chitiet&chitiet=91" class="visit-product active"
//                       ><i class="icon-search"></i>Chi tiết</a
//                     >
//                   </div>
//                 </div>
//               </div>
//               <div class="title">
//                 <a href="#">
//                   <h3 class="h6 text-uppercase no-margin-bottom">
//                     ĐỒNG HỒ ĐÔI ALEXANDRE 1
//                   </h3></a
//                 ><span class="price">10990000 ₫ </span>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </section>';
    
//             }
//             else{
//                while ($row2 = mysql_fetch_array($result2)) {
//              if($page == $row2['madh'])
            
            
//             {

//                 echo '<p>
//               '.$row2["description"].'
//             </p>
            
//             <ul class="CTAs list-inline">
//               <li class="list-inline-item">
//                 <a href="#" class="btn btn-template wide">
//                   <i class="icon-cart"></i>Thêm vào giỏ hàng</a
//                 >
//               </li>
              
//             </ul>
//           </div>
//         </div>
//       </div>
//     </section>';

//     echo '<div class="float_left_02"><img src="images/thongtinchitiet.png" width="800px" /><br /><table border="0px"><tr  height="30px"><td class="thongtin1" width="600px"><br><strong>BỘ MÁY & NĂNG LƯỢNG</strong></td><td width="290px" ><br>'.$row2["nangluong"].'</td></tr></tr></table><img src="images/ngang.png" width="800px"/>';
//             echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="600px"><strong>CHẤT LIỆU DÂY</strong></td><td width="290px" >'.$row2["chatlieuday"].'</td></tr></table><img src="images/ngang.png" width="800px"/>';
//             echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="600px"><strong>CHẤT LIỆU MẶT KÍNH</strong></td><td width="290px" >'.$row2["chatlieumatkinh"].'</td></tr></table><img src="images/ngang.png" width="800px"/>';
            
//             echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="600px"><strong>HÌNH DẠNG MẶT SỐ</strong></td><td width="290px" >'.$row2["hinhdangmatso"].'</td></tr></table><img src="images/ngang.png" width="800px"/>';
//             echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="600px"><strong>KÍCH THƯỚC MẶT SỐ</strong></td><td width="290px" >'.$row2["kichthuocmatso"].'</td></tr> </table><img src="images/ngang.png" width="800px"/>';
//             echo ' <table border="0px"><tr  height="30px"><td class="thongtin1" width="600px"><strong>MÀU MẶT SỐ</strong></td><td width="290px" >'.$row2["maumatso"].'</td></tr></table><img src="images/ngang.png" width="800px"/>';
//             echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="600px"><strong>MỨC CHÓNG NƯỚC</strong></td><td width="290px" >'.$row2["mucchongnuoc"].'</td></tr></table><img src="images/ngang.png" width="800px"/>';
//             echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="600px"><strong>THƯƠNG HIỆU</strong></td><td width="290px" >'.$row2["thuonghieu"].'</td></tr></table><img src="images/ngang.png" width="800px"/>';
//             echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="600px"><STRONG>XUẤT XỨ</STRONG></td><td width="290px" >'.$row2["xuatxu"].'</td></tr></table><img src="images/ngang.png" width="800px"/></div>';
            
//               echo '<div class="mono"></div>';


    
//     echo '<section class="related-products">
//       <div class="container">
//         <header class="text-center">
//           <h2>CÓ LẼ BẠN SẼ THÍCH</h2>
//         </header>
//         <div class="row">
//           <!-- item-->
//           <div class="item col-lg-3">
//             <div class="product is-gray">
//               <div
//                 class="image d-flex align-items-center justify-content-center"
//               >
//                 <img src="images/nam1.jpg" alt="..." class="img-fluid" />
//                 <div
//                   class="hover-overlay d-flex align-items-center justify-content-center"
//                 >
//                   <div
//                     class="CTA d-flex align-items-center justify-content-center"
//                   >
//                     <a href="?catch=chitiet&chitiet=1" class="visit-product active"
//                       ><i class="icon-search"></i>Chi tiết</a
//                     >
//                   </div>
//                 </div>
//               </div>
//               <div class="title">
//                 <a href="#">
//                   <h3 class="h6 text-uppercase no-margin-bottom">
//                     ĐỒNG HỒ LOUIS ERARD 1
//                   </h3></a
//                 ><span class="price">
// 10990000 ₫ </span>
//               </div>
//             </div>
//           </div>
//           <!-- item-->
//           <div class="item col-lg-3">
//             <div class="product is-gray">
//               <div
//                 class="image d-flex align-items-center justify-content-center"
//               >
//                 <img src="images/nam8.jpg" alt="..." class="img-fluid" />
//                 <div
//                   class="hover-overlay d-flex align-items-center justify-content-center"
//                 >
//                   <div
//                     class="CTA d-flex align-items-center justify-content-center"
//                   >
//                     <a href="?catch=chitiet&chitiet=8" class="visit-product active"
//                       ><i class="icon-search"></i>Chi tiết</a
//                     >
//                   </div>
//                 </div>
//               </div>
//               <div class="title">
//                 <a href="#">
//                   <h3 class="h6 text-uppercase no-margin-bottom">
//                     ĐỒNG HỒ CASIO 1
//                   </h3></a
//                 ><span class="price">14590000 ₫ </span>
//               </div>
//             </div>
//           </div>
//           <!-- item-->
//           <div class="item col-lg-3">
//             <div class="product is-gray">
//               <div
//                 class="image d-flex align-items-center justify-content-center"
//               >
//                 <img src="images/nu2.jpg" alt="..." class="img-fluid" />
//                 <div
//                   class="hover-overlay d-flex align-items-center justify-content-center"
//                 >
//                   <div
//                     class="CTA d-flex align-items-center justify-content-center"
//                   >
//                     <a href="?catch=chitiet&chitiet=42" class="visit-product active"
//                       ><i class="icon-search"></i>Chi tiết</a
//                     >
//                   </div>
//                 </div>
//               </div>
//               <div class="title">
//                 <a href="#">
//                   <h3 class="h6 text-uppercase no-margin-bottom">
//                     ĐỒNG HỒ CITIZEN 1
//                   </h3></a
//                 ><span class="price">
// 12000000 ₫ </span>
//               </div>
//             </div>
//           </div>
//           <!-- item-->
//           <div class="item col-lg-3">
//             <div class="product is-gray">
//               <div
//                 class="image d-flex align-items-center justify-content-center"
//               >
//                 <img src="images/doi1.jpg" alt="..." class="img-fluid" />
//                 <div
//                   class="hover-overlay d-flex align-items-center justify-content-center"
//                 >
//                   <div
//                     class="CTA d-flex align-items-center justify-content-center"
//                   >
//                     <a href="?catch=chitiet&chitiet=91" class="visit-product active"
//                       ><i class="icon-search"></i>Chi tiết</a
//                     >
//                   </div>
//                 </div>
//               </div>
//               <div class="title">
//                 <a href="#">
//                   <h3 class="h6 text-uppercase no-margin-bottom">
//                     ĐỒNG HỒ ĐÔI ALEXANDRE 1
//                   </h3></a
//                 ><span class="price">10990000 ₫ </span>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </section></div></div>';
           
            
//           }  

//         }
//       }
        
    }
    

    echo '<section class="">
    <div class="container">
      <div class="row d-flex">
        <div class="col-lg-9 order-2 order-lg-1">
        
        <div class="">
                    <div class="block-header mb-5">
                      <h5>ĐÁNH GIÁ SẢN PHẨM</h5>
                    </div>';
                    // echo '<div class="product-rating-overview"></div>';
                    echo'
                      <form action="" method="POST">
                        <div class="product-rating-overview">
                          <div class="product-rating-overview__briefing">
                            <div class="product-rating-overview__score-wrapper">
                              <span class="product-rating-overview__rating-score">5</span>
                              <span class="product-rating-overview__rating-score-out-of">trên 5</span>
                            </div>
                            <div class="shopee-rating-stars product-rating-overview__stars">
                              <span class="fa fa-star checked"></span>
                              <span class="fa fa-star checked"></span>
                              <span class="fa fa-star checked"></span>
                              <span class="fa fa-star checked"></span>
                              <span class="fa fa-star checked"></span>
                            </div>
                          </div>
                          
                            <div class="product-rating-overview__filters">
                              <button class="product-rating-overview__filter product-rating-overview__filter--active product-rating-overview__filter--all" name="tatca">
                                Tất cả
                              </button>
                              <div class="product-rating-overview__filter">
                                5 sao
                              </div>
                              <div class="product-rating-overview__filter">
                                4 sao
                              </div>
                              <div class="product-rating-overview__filter">
                                3 sao
                              </div>
                              <div class="product-rating-overview__filter">
                                2 sao
                              </div>
                              <div class="product-rating-overview__filter">
                                1 sao
                              </div>
                              <div class="product-rating-overview__filter">
                                0 sao
                              </div>
                            </div>
                          
                        </div>
                      </form>';
                    // binhluan();
                    echo '<div class="form-group col-md-8">';
                          binhluan();
                    echo '</div>';
        echo '</div>';
  




  function namsao()
  {
    echo '<span class="fa fa-star checked"></span>';
    echo '<span class="fa fa-star checked"></span>';
    echo '<span class="fa fa-star checked"></span>';
    echo '<span class="fa fa-star checked"></span>';
    echo '<span class="fa fa-star checked"></span>';echo'<br>';
  }
  function bonsao()
  {
    echo '<span class="fa fa-star checked"></span>';
    echo '<span class="fa fa-star checked"></span>';
    echo '<span class="fa fa-star checked"></span>';
    echo '<span class="fa fa-star checked"></span>';
    echo '<span class="fa fa-star"></span>';echo'<br>';
  }
  function basao()
  {
    echo '<span class="fa fa-star checked"></span>';
    echo '<span class="fa fa-star checked"></span>';
    echo '<span class="fa fa-star checked"></span>';
    echo '<span class="fa fa-star"></span>';
    echo '<span class="fa fa-star"></span>';echo'<br>';
  }
  function haisao()
  {
    echo '<span class="fa fa-star checked"></span>';
    echo '<span class="fa fa-star checked"></span>';
    echo '<span class="fa fa-star"></span>';
    echo '<span class="fa fa-star"></span>';
    echo '<span class="fa fa-star"></span>';echo'<br>';
  }
  function motsao()
  {
    echo '<span class="fa fa-star checked"></span>';
    echo '<span class="fa fa-star"></span>';
    echo '<span class="fa fa-star"></span>';
    echo '<span class="fa fa-star"></span>';
    echo '<span class="fa fa-star"></span>';echo'<br>';
  }
  function khongsao()
  {
    echo '<span class="fa fa-star"></span>';
    echo '<span class="fa fa-star"></span>';
    echo '<span class="fa fa-star"></span>';
    echo '<span class="fa fa-star"></span>';
    echo '<span class="fa fa-star"></span>';echo'<br>';
  }
        
  function binhluan()
  {
      $conn = OpenCon();
      $id_product = $_GET['chitiet'];

      $sql12 = "SELECT count(id) as total from feedback WHERE product_id = $id_product ";
        $result12 = mysqli_query ( $conn , $sql12);
        $row12 = mysqli_fetch_assoc($result12);
        $total_records = $row12['total'];



        // BƯỚC 3: TÌM LIMIT VÀ CURRENT_PAGE
        $current_page = isset($_GET['trang']) ? $_GET['trang'] : 1;
        $limit = 5;


        // BƯỚC 4: TÍNH TOÁN TOTAL_PAGE VÀ START
        // tổng số trang

        $total_page = ceil($total_records / $limit);

        // Giới hạn current_page trong khoảng 1 đến total_page
        if ($current_page > $total_page){
            $current_page = $total_page;
        }
        else if ($current_page < 1){
            $current_page = 1;
        }
 
        // Tìm Start
        $start = ($current_page - 1) * $limit;
      if (isset($_SESSION['currId']))
      {
        
      
            // $conn = OpenCon();
            $id_user = $_SESSION['currId'];
            // $id_product = $_GET['chitiet'];
            $sql4 = mysqli_query ( $conn ,"SELECT * FROM transaction Where user_id = '$id_user'");
            if (mysqli_num_rows($sql4) != 0)
            {
                echo '
                      <div class="">
                          <form action="" method="POST">
                              <div class="form-group col-md-10">
                                <textarea
                                  id="hoten"
                                  required=""
                                  style="resize: none"
                                  name="binhluan"
                                  placeholder="Bình luận..."
                                  class="form-control"
                                  rows="2"
                                ></textarea>
                                <input class="star star-5" id="star-5" type="radio" name="star" value="5"/>
                                <label class="star star-5" for="star-5"></label>
                                <input class="star star-4" id="star-4" type="radio" name="star" value="4"/>
                                <label class="star star-4" for="star-4"></label>
                                <input class="star star-3" id="star-3" type="radio" name="star" value="3"/>
                                <label class="star star-3" for="star-3"></label>
                                <input class="star star-2" id="star-2" type="radio" name="star" value="2"/>
                                <label class="star star-2" for="star-2"></label>
                                <input class="star star-1" id="star-1" type="radio" name="star" value="1"/>
                                <label class="star star-1" for="star-1"></label>
                              </div>
                              <div>
                                <button class="btn btn-template wide next" type="submit" value="Gửi bình luận" name="mua">Gửi bình luận</button>
                              </div>
                          </form>
                      </div>';
              
            }
      }

              echo '</div>
                    </div>
                </section>';

              if(isset($_POST['binhluan']))
              {
                // $conn = OpenCon();
                // $id_user = $_SESSION['currId'];
                // $id_product = $_GET['chitiet'];
                $cmt = $_POST['binhluan'];
                if (isset($_POST['star']))
                {
                  $rate = $_POST['star'];
                }
                else $rate = 0;
                
                echo $rate;
                // echo $id;
                // echo $_GET['chitiet'];
                $today = date("Y/m/d");
                // echo $today;
                $sql3 = mysqli_query ( $conn ,"SELECT * FROM member Where id = '$id_user' ");
                if (mysqli_num_rows($sql3) != 0)
                {
                  // echo "<script> alert('dsdsdsdsdsdsd') </script>";
                  $addmember = mysqli_query($conn,"
                  INSERT INTO `feedback` (`user_id`, `product_id`, `content`, `rate`, `date_created`) VALUES ('{$id_user}', '{$id_product}', '{$cmt}', '{$rate}', '{$today}');
                  ");
                  // echo $today;
                }
                // echo $_POST['binhluan'].$_SESSION['currUser'];
              }

              $sql3 = mysqli_query ( $conn ,"SELECT * FROM feedback Where product_id = '$id_product' LIMIT $start, $limit");
              // echo $sql3;
              
              if (mysqli_num_rows($sql3) != 0)
              {
                while ($row = mysqli_fetch_assoc($sql3))
                {
                  // echo '
                  //     <div class="shopee-product-rating container">
                  //       <div class="shopee-product-rating__avatar">
                  //         hình
                  //       </div>
                  //       <div class="shopee-product-rating__main">
                  //         <div class="shopee-product-rating__author-name">
                  //           name
                  //         </div>
                  //         <div class="">
                  //           sao
                  //         </div>
                  //         <div class="shopee-product-rating__content">
                  //           ákd
                  //         </div>
                  //         <div class="shopee-product-rating__time">
                  //           ngày
                  //         </div>
                  //       </div>
                  //     </div>
                  //       ';
                  // echo $row['rate'];  echo'<br>';
                  // echo '<div class="container">';
                  // echo $_SESSION['currUser'].'.';
                  $id_cmt = $row['user_id'];
                  $sql6 = mysqli_query ( $conn ,"SELECT * FROM member Where id = '$id_cmt' ");
                  if (mysqli_num_rows($sql6) != 0)
                  {
                    $row6 = mysqli_fetch_assoc($sql6);
                    // echo $row6['name'];
                  }

                  // echo '    <img src="images/tik.png" width="20px" height="20px">';
                  // echo '  Đã mua sản phẩm <br> ' ;
                  // if ($row['rate'] == 0)
                  // {
                  //   khongsao();
                  // }
                  // if ($row['rate'] == 1)
                  // {
                  //   motsao();
                  // }
                  // if ($row['rate'] == 2)
                  // {
                  //   haisao();
                  // }
                  // if ($row['rate'] == 3)
                  // {
                  //   basao();
                  // }
                  // if ($row['rate'] == 4)
                  // {
                  //   bonsao();
                  // }
                  // if ($row['rate'] == 5)
                  // {
                  //   namsao();
                  // }
                  // // echo '<i class="fa fa-star fa-1x" data-index='.$row["rate"].'></i>';
                  // echo $row['content'].'.';
                  // echo '<div class="text-right" style="color:gray;">'.$row['date_created'].'</div>';
                  
                  // echo '<img src="images/ngang.png" width="1120px"/>';
                  // echo '</div>';
                  // echo "<br>";
                  
                  $feedback_id = $row['id'];
                  $sql5 = mysqli_query ( $conn ,"SELECT * FROM reply_feedback Where feedback_id = '$feedback_id'");
                  if (mysqli_num_rows($sql5) != 0)
                  {
                    $row5 = mysqli_fetch_assoc($sql5);
                    // echo $feedback_id;
                    // echo $row5['content'];
                    // echo $row5['created'];
                    
                  }
                  echo '
                    <div class="col-lg-9 order-2 order-lg-1">
                      <div class="shopee-product-rating container">
                        <div class="shopee-product-rating__avatar">
                          <img src="images/user.png" width="20px" height="20px">
                        </div>
                        <div class="shopee-product-rating__main">
                          <div class="shopee-product-rating__author-name">';
                            echo $row6['name'].'&nbsp;&nbsp;&nbsp;<img src="images/tik.png" width="15px" height="15px">'.'&nbsp;&nbsp;&nbspĐã mua sản phẩm';
                  echo '  </div>
                          <div class="">';
                            if ($row['rate'] == 0)
                            {
                              khongsao();
                            }
                            if ($row['rate'] == 1)
                            {
                              motsao();
                            }
                            if ($row['rate'] == 2)
                            {
                              haisao();
                            }
                            if ($row['rate'] == 3)
                            {
                              basao();
                            }
                            if ($row['rate'] == 4)
                            {
                              bonsao();
                            }
                            if ($row['rate'] == 5)
                            {
                              namsao();
                            }
                  echo '  </div>
                          <div class="shopee-product-rating__content">cmt';
                          // echo $row['content'].'.';
                  echo    '</div>
                          <div class="shopee-product-rating__time">';
                            echo $row['date_created'];
                  echo    '</div>';
                  // echo '   <div class="_2G-i9m">
                  //             <div class="Z-0IMr">
                  //               Adim
                  //             </div>
                  //             <div class="_3IhnIk">sljk';
                              $feedback_id = $row['id'];
                              $sql5 = mysqli_query ( $conn ,"SELECT * FROM reply_feedback Where feedback_id = '$feedback_id'");
                              if (mysqli_num_rows($sql5) != 0)
                              {
                                $row5 = mysqli_fetch_assoc($sql5);
                                // echo $feedback_id;
                                echo '   <div class="_2G-i9m">
                                            <div class="Z-0IMr">
                                              Adim
                                            </div>
                                        <div class="_3IhnIk">';
                                          echo $row5['content'];
                                // echo $row5['created'];
                                      echo    '</div>
                                            </div>
                                          </div>';
                                
                              }
                    // echo    '</div>
                    //         </div>
                    //       </div>';
                  echo   '  
                        </div>
                      </div>
                      </div>
                        ';
                }
              }
              else{
                echo '<div class="block-header container">';
                echo 'Sản phẩm này chưa có đánh giá.<br>

                Hãy cho người khác biết bạn nghĩ gì và là người đầu tiên viết bình luận.';
                echo '</div>';
              }
              $page = null;

                    echo '</div>';
            $config = [
            'total' => $total_records, 
            'limit' => $limit,
            'full' => true,
            'querystring' => 'trang'
            ];
            $page = new Pagination($config);
            echo $page->getPagination();



  }

  echo '<section class="related-products">
                    <div class="container">
                      <header class="text-center">
                        <h2>CÓ LẼ BẠN SẼ THÍCH</h2>
                      </header>
                      <div class="row">
                        <!-- item-->
                        <div class="item col-lg-3">
                          <div class="product is-gray">
                            <div
                              class="image d-flex align-items-center justify-content-center"
                            >
                              <img src="images/nam1.jpg" alt="..." class="img-fluid" />
                              <div
                                class="hover-overlay d-flex align-items-center justify-content-center"
                              >
                                <div
                                  class="CTA d-flex align-items-center justify-content-center"
                                >
                                  <a href="?catch=chitiet&chitiet=1" class="visit-product active"
                                    ><i class="icon-search"></i>Chi tiết</a
                                  >
                                </div>
                              </div>
                            </div>
                            <div class="title">
                              <a href="#">
                                <h3 class="h6 text-uppercase no-margin-bottom">
                                  ĐỒNG HỒ LOUIS ERARD 1
                                </h3></a
                              ><span class="price">
              10990000 ₫ </span>
                            </div>
                          </div>
                        </div>
                        <!-- item-->
                        <div class="item col-lg-3">
                          <div class="product is-gray">
                            <div
                              class="image d-flex align-items-center justify-content-center"
                            >
                              <img src="images/nam8.jpg" alt="..." class="img-fluid" />
                              <div
                                class="hover-overlay d-flex align-items-center justify-content-center"
                              >
                                <div
                                  class="CTA d-flex align-items-center justify-content-center"
                                >
                                  <a href="?catch=chitiet&chitiet=8" class="visit-product active"
                                    ><i class="icon-search"></i>Chi tiết</a
                                  >
                                </div>
                              </div>
                            </div>
                            <div class="title">
                              <a href="#">
                                <h3 class="h6 text-uppercase no-margin-bottom">
                                  ĐỒNG HỒ CASIO 1
                                </h3></a
                              ><span class="price">14590000 ₫ </span>
                            </div>
                          </div>
                        </div>
                        <!-- item-->
                        <div class="item col-lg-3">
                          <div class="product is-gray">
                            <div
                              class="image d-flex align-items-center justify-content-center"
                            >
                              <img src="images/nu2.jpg" alt="..." class="img-fluid" />
                              <div
                                class="hover-overlay d-flex align-items-center justify-content-center"
                              >
                                <div
                                  class="CTA d-flex align-items-center justify-content-center"
                                >
                                  <a href="?catch=chitiet&chitiet=42" class="visit-product active"
                                    ><i class="icon-search"></i>Chi tiết</a
                                  >
                                </div>
                              </div>
                            </div>
                            <div class="title">
                              <a href="#">
                                <h3 class="h6 text-uppercase no-margin-bottom">
                                  ĐỒNG HỒ CITIZEN 1
                                </h3></a
                              ><span class="price">
              12000000 ₫ </span>
                            </div>
                          </div>
                        </div>
                        <!-- item-->
                        <div class="item col-lg-3">
                          <div class="product is-gray">
                            <div
                              class="image d-flex align-items-center justify-content-center"
                            >
                              <img src="images/doi1.jpg" alt="..." class="img-fluid" />
                              <div
                                class="hover-overlay d-flex align-items-center justify-content-center"
                              >
                                <div
                                  class="CTA d-flex align-items-center justify-content-center"
                                >
                                  <a href="?catch=chitiet&chitiet=91" class="visit-product active"
                                    ><i class="icon-search"></i>Chi tiết</a
                                  >
                                </div>
                              </div>
                            </div>
                            <div class="title">
                              <a href="#">
                                <h3 class="h6 text-uppercase no-margin-bottom">
                                  ĐỒNG HỒ ĐÔI ALEXANDRE 1
                                </h3></a
                              ><span class="price">10990000 ₫ </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>';


      if(isset($_POST['tatca']))
      {
        echo "áhdkajsnaskdjjjj";
      }

?>

<div>
        <!-- <i class="fa fa-star fa-2x checked" data-index="0"></i>
        <i class="fa fa-star fa-2x" data-index="1"></i>
        <i class="fa fa-star fa-2x" data-index="2"></i>
        <i class="fa fa-star fa-2x" data-index="3"></i>
        <i class="fa fa-star fa-2x" data-index="4"></i>
        <br><br> -->
        <?php 
        // echo round($avg,2)
         ?>
</div>
<!-- <div class="stars">
  <form action="">
    <input class="star star-5" id="star-5" type="radio" name="star"/>
    <label class="star star-5" for="star-5"></label>
    <input class="star star-4" id="star-4" type="radio" name="star"/>
    <label class="star star-4" for="star-4"></label>
    <input class="star star-3" id="star-3" type="radio" name="star"/>
    <label class="star star-3" for="star-3"></label>
    <input class="star star-2" id="star-2" type="radio" name="star"/>
    <label class="star star-2" for="star-2"></label>
    <input class="star star-1" id="star-1" type="radio" name="star"/>
    <label class="star star-1" for="star-1"></label>
  </form>
</div> -->
    <!-- <script src="http://code.jquery.com/jquery-3.4.0.min.js" integrity="sha256-BJeo0qm959uMBGb65z40ejJYGSgR7REI4+CW1fNKwOg=" crossorigin="anonymous"></script> -->
    <!-- <script>
        var ratedIndex = -1, uID = 0;

        $(document).ready(function () {
            resetStarColors();

            if (localStorage.getItem('ratedIndex') != null) {
                setStars(parseInt(localStorage.getItem('ratedIndex')));
                uID = localStorage.getItem('uID');
            }

            $('.fa-star').on('click', function () {
               ratedIndex = parseInt($(this).data('index'));
               localStorage.setItem('ratedIndex', ratedIndex);
               saveToTheDB();
            });

            $('.fa-star').mouseover(function () {
                resetStarColors();
                var currentIndex = parseInt($(this).data('index'));
                setStars(currentIndex);
            });

            $('.fa-star').mouseleave(function () {
                resetStarColors();

                if (ratedIndex != -1)
                    setStars(ratedIndex);
            });
        });

        function saveToTheDB() {
            $.ajax({
               url: "detail.php",
               method: "POST",
               dataType: 'json',
               data: {
                   save: 1,
                   uID: uID,
                   ratedIndex: ratedIndex
               }, success: function (r) {
                    uID = r.id;
                    localStorage.setItem('uID', uID);
               }
            });
        }

        function setStars(max) {
            for (var i=0; i <= max; i++)
                $('.fa-star:eq('+i+')').css('color', '#FACC2E');
        }

        function resetStarColors() {
            $('.fa-star').css('color', 'gray');
        }
    </script> -->


  

<style>
  .checked {
    color: #FACC2E;
  }

  div.stars {
  width: 270px;
  display: inline-block;
}
 
input.star { display: none; }
 
label.star {
  float: right;
  padding: 10px;
  font-size: 36px;
  color: #444;
  transition: all .2s;
}
 
input.star:checked ~ label.star:before {
  content: '\f005';
  color: #FACC2E;
  transition: all .25s;
}
 
input.star-5:checked ~ label.star:before {
  color: #FACC2E;
  text-shadow: 0 0 20px #FACC2E;
}
 
input.star-1:checked ~ label.star:before { color: #FACC2E; }
 
label.star:hover { transform: rotate(-15deg) scale(1.3); }
 
label.star:before {
  content: '\f006';
  font-family: FontAwesome;
}
.item-card-special{
  position: relative;
}
.page-product__content {
    /* display: -webkit-box; */
    /* display: -webkit-flex; */
    /* display: -moz-box;
    display: -ms-flexbox; */
    display: flex;
}
.page-product__content--left {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    /* -moz-box-flex: 1;
    -ms-flex: 1; */
    flex: 1;
    min-width: 0;
    max-width: 800px
}
.page-product__content--right {
    width: 14.375rem;
    /* margin-left: .9375rem; */
    margin-left: 100px;
}
.container_01 {
    width: 1200px;
    margin-right: auto;
    margin-left: auto;
    margin-top: 50px;
}
.product-ratings {
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.05);
    border-radius: .125rem;
    overflow: hidden;
    background: #fff;
    margin-top: .9375rem;
    padding: 1.5625rem;
}
.boderexam1 {
        padding: 15px;
        border: 1px solid gray;
        border-style: ridge;
    }
.product-shop-hot-sales {
    padding: .625rem 0;
}
.product-rating-overview {
    background-color: #fffbf8;
    min-height: 5rem;
    /* border: 1px solid #f9ede5; */
    border: 1px solid #9055a2;
    margin-bottom: 1rem;
    display: -webkit-box;
    display: -webkit-flex;
    /* display: -moz-box;
    display: -ms-flexbox; */
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    /* -moz-box-align: center;
    -ms-flex-align: center; */
    align-items: center;
    border-radius: 2px;
    /* -moz-box-sizing: border-box; */
    box-sizing: border-box;
    padding: 1.875rem;
}
.product-rating-overview__briefing {
    text-align: center;
    margin-right: 1.875rem;
}
.product-rating-overview__score-wrapper {
    color: #9a569b;
    font-size: 1.125rem;
}
.product-rating-overview__score-wrapper {
    color: #9a569b;
    font-size: 1.125rem;
}
.product-rating-overview__rating-score {
    font-size: 1.875rem;
}
.product-rating-overview__stars {
    font-size: 1.25rem;
    margin-top: .625rem;
}
.product-rating-overview__filters {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    /* -moz-box-flex: 1;
    -ms-flex: 1; */
    flex: 1;
    margin-left: .9375rem;
}
.product-rating-overview__filter--active {
    border-color: #ee4d2d;
    fill: #ee4d2d;
    color: #ee4d2d;
}
.product-rating-overview__filter {
    cursor: pointer;
    -webkit-user-select: none;
    /* -moz-user-select: none;
    -ms-user-select: none; */
    user-select: none;
    height: 2rem;
    line-height: 2rem;
    min-width: 6.25rem;
    text-align: center;
    padding: 0 .625rem;
    background-color: #fff;
    border: 1px solid rgba(0,0,0,.09);
    /* -moz-box-sizing: border-box; */
    box-sizing: border-box;
    display: inline-block;
    margin-right: .5rem;
    text-decoration: none;
    color: rgba(0,0,0,.8);
    text-transform: capitalize;
    border-radius: 2px;
    margin-bottom: .3125rem;
    margin-top: .3125rem;
}
.shopee-product-rating__avatar {
    width: 2.5rem;
    margin-right: .625rem;
    text-align: center;
}
.shopee-product-rating__main {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    /* -moz-box-flex: 1;
    -ms-flex: 1; */
    flex: 1;
}
.shopee-product-rating {
    border-bottom: 1px solid rgba(0,0,0,.09);
    display: -webkit-box;
    display: -webkit-flex;
    /* display: -moz-box;
    display: -ms-flexbox; */
    display: flex;
    padding: 1rem 0 1rem 1.25rem;
}
.shopee-product-rating__author-name {
    text-decoration: none;
    color: rgba(0,0,0,.8);
    color: rgba(0,0,0,.87);
    font-size: .85rem;
}
.shopee-product-rating__rating1 {
    margin-top: .375rem;
}
.shopee-product-rating__content {
    margin-top: .875rem;
    margin-bottom: .875rem;
}
.shopee-product-rating__time {
    margin-top: .75rem;
    font-size: .75rem;
    color: rgba(0,0,0,.54);
}
._2G-i9m {
    margin-top: .75rem;
    background-color: #f5f5f5;
    padding: .875rem .75rem;
    position: relative;
}
.Z-0IMr {
    color: #8b572a;
    font-size: .875rem;
    text-transform: capitalize;
}
._3IhnIk {
    color: rgba(0,0,0,.87);
    white-space: pre-wrap;
    margin-top: .625rem;
    word-break: break-word;
}
._2G-i9m:after {
    border: .28125rem solid transparent;
    border-bottom-color: #f5f5f5;
    content: "";
    display: inline-block;
    position: absolute;
    top: 0;
    left: 2rem;
    -webkit-transform: translateX(-50%) translateY(-100%);
    transform: translateX(-50%) translateY(-100%);
}
</style>


    <?php
    if (isset($_POST['save'])) {
      echo "sdsđá";
    }
    ?>
<!-- <div class="container_01">
  <div class="page-product__content">
      <div class="page-product__content--left">
          <div class="product-ratings">
            <h5>THÔNG TIN CHI TIẾT</h5>
          </div>
          <?php
            echo '<div class="block-body">';
            echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><br><strong>NĂNG LƯỢNG</strong></td><td width="290px" ><br>'.$row["ennergy"].'</td></tr></tr></table><img src="images/ngang.png" width="600px"/>';
            echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>CHẤT LIỆU DÂY</strong></td><td width="290px" >'.$row["strap_material"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
            echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>CHẤT LIỆU MẶT KÍNH</strong></td><td width="290px" >'.$row["glass_material"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
            
            echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>HÌNH DẠNG MẶT SỐ</strong></td><td width="290px" >'.$row["face_shape"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
            echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>KÍCH THƯỚC MẶT SỐ</strong></td><td width="290px" >'.$row["size_face"].'</td></tr> </table><img src="images/ngang.png" width="600px"/>';
            echo ' <table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>MÀU MẶT SỐ</strong></td><td width="290px" >'.$row["color_face"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
            echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>MỨC CHÓNG NƯỚC</strong></td><td width="290px" >'.$row["waterproof"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
            echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><strong>THƯƠNG HIỆU</strong></td><td width="290px" text-transform: capitalize;>'.$row["trademark"].'</td></tr></table><img src="images/ngang.png" width="600px"/>';
            echo '<table border="0px"><tr  height="30px"><td class="thongtin1" width="400px"><STRONG>XUẤT XỨ</STRONG></td><td width="290px" >'.$row["origin"].'</td></tr></table><img src="images/ngang.png" width="600px"/></div>';
          ?>
      </div>
      <div class="page-product__content--right">
      <?php
        echo '<div>Top sản phẩm bánn chạy</div>
        
          ';
      ?>
      </div>
  </div>
</div> -->

<!-- <div class="product-rating-overview">
    <div class="product-rating-overview__briefing">
      <div class="product-rating-overview__score-wrapper">
        <span class="product-rating-overview__rating-score">5</span>
        <span class="product-rating-overview__rating-score-out-of">trên 5</span>
      </div>
      <div class="shopee-rating-stars product-rating-overview__stars">
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
      </div>
    </div>
    <div class="product-rating-overview__filters">
      <div class="product-rating-overview__filter product-rating-overview__filter--active product-rating-overview__filter--all">
        Tất cả
      </div>
      <div class="product-rating-overview__filter">
        5 sao
      </div>
      <div class="product-rating-overview__filter">
        4 sao
      </div>
      <div class="product-rating-overview__filter">
        3 sao
      </div>
      <div class="product-rating-overview__filter">F
        2 sao
      </div>
      <div class="product-rating-overview__filter">
        1 sao
      </div>
      <div class="product-rating-overview__filter">
        0 sao
      </div>
    </div>
</div>

<div class="shopee-product-rating">
  <div class="shopee-product-rating__avatar">
    sdsd
  </div>
  <div class="shopee-product-rating__main">
    sdsd
  </div> -->
</div>
</div>