<?php require_once 'Pagination3.php'; ?>

<?php




// Hien thi ket qua
        
        echo'<!-- Hero Section-->
    <section class="hero hero-page gray-bg padding-small">
      <div class="container">
        <div class="row d-flex">
          <div class="col-lg-9 order-2 order-lg-1">
            <h1>ĐỒNG HỒ NỮ</h1>
            <p class="lead text-muted">
              
            </p>
          </div>
          <div class="col-lg-3 text-right order-1 order-lg-2">
            <ul class="breadcrumb justify-content-lg-end">
              <li class="breadcrumb-item"><a href="index.php">Trang chủ</a></li>
              <li class="breadcrumb-item active">ĐỒNG HỒ NỮ</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <main>
      <div class="container">
        <div class="row">
          <!-- Sidebar-->
          <div class="sidebar col-xl-3 col-lg-4 sidebar">
            <div class="block">
              <h6 class="text-uppercase">Danh mục</h6>
              <ul class="list-unstyled">
                <li >
                  <a
                    href="?catch=men"
                    class="d-flex justify-content-between align-items-center"
                    ><span>Đồng hồ nam</span></a
                  >
                </li>
                <li class="active">
                  <a
                    href="?catch=women"
                    class="d-flex justify-content-between align-items-center"
                    ><span>Đồng hồ nữ</span></a
                  >
                </li>
                <li>
                  <a
                    href="?catch=couple"
                    class="d-flex justify-content-between align-items-center"
                    ><span>Đồng hồ đôi</span></a
                  >
                  
                </li>
                
              </ul>
            </div>
            
            
            
          </div>
          <div class="products-grid col-xl-9 col-lg-8 sidebar-left">
            
            ';



 // BƯỚC 2: TÌM TỔNG SỐ RECORDS
        $sql2 = "SELECT count(id) as total from product WHERE catalog_id IN ('2') ";
        $result2 = mysqli_query ( $conn , $sql2);
        $row2 = mysqli_fetch_assoc($result2);
        $total_records = $row2['total'];



        // BƯỚC 3: TÌM LIMIT VÀ CURRENT_PAGE
        $current_page = isset($_GET['trang']) ? $_GET['trang'] : 1;
        $limit = 9;


        // BƯỚC 4: TÍNH TOÁN TOTAL_PAGE VÀ START
        // tổng số trang

        $total_page = ceil($total_records / $limit);

        // Giới hạn current_page trong khoảng 1 đến total_page
        if ($current_page > $total_page){
            $current_page = $total_page;
        }
        else if ($current_page < 1){
            $current_page = 1;
        }
 
        // Tìm Start
        $start = ($current_page - 1) * $limit;



        // BƯỚC 5: TRUY VẤN LẤY DANH SÁCH TIN TỨC
        // Có limit và start rồi thì truy vấn CSDL lấy danh sách tin tức
 
        echo '<header class="d-flex justify-content-between align-items-start">
              <span class="visible-items"
                >Đồng hồ nữ có <strong>'.$total_records.'</strong> sản phẩm.</span
              >
              
            </header><div class="row">';
        

        $sql1 = "SELECT * FROM product WHERE catalog_id IN ('2') LIMIT $start, $limit";
        $result1 = mysqli_query ( $conn , $sql1);
        while ($row = mysqli_fetch_assoc($result1))

            {
              
              {

                            echo '<div class="item col-xl-4 col-md-6">
                <div class="product is-gray">
                  <div
                    class="image d-flex align-items-center justify-content-center"
                  >
                    
                    <img
                      src="images/'.$row["image"].'"
                      alt="product"
                      class="img-fluid"
                    />
                    <div
                      class="hover-overlay d-flex align-items-center justify-content-center"
                    >
                      <div
                        class="CTA d-flex align-items-center justify-content-center"
                      >
                        <a href="cart/cart.php?type=add&product_id='.$row["id"].'&product_qty=1&return_url='.$current_url.'" class="add-to-cart"
                          ><i class="fa fa-shopping-cart"></i></a
                        ><a href="?catch=chitiet&chitiet='.$row["id"].'" class="visit-product active"
                          ><i class="icon-search"></i>Chi tiết</a
                        >
                      </div>
                    </div>
                  </div>
                  <div class="title">
                    <small class="text-muted">Đồng hồ nữ</small
                    ><a href="detail.html">
                      <h3 class="h6 text-uppercase no-margin-bottom">
                        '.$row["name"].'
                      </h3></a
                    ><span class="price text-muted">'.$row["price"].'₫</span>
                  </div>
                </div>
              </div>';

       
        
              
              }


        
       
            }
            $page = null;

                    echo '</div>';
            $config = [
            'total' => $total_records, 
            'limit' => $limit,
            'full' => true,
            'querystring' => 'trang'
            ];
            $page = new Pagination($config);
            echo $page->getPagination();
            echo "</div>";

            echo "
      </div></div>
    </main>";
            $page = null;
          
        
        
    
            
        




 



?>


