<section class="hero hero-page gray-bg padding-small">
      <div class="container">
        <div class="row d-flex">
          <div class="col-lg-9 order-2 order-lg-1">
            <h1>Liên hệ</h1>
          </div>
          <div class="col-lg-3 text-right order-1 order-lg-2">
            <ul class="breadcrumb justify-content-lg-end">
              <li class="breadcrumb-item"><a href="index.php">Trang chủ</a></li>
              <li class="breadcrumb-item active">Liên hệ</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <main class="contact-page">
      <!-- Contact page-->
      <section class="contact">
        <div class="container">
          <header>
            <p class="lead">
              
            </p>
          </header>
          <div class="row">
            <div class="col-md-4">
              <div class="contact-icon">
                <div class="icon icon-street-map"></div>
              </div>
              <h3>Địa chỉ</h3>
              <p>
                123 An Dương Vương<br /> Phường 4 <br />TP Hồ Chí Minh,
                <strong>Việt Nam</strong>
              </p>
            </div>
            <div class="col-md-4">
              <div class="contact-icon">
                <div class="icon icon-support"></div>
              </div>
              <h3>Điện thoại hỗ trợ</h3>
              <p>
                
              </p>
              <p><strong> + 0123456789</strong></p>
            </div>
            <div class="col-md-4">
              <div class="contact-icon">
                <div class="icon icon-envelope"></div>
              </div>
              <h3>Email hỗ trợ</h3>
              <p>
                
              </p>
              <ul class="list-style-none">
                <li>
                  <strong><a href="mailto:">info@dano.com</a></strong>
                </li>
                
              </ul>
            </div>
          </div>
        </div>
      </section>
    </main>