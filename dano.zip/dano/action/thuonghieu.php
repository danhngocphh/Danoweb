<?php require_once 'Pagination2.php'; ?>



<?php

if(isset($_GET['id']))
{
  $id = $_GET['id'];
}else
{
  $id =1;
}

                $rowscheck = mysqli_query($conn,"
                SELECT * FROM trademark WHERE id = '$id'
                ");





                while ( $row = mysqli_fetch_assoc($rowscheck)) {
                  
                       $name = $row['name'];

                  ;
                  # code...
                }



// Hien thi ket qua
        
        echo'<!-- Hero Section-->
    <section class="hero hero-page gray-bg padding-small">
      <div class="container">
        <div class="row d-flex">
          <div class="col-lg-9 order-2 order-lg-1">
            <h1>Đồng hồ '.$name.'</h1>
            <p class="lead text-muted">
              
            </p>
          </div>
          <div class="col-lg-3 text-right order-1 order-lg-2">
            <ul class="breadcrumb justify-content-lg-end">
              <li class="breadcrumb-item"><a href="index.php">Trang chủ</a></li>
              <li class="breadcrumb-item active">Đồng hồ '.$name.'</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <main>
      <div class="container">
        <div class="row">
          <!-- Sidebar-->
          <div class="sidebar col-xl-3 col-lg-4 sidebar">
            
            
            <div class="block">
              <h6 class="text-uppercase">Tìm kiếm nâng cao</h6>
              <div id="slider-snap"></div>
              <form action="action/searchnc.php"  class="jsx-1387603744 search-form"><div class="jsx-1387603744"><div class="jss190"><label class="jss205 jss194 jss199 jss202" data-shrink="false">Tìm theo tên:</label><div class="jss225 jss212 jss216 jss226 jss213"><input name="searchByName" class="jss235 jss220" aria-invalid="false" type="text" value=""></div></br></div><div class="jss190"><label class="jss205 jss194 jss199 jss202" data-shrink="false">Chọn loại đồng hồ:</label><div class="jss225 jss212 jss216 jss226 jss213"><select name= "loaidh" >
                                            <option value="nam">&nbsp;&nbsp;&nbsp;Đồng hồ nam</option>
                                            <option value="nu">&nbsp;&nbsp;&nbsp;Đồng hồ nữ</option>   
                                             <option value="doi">&nbsp;&nbsp;&nbsp;Đồng hồ đôi</option>                                               

                                        </select></br></br></div></div></div><div class="jsx-1387603744"><div class="jsx-1387603744">Tìm theo giá:</div><div class="jss190" style="width: 100px;"><label class="jss205 jss209 jss194 jss199 jss202 jss201" data-shrink="true">Từ</label><div class="jss225 jss212 jss216 jss226 jss213"><input onkeypress=" return isNumberKey(event)" name="searchByPriceFrom" class="jss235 jss220" aria-invalid="false" type="text" value=""></div></div><div class="jss190" style="width: 100px;"><label class="jss205 jss209 jss194 jss199 jss202 jss201" data-shrink="true">Đến</label><div class="jss225 jss212 jss216 jss226 jss213"><input onkeypress=" return isNumberKey(event)" name="searchByPriceTo" class="jss235 jss220" aria-invalid="false" type="text" value=""></div></div></div></br><button tabindex="0" class="jss27 jss1 jss12 jss13 jss15 jss16" type="submit"><span class="jss2">Tìm kiếm</span><span class="jss253"></span></button></form>
              
            </div>
            
            
          
            
            
          </div>
          <div class="products-grid col-xl-9 col-lg-8 sidebar-left">
            
            ';



 // BƯỚC 2: TÌM TỔNG SỐ RECORDS
        $sql2 = "SELECT count(id) as total from product WHERE trademark_id = '$id' ";
        $result2 = mysqli_query ( $conn , $sql2);
        $row2 = mysqli_fetch_assoc($result2);
        $total_records = $row2['total'];



        // BƯỚC 3: TÌM LIMIT VÀ CURRENT_PAGE
        $current_page = isset($_GET['trang']) ? $_GET['trang'] : 1;
        $limit = 9;


        // BƯỚC 4: TÍNH TOÁN TOTAL_PAGE VÀ START
        // tổng số trang

        $total_page = ceil($total_records / $limit);

        // Giới hạn current_page trong khoảng 1 đến total_page
        if ($current_page > $total_page){
            $current_page = $total_page;
        }
        else if ($current_page < 1){
            $current_page = 1;
        }
 
        // Tìm Start
        $start = ($current_page - 1) * $limit;



        // BƯỚC 5: TRUY VẤN LẤY DANH SÁCH TIN TỨC
        // Có limit và start rồi thì truy vấn CSDL lấy danh sách tin tức
 
        echo '<header class="d-flex justify-content-between align-items-start">
              <span class="visible-items"
                >Đồng hồ '.$name.' có <strong>'.$total_records.'</strong> sản phẩm.</span
              >
              
            </header><div class="row">';

           
        

        $sql1 = "SELECT * FROM product WHERE trademark_id = '$id' LIMIT $start, $limit";
        $result1 = mysqli_query ( $conn , $sql1);
        while ($row = mysqli_fetch_assoc($result1))

    				{
    					
    					{
                $chuoi1 = "Devpro";
$chuoi2 = "đào tạo lập trình viên chuyên nghiệp";
//nối $chuoi1 và $chuoi2 bằng dấu chấm '.'
$chuoi3 = $chuoi1." ".$chuoi2;

$url = $current_url.'&id='.$row['id'];
               
                

                            echo '<div class="item col-xl-4 col-md-6">
                <div class="product is-gray">
                  <div
                    class="image d-flex align-items-center justify-content-center"
                  >
                    
                    <img
                      src="images/'.$row["image"].'"
                      alt="product"
                      class="img-fluid"
                    />
                    <div
                      class="hover-overlay d-flex align-items-center justify-content-center"
                    >
                      <div
                        class="CTA d-flex align-items-center justify-content-center"
                      >
                        <a href="cart/cart.php?type=add&product_id='.$row["id"].'&product_qty=1&return_url='.$url.'" class="add-to-cart"
                          ><i class="fa fa-shopping-cart"></i></a
                        ><a href="?catch=chitiet&chitiet='.$row["id"].'" class="visit-product active"
                          ><i class="icon-search"></i>Chi tiết</a
                        >
                      </div>
                    </div>
                  </div>
                  <div class="title">
                    <small class="text-muted">Đồng hồ nam</small
                    ><a href="detail.html">
                      <h3 class="h6 text-uppercase no-margin-bottom">
                        '.$row["name"].'
                      </h3></a
                    ><span class="price text-muted">'.$row["price"].'₫</span>
                  </div>
                </div>
              </div>';

       
        
        			
    					}


        
       
   					}
   					$page = null;

                    echo '</div>';
            $config = [
            'total' => $total_records, 
            'limit' => $limit,
            'full' => true,
            'querystring' => 'trang'
            ];
            $page = new Pagination($config);
            echo $page->getPagination();
            echo "</div>";

            echo "
      </div></div>
    </main>";
            $page = null;
    	    
        
        
    
            
        




 



?>


