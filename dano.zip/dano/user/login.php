<?php
	
	session_start();
	
	function get_user ($username,$password){

			include '../database/DataProvider.php';	
			$conn = OpenCon();
			$passwordm = md5($password );
			$sql = mysqli_query ( $conn ,"SELECT * FROM member WHERE username = '$username' AND password ='$passwordm'");
			if(mysqli_num_rows($sql) == 1)
			{
					
					$row = mysqli_fetch_assoc($sql);
					
					$_SESSION['currId'] = $row['id'];
					$_SESSION['currUser'] = $row['name'];
					$_SESSION['currName'] = $row['username'];
					$_SESSION['currPhone'] = $row['phone'];
					$_SESSION['currAdd'] = $row['address'];
					$_SESSION['currEmail'] = $row['email'];
						if ($row['lockuser'] == '1') {
							
							
       						//  echo '<a href="#" class="btn btn-template wide shop-now"
                 			//  >Tài khoản của bạn đã bị khóa.<i class="icon-bag"> </i
							// ></a>';
							echo "<script> alert('Tài khoản này của bạn đã bị khóa') </script>";
						}
						else
						{
							if($row['roleuser'] == 0)
							{

								// $_SESSION['currAdmin'] = $row['roleuser'];
								// 	header("location:../admin/");
								echo "<script> alert('Tên đăng nhập hoặc mật khẩu không đúng vui lòng kiểm tra lại') </script>";
							}
							else
							{
								
								if($row['roleuser'] == 1)
								{

									// $_SESSION['currNV'] = $row['roleuser'];
									// 	header("location:../admin/index2.php");
									echo "<script> alert('Tên đăng nhập hoặc mật khẩu không đúng vui lòng kiểm tra lại') </script>";
								}
								
							
								else
								{
									header("location:../index.php");
								}
							}
						}

			} else{
					echo "<script> alert('Tên đăng nhập hoặc mật khẩu không đúng vui lòng kiểm tra lại') </script>";
					// echo "<script> alert('$username.$passwordm') </script>";
			}

			

}
?>