﻿<?php session_start(); 
 
    if (isset($_SESSION['currUser'])){
        unset($_SESSION['currUser']); // xóa session login
        Header( "Location: ../index.php" );
    }

    require_once "../../google/config.php";
	unset($_SESSION['access_token']);
	$gClient->revokeToken();
	session_destroy();
    // header('Location: login.php');
    header('Location: ../index.php');
	exit();
?>
