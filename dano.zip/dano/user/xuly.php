<?php
 
    // Nếu không phải là sự kiện đăng ký thì không xử lý
    if (!isset($_POST['username'])){
        die('');
    }
     
    //Nhúng file kết nối với database
    // include('ketnoi.php');
    include '../database/DataProvider.php';	
          
    //Khai báo utf-8 để hiển thị được tiếng việt
    header('Content-Type: text/html; charset=UTF-8');
          
    //Lấy dữ liệu từ file dangky.php
    $username   = addslashes($_POST['username']);
    $password   = md5($_POST['password']);
    $email      = addslashes($_POST['email']);
    $fullname   = addslashes($_POST['fullname']);
    $phone      = addslashes($_POST['phone']);
    $birthday   = addslashes($_POST['birthday']);
    $sex        = addslashes($_POST['sex']);


    

    $conn = OpenCon();
            
    // Kiểm tra tên đăng nhập này đã có người dùng chưa
    // if (mysqli_num_rows(mysqli_query($conn, "SELECT username FROM member WHERE username='$username'"))>0)
    // {
    //     echo "Tên đăng nhập này đã có người dùng. Vui lòng chọn tên đăng nhâp khác khác. <a href='javascript: history.go(-1)'>Trở lại</a>";  
    //     exit;
    
    // } 
    //Kiểm tra email có đúng định dạng hay không
    // if (!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$", $email))
    // {
    //     echo "Email không đứng định dạng. <a href='javascript: history.go(-1)'>Trở lại</a>";

    //     exit;
    // }
          
    //Kiểm tra email đã có người dùng chưa
    // if (mysqli_num_rows(mysqli_query("SELECT email FROM member WHERE email='$email'")) > 0)
    // {
    //     echo "Email này đã có người dùng. Vui lòng chọn Email khác. <a href='javascript: history.go(-1)'>Trở lại</a>";
    //     exit;
    // }
    
    //Lưu thông tin thành viên vào bảng

    // INSERT INTO `member` (`id`, `name`, `email`, `phone`, `address`, `username`, `password`, `role`, `created`, `lock`) VALUES ('4', '{$fullname}', '{$email}', '{$phone}', 'yuy ewewe', '{$username}', '{$password}', '0', '0', '0');


    // @$addmember = mysqli_query("
    //     INSERT INTO 'member' (
    //         'username,
    //         'password,
    //         'email,
    //         'fullname,
    //         'phone,
    //         'birthday,
    //         'sex
    //     )
    //     VALUE (
    //         '{$username}',
    //         '{$password}',
    //         '{$email}',
    //         '{$fullname}',
    //         '{$phone}',
    //         '{$birthday}',
    //         '{$sex}'
    //     )
    // ");

    // $sql = "INSERT INTO `member` (`id`, `name`, `email`, `phone`, `address`, `username`, `password`, `roleuser`, `created`, `lockuser`) VALUES ('4', '{$fullname}', '{$email}', '{$phone}', 'yuy ewewe', '{$username}', '{$password}', '0', '0', '0')"
                     
    $addmember = mysqli_query($conn,"
    INSERT INTO `member` (`name`, `email`, `phone`, `username`, `password`, `roleuser`, `created`, `lockuser`) VALUES ('{$fullname}', '{$email}', '{$phone}', '{$username}', '{$password}', '2', '0', '0');
    ");


    //Thông báo quá trình lưu
    if ($addmember)
    {
        // $conn = OpenCon();
        // $sql = mysqli_query ( $conn ,"SELECT * FROM member WHERE username = '$username'");
        // if(mysqli_num_rows($sql) == 1)
        {
            // $row = mysqli_fetch_assoc($sql);
            // $_SESSION['currUser'] = $row['username'];
            header("location: dangnhap.php");   
        }   
    }
    else
        echo "Có lỗi xảy ra trong quá trình đăng ký. <a href='dangky.php'>Thử lại</a>";
?>