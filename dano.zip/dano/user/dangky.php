<!DOCTYPE HTML>
<html>
    <script type="text/javascript">
                    function checkuser(){
                        var form = document.from;     
                        
                        if(form.username.value == ""){
                            alert("Vui lòng nhập Tên tài khoản");
                            form.username.focus();
                            return false;
                        }
                        if(form.password.value == ""){
                            alert("Vui lòng nhập Mật khẩu");
                            form.password.focus();
                            return false;
                        }
                        if(form.repass.value == ""){
                            alert("Vui lòng nhập lại mật khẩu");
                            form.repass.focus();
                            return false;
                        }
                        if(form.password.value != form.repass.value){
                            alert("Nhập lại mẩu khẩu chưa đúng");
                            form.password.focus();
                            return false;
                        }
                        if(form.name.value == ""){
                            alert("Vui lòng nhập Họ tên");
                            form.name.focus();
                            return false;
                        }
                        if(form.phone.value == ""){
                            alert("Vui lòng nhập Số điện thoại");
                            form.phone.focus();
                            return false;
                        }
                        if(isNaN(form.phone.value)){
                            alert("Số điện thoại không đúng định dạng");
                            form.phone.focus();
                            return false;
                        }
                        if(form.adress.value == ""){
                            alert("Vui lòng nhập Địa chỉ");
                            form.adress.focus();
                            return false;
                        }
                        if(form.email.value == ""){
                            alert("Vui lòng nhập Email");
                            form.email.focus();
                            return false;
                        }
                        if(form.email.value.indexOf('@') == -1){
                            alert("Email không đúng định dạng");
                            form.email.focus();
                            return false;
                        }
                        
                        if(form.email.value.indexOf('@') == 0){
                            alert("Trước @ phải có dữ liệu");
                            form.email.focus();
                            return false;
                        }
                        if(form.email.value.indexOf('@') == form.email.value.length -1  ){
                            alert("Sau @ phải có dữ liệu");
                            form.email.focus();
                            return false;
                        }
                        if(form.email.value.indexOf('.',form.email.value.indexOf('@')) == -1){
                            alert("Sau @ phải có dấu chấm");
                            form.email.focus();
                            return false;
                        }
                        if(form.email.value.indexOf('.') - form.email.value.indexOf('@') == 1){
                            alert("Giữa  @ và dấu châm phải có dữ liệu");
                            form.email.focus();

                        }

                 }   
                </script>

            
    <head>
	<meta http-equiv="content-type" content="text/html" charset="utf-8"/>
    <link rel="stylesheet"  href="abc.css" type="text/css"/>
	<title> Đăng ký </title>
                     <body background="hinh6.jpg">    
            	       <form action="xuly.php" method="POST" name="from"  id="form"  onsubmit="return checkuser()" enctype="">
                                    <h1>ĐĂNG KÝ</h1>	
                                    <div>
                                        <label>Tên tài khoản</label>
                                        <input type="text" name="username"  class="text" id="username"  /></div>
                                    </div>
                                    <div>          
                                        <label >Mật khẩu</label>
                                        <div ><input type="password" name="password"  id="password" pattern="[a-zA-Z0-9\+]{6,24}"  /></div>
                                    </div>
                                    <div >
                                        <label >Nhập lại mật khẩu</label>
                                        <div><input type="password" name="repass" id="repass" pattern="[a-zA-Z0-9\+]{6,24}"  /></div>
                                    </div>
                                                	
                                    <div>
                                    <label>Họ tên</label>
                                        <div><input type="text" name="fullname" id="name"   /></div>
                                    </div>
                                    <div>
                                        <label>Ngày sinh</label>
                                        <div><input type="date" name="birthday"  id="birthday"  /></div>
                                    </div>
                                    <div>
                                        <label>Giới tính</label>
                                    </div>
                                    <div>
                                        <select name= "sex" >
                                            <option value="1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nam</option>
                                            <option value="0">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nữ</option>                                                
                                        </select>
                                    </div>
                                    <div>
                                        <label>Số điện thoại</label>
                                        <div><input type="num" name="phone"  id="phone" pattern="[0-9]{10,11}"  /></div>
                                    </div>
                                    <div>        
                                        <label>Email</label>
                                        <div><input type="email" name="email"  id="email"  /></div>
                                    </div>
                                    <div>&nbsp;</div>
                                    <div><input type="submit" name="ok" value="Đăng ký" class="padding"  id="button" />
                                         <input type="reset" value="Nhập lại" class="padding"  id="button" />
                                    </div>
                                </br>
                                    <a
                      href="dangnhap.php"
                      class="btn btn-template-outlined wide prev"
                    >
                      <i class="fa fa-angle-left"></i>Quay lại đăng nhập</a
                    >
                                </div>
                        </form>
            		</body>
	</head>
</html>
