<?php
    require ("login.php");
    if($_SERVER['REQUEST_METHOD'] == 'POST'){

        $username = $_POST['username'];
        $password = $_POST['password'];
        get_user($username,$password);
    }
    


?>


<?php
    require_once "../../google/config.php";

	if (isset($_SESSION['access_token'])) {
    // header('Location: ../template/index.php');
    header('Location: ../index.php');
		exit();
	}

	$loginURL = $gClient->createAuthUrl();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Đăng nhập</title>
    
    <link rel="stylesheet" href="form .css" type="text/css" />
</head>
<body background="hinh6.jpg">
	<form action='' method='POST'> 
    <h1>ĐĂNG NHẬP</h1>
  <div class="form-group">
    <input  class="form-control" placeholder="Tên đăng nhập" type="text" required="" id="username"  name="username"/>
  </div>
  <div class="form-group">
    <input  class="form-control" placeholder="Mật Khẩu" type="password" required="" id="password" name="password" />
  </div>
  <div class="form-group">
          <button class="btn btn-info" type="submit" value="Đăng nhập" name="dangnhap">Đăng nhập</button> 
  </div>

 
 <div class="dn"><a href="dangky.php" tagret="blank">Nhấp vào đây để đăng ký </a></div>
 <div class="form-group">
          <button class="btn btn-info" type="button" onclick="window.location = '<?php echo $loginURL ?>';" value="Log In With Google" name="">Đăng nhập bằng Google</button> 
  </div>
 </form>
</body>
</html>