<?php session_start(); 
require './database/DataProvider.php';
$conn = OpenCon();
$current_url = $_SERVER['REQUEST_URI'];
?>


<?php
	// session_start();

	// if (!isset($_SESSION['access_token'])) {
  //   // header('Location: login.php');
	// 	header('Location: ../index.php');
	// 	exit();
	// }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Dano - Website bán đồng hồ</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="robots" content="all,follow" />
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="css/font-awesome.min.css" />
    <!-- Bootstrap Select-->
    <link rel="stylesheet" href="css/bootstrap-select.min.css" />
    <!-- Price Slider Stylesheets -->
    <link rel="stylesheet" href="css/nouislider.css" />
    <!-- Custom font icons-->
    <link rel="stylesheet" href="fonts/custom-fonticons.css" />
    <!-- Google fonts - Poppins-->
    <link rel="stylesheet" href="./fonts/Poppins.css" />
    <!-- owl carousel-->
    <link rel="stylesheet" href="css/owl.carousel.css" />
    <link rel="stylesheet" href="css/owl.theme.default.css" />
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet" />
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css" />
    <!-- Favicon-->
    
    <!-- Modernizr-->
    <script src="js/modernizr.custom.79639.js"></script>
    <!-- Tweaks for older IEs-->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script
    ><![endif]-->
  </head>
  <body>
    <!-- navbar-->
    <header class="header">
      <!-- Tob Bar-->
      <div class="top-bar">
        <div class="container-fluid">
          <div class="row d-flex align-items-center">
            <div class="col-lg-6 hidden-lg-down text-col">
              <ul class="list-inline">
                <li class="list-inline-item">
                  <i class="icon-telephone"></i>0123456789
                </li>
                <li class="list-inline-item">
                  Miễn phí vận chuyển cho đơn hàng từ 500.000 VNĐ
                </li>
              </ul>
            </div>
            <div class="col-lg-6 d-flex justify-content-end">
              <!-- Language Dropdown-->
              
              <!-- Currency Dropdown-->
              <div class="dropdown show">
                <li class="list-inline-item">
                  <?php 
       if (isset($_SESSION['currUser']))
       {
           echo '
            Xin chào <a id="userdetails" href="./acount.php" class="user-link">'.$_SESSION['currUser'].' </a> | ';
           echo '&nbsp<a href="user/logout.php">Đăng xuất</a>';
       }
       else
       {
              if (isset($_SESSION['familyName']))
              {
                  echo 'Xin chào '.$_SESSION['familyName'].'  | ';
                  echo '&nbsp<a href="user/logout.php">Đăng xuất</a>';


                  $username   = $_SESSION['givenName'];
                  $password   = md5($_SESSION['id']);
                  $email      = $_SESSION['email'];
                  $fullname   = $_SESSION['givenName'].' '.$_SESSION['familyName'];
                  $phone      = "";
                  $sex        = $_SESSION['gender'];
                  // $string = $_SESSION['email'];
                  // $pass = md5($_SESSION['id']);
                  // $conn = OpenCon();
                  // $sql2 = mysqli_query ( $conn ,"SELECT * FROM member WHERE email = '$_SESSION['email']'");
                  $sql3 = mysqli_query ( $conn ,"SELECT email FROM member Where email = '$email' ");
                  // echo "<script> alert($sql3) </script>";
                  if (mysqli_num_rows($sql3) == 0)
                  {
                    // echo "<script> alert('dsdsdsdsdsdsd') </script>";
                    $addmember = mysqli_query($conn,"
                    INSERT INTO `member` (`name`, `email`, `phone`, `username`, `password`, `roleuser`, `created`, `lockuser`) VALUES ('{$fullname}', '{$email}', '{$phone}', '{$username}', '{$password}', '2', '0', '0');
                    ");
                  }
                  $sql4 = mysqli_query ( $conn ,"SELECT * FROM member Where email='$email'");
                  $row = mysqli_fetch_assoc($sql4);
                  $_SESSION['currId'] = $row['id'];
                  $_SESSION['User'] = $row['name'];
                  $_SESSION['currUser'] = $row['name'];
                  $_SESSION['currName'] = $row['username'];
                  $_SESSION['Phone'] = $row['phone'];
                  $_SESSION['Add'] = $row['address'];
                  $_SESSION['currEmail'] = $row['email'];
              }
              else
              {
                  echo' <a id="userdetails" href="./user/dangnhap.php" class="user-link"
                  >Đăng nhập</a>   |   <a id="userdetails" href="./user/dangky.php" class="user-link"
                  >Đăng ký</a>';
              }
       }
?>
                </li>
              </div>
            </div>
          </div>
        </div>
      </div>
      <nav class="navbar navbar-expand-lg">
        <div class="search-area">
          <div
            class="search-area-inner d-flex align-items-center justify-content-center"
          >
            <div class="close-btn"><i class="icon-close"></i></div>
            <form action="#">
              <div class="form-group">
                <input
                  type="search"
                  name="search"
                  id="search"
                  placeholder="Nhập tên sản phẩm bạn muốn tìm"
                />
                <button type="submit" class="submit">
                  <i class="icon-search"></i>
                </button>
              </div>
            </form>
          </div>
        </div>
        <div class="container-fluid">
          <!-- Navbar Header  --><a href="index.php" class="navbar-brand"
            ><img src="img/logo.png" alt="..."
          />  DANO</a>
          <button
            type="button"
            data-toggle="collapse"
            data-target="#navbarCollapse"
            aria-controls="navbarCollapse"
            aria-expanded="false"
            aria-label="Toggle navigation"
            class="navbar-toggler navbar-toggler-right"
          >
            <i class="fa fa-bars"></i>
          </button>
          <!-- Navbar Collapse -->
          <div id="navbarCollapse" class="collapse navbar-collapse">
            <ul class="navbar-nav mx-auto">
              
              <li class="nav-item">
                <a href="?catch=men" class="nav-link">đồng hồ nam</a>
              </li>
              <li class="nav-item">
                <a href="?catch=women" class="nav-link">đồng hồ nữ</a>
              </li>
              <li class="nav-item">
                <a href="?catch=couple" class="nav-link">đồng hồ đôi</a>
              </li>
              <!-- Megamenu-->
              <li class="nav-item dropdown">
                <a
                  id="navbarDropdownMenuLink"
                  href="http://example.com"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                  class="nav-link"
                  >thương hiệu<i class="fa fa-angle-down"></i
                ></a>
                <ul
                  aria-labelledby="navbarDropdownHomeLink"
                  class="dropdown-menu"
                >

                <?php


                $rowscheck = mysqli_query($conn,"
                SELECT * FROM trademark WHERE hide = 0
                ");

                while ( $row = mysqli_fetch_assoc($rowscheck)) {
                  echo ' 

                  <li>
                    <a href="?catch=thuonghieu&id='.$row['id'].'" class="dropdown-item">'.$row['name'].'</a>
                  </li>


                  ';
                  # code...
                }

                   
                 

                ?>
                  
                </ul>
              </li>
              
              <!-- Multi level dropdown end-->
              <li class="nav-item">
                <a href="?catch=contact" class="nav-link">liên hệ</a>
              </li>
            </ul>
            <div
              class="right-col d-flex align-items-lg-center flex-column flex-lg-row"
            >
              <!-- Search Button-->
              <div class="search"><i class="icon-search"></i></div>
              <!-- User Not Logged - link to login page-->
              <div class="user">










               
              </div>
              <!-- Cart Dropdown-->
              <div class="cart dropdown show">
                <a
                  id="cartdetails"
                  href="https://example.com"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                  class="dropdown-toggle"
                  ><i class="icon-cart"></i>
                  <div class="cart-no">
                    <?php 
                        $sl = 0;
                        if (isset($_SESSION["products"]))
                        {
                          // $dem=0;
                          foreach ($_SESSION["products"] as $cart_itm)
                          {
                              $product_id = $cart_itm["id"];
                              $sql1 = "SELECT * FROM product WHERE id IN ('$product_id') LIMIT 1";
                              
                              // $results1 = DataProvider::executeQuery($sql1);

                              // $conn = OpenCon();
                              $results1 = mysqli_query ( $conn ,$sql1);
                              
                              $obj = mysqli_fetch_array($results1);
                              $sl += $cart_itm["qty"]; 
                              // echo $sl;
                          }
                          echo $sl;
                        }
                        // echo $cart_itm["qty"];
                        else
                        echo("0");
                    ?>
                  </div></a
                ><a href="cart.html" class="text-primary view-cart"
                  >View Cart</a
                >
                <div aria-labelledby="cartdetails" class="dropdown-menu">
                  <!-- cart item-->
               <?php 

      if((!isset($_SESSION['currUser'])) && (!isset($_SESSION['familyName'])))
      {
        echo 'Vui lòng đăng nhập ';
      }
      else
      {
            if(isset($_SESSION["products"]))
            // if(1 == 1)
            {
                $current_url = $_SERVER['REQUEST_URI'];
                $total = 0;
              echo '<div class="dropdown-item cart-product">';
                $cart_items = 0;
                foreach ($_SESSION["products"] as $cart_itm)
                {
                  $product_id = $cart_itm["id"];
                  $sql1 = "SELECT * FROM product WHERE id IN ('$product_id') LIMIT 1";
                  
                  // $results1 = DataProvider::executeQuery($sql1);

                  // $conn = OpenCon();
                  $results1 = mysqli_query ( $conn ,$sql1);
                  
                  $obj = mysqli_fetch_array($results1);


                  echo '</br>
                            <div class="d-flex align-items-center">
                              
                              <div class="img">
                                <img
                                  src="images/'.$obj['image'].'"
                                  alt="..."
                                  class="img-fluid"
                                />
                              </div>
                              <div class="details d-flex justify-content-between">
                                <div class="text">
                                  <a href="?catch=chitiet&chitiet='.$obj['id'].'"><strong>'.$cart_itm["name"].'</strong></a
                                  ><small>Số lượng: '.$cart_itm["qty"].' </small
                                  ><span class="price"> Giá: '.number_format($cart_itm["price"], 0, ',', '.').' đ</span>
                                </div>
                                <a href="cart/cart.php?removep='.$cart_itm["id"].'&return_url='.$current_url.'"  class="delete" onclick="return confirm("Bạn có chắc chắn xóa không ?")"
                                  ><i class="fa fa-trash-o"></i
                                ></a>
                              </div>
                            </div>
                          
                          ';
                          $subtotal = ($cart_itm["price"]*$cart_itm["qty"]);
                          $total = ($total + $subtotal);
              }

              echo '</div>
              <!-- total price-->
                          <div
                            class="dropdown-item total-price d-flex justify-content-between"
                          >
                            <span>Tổng</span
                            ><strong class="text-primary">'.number_format($total, 0, ',', '.').' đ</strong>
                          </div>
                          <!-- call to actions-->
                          <div class="dropdown-item CTA d-flex">
                            <a href="?catch=cart" class="btn btn-template wide"
                              >Giỏ hàng</a
                            ><a href="?catch=checkout" class="btn btn-template wide"
                              >Mua hàng</a
                            >
                          </div>';





                    
                  
                
            }else{
                echo 'Giỏ hàng trống';
                
            }
      }
?>
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </nav>
    </header>
    <script>
function confirmDelete(delUrl) {
  if (confirm("Bạn có chắc chắn xóa không ?")) {
    document.location = delUrl;
  }
}
</script>