<!DOCTYPE html>

<html lang="en">
<body>
<!-- Footer-->
    <footer class="main-footer">
      <!-- Service Block-->
      <div class="services-block">
        <div class="container">
          <div class="row">
            <div
              class="col-lg-4 d-flex justify-content-center justify-content-lg-start"
            >
              <div class="item d-flex align-items-center">
                <div class="icon"><i class="icon-truck"></i></div>
                <div class="text">
                  <h6 class="no-margin text-uppercase">
                    Miễn phí vận chuyển &amp; đổi trả
                  </h6>
                  <span>Miễn phí vận chuyển từ 500.000 VNĐ </span>
                </div>
              </div>
            </div>
            <div class="col-lg-4 d-flex justify-content-center">
              <div class="item d-flex align-items-center">
                <div class="icon"><i class="icon-coin"></i></div>
                <div class="text">
                  <h6 class="no-margin text-uppercase">Đảm bảo hoàn tiền</h6>
                  <span>Đảm bảo hoàn tiền trong 30 ngày</span>
                </div>
              </div>
            </div>
            <div class="col-lg-4 d-flex justify-content-center">
              <div class="item d-flex align-items-center">
                <div class="icon"><i class="icon-headphones"></i></div>
                <div class="text">
                  <h6 class="no-margin text-uppercase">0123456789</h6>
                  <span>24/7 Hỗ trợ có sẵn</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Main Block -->
      <div class="main-block">
        <div class="container">
          <div class="row">
            <div class="info col-lg-4">
              <div class="logo">
                <img src="img/logo.png" alt="..." />
              </div>
              <p></p>
              <ul class="social-menu list-inline">
                <li class="list-inline-item">
                  <a href="#" target="_blank" title="twitter"
                    ><i class="fa fa-twitter"></i
                  ></a>
                </li>
                <li class="list-inline-item">
                  <a href="#" target="_blank" title="facebook"
                    ><i class="fa fa-facebook"></i
                  ></a>
                </li>
                <li class="list-inline-item">
                  <a href="#" target="_blank" title="instagram"
                    ><i class="fa fa-instagram"></i
                  ></a>
                </li>
                <li class="list-inline-item">
                  <a href="#" target="_blank" title="pinterest"
                    ><i class="fa fa-pinterest"></i
                  ></a>
                </li>
                <li class="list-inline-item">
                  <a href="#" target="_blank" title="vimeo"
                    ><i class="fa fa-vimeo"></i
                  ></a>
                </li>
              </ul>
            </div>
            <div class="site-links col-lg-2 col-md-6">
              <h5 class="text-uppercase">Dano</h5>
              <ul class="list-unstyled">
                <li><a href="?catch=men">Đồng hồ nam</a></li>
                <li><a href="?catch=women">Đồng hồ nữ</a></li>
                <li><a href="?catch=couple">Đồng hồ đôi</a></li>
                <li><a href="?catch=contact">Liên hệ</a></li>
                
              </ul>
            </div>
            
            <div class="newsletter col-lg-4">
              <h5 class="text-uppercase">Nhận thông tin khuyến mãi</h5>
              <p>
                
              </p>
              <form action="#" id="newsletter-form">
                <div class="form-group">
                  <input
                    type="email"
                    name="subscribermail"
                    placeholder="Địa chỉ email"
                  />
                  <button type="submit">
                    <i class="fa fa-paper-plane"></i>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <div class="copyrights">
        <div class="container">
          <div class="row d-flex align-items-center">
            <div class="text col-md-6">
              <p>
                &copy; 2018<a href="#" target="_blank"
                  >Dano
                </a>
                All rights reserved.
              </p>
            </div>
            <div class="payment col-md-6 clearfix">
              <ul class="payment-list list-inline-item pull-right">
                <li class="list-inline-item">
                  <img src="img/visa.svg" alt="..." />
                </li>
                <li class="list-inline-item">
                  <img src="img/mastercard.svg" alt="..." />
                </li>
                <li class="list-inline-item">
                  <img src="img/paypal.svg" alt="..." />
                </li>
                <li class="list-inline-item">
                  <img src="img/western-union.svg" alt="..." />
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </footer>
    
    <!-- JavaScript files-->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/owl.carousel2.thumbs.min.js"></script>
    <script src="js/bootstrap-select.min.js"></script>
    <script src="js/nouislider.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/masonry.pkgd.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <!-- masonry -->
    <script>
      $(function() {
        var $grid = $('.masonry-wrapper').masonry({
          itemSelector: '.item',
          columnWidth: '.item',
          percentPosition: true,
          transitionDuration: 0
        });

        $grid.imagesLoaded().progress(function() {
          $grid.masonry();
        });
      });
    </script>
    <!-- Main Template File-->
    <script src="js/front.js"></script>
  </body>


</html>