
<?php
if(isset($_GET['action']))
   {
        if($_GET['action']=='em')
        {
            include 'action/employeemanager.php';
        }
        if($_GET['action']=='item')
        {
            include 'action/itemmanagement.php';
        }
        if($_GET['action']=='invoice')
        {
            include 'action/invoicemanagement.php';
        }
        if($_GET['action']=='tran')
        {
            include 'action/transaction.php';
        }
        if($_GET['action']=='acc')
        {
            include 'action/accountsettings.php';
        }
        if($_GET['action']=='adduser')
        {
            include 'action/adduser.php';
        }
        if($_GET['action']=='cpass')
        {
            include 'action/changepassword.php';
        }
        if($_GET['action']=='assandcom')
        {
            include 'action/assessandcomment.php';
        }
        if($_GET['action']=='additem')
        {
            include 'action/additem.php';
        }
        if($_GET['action']=='updateitem')
        {
            include 'action/updateitem.php';
        }
        if($_GET['action']=='ifcu')
        {
            include 'action/customerinformation.php';
        }
        if($_GET['action']=='inp')
        {
            include 'action/inp.php';
        }
        if($_GET['action']=='handleinp')
        {
            include 'action/handleinp.php';
        }
        if($_GET['action']=='oabd')
        {
            include 'action/oabd.php';
        }
        if($_GET['action']=='tip')
        {
            include 'action/tip.php';
        }
        if($_GET['action']=='feedback')
        {
            include 'action/feedback.php';
        }
        if($_GET['action']=='feedbackdata')
        {
            include 'action/feedbackdata.php';
        }
        if($_GET['action']=='repfb')
        {
            include 'action/repfb.php';
        }
        if($_GET['action']=='ansfb')
        {
            include 'action/ansfb.php';
        }
        if($_GET['action']=='trade')
        {
            include 'action/trademark.php';
        }
        if($_GET['action']=='addtrade')
        {
            include 'action/addtrade.php';
        }
        if($_GET['action']=='updatetrade')
        {
            include 'action/updatetrade.php';
        }

        




        



   }
   else{
      

    include 'action/dashboard.php';
}
?>