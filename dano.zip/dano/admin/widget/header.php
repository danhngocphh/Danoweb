<!DOCTYPE html>
<html lang="en">

<head>
    
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
  
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>Dano Admin







    </title>



</head>

<body class="animsition">
    <div class="page-wrapper">
        
        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="img/dano.png" height="50" width="120" alt="Dano Admin" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li>
                            <a class="js-arrow" href="index.php">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                            
                        </li>
                         <li>
                            <a class="js-arrow" href="index.php?action=trade">
                                <i class="fa fa-cubes" aria-hidden="true"></i>Trademark</a>
                            
                        </li>

                        <?php

                        if($_SESSION['role'] == 0)

                        echo '


                        <li>
                            <a class="js-arrow" href="#">
                             <i class="fas fa-users"></i>Employee manager</a>
                                <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li>
                                    <a href="?action=adduser">Add User</a>
                                </li>
                                <li>
                                    <a href="?action=em">Member Data</a>
                                </li>
                                
                            </ul>
                        </li>


                        ';


                        ?>


                        
                        <li>
                            <a class="js-arrow" href="#">
                             <i class="fas fa-cubes"></i>Item Management</a>
                                <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li>
                                    <a href="?action=additem">Add Item</a>
                                </li>
                                <li>
                                    <a href="?action=item">Data Table</a>
                                </li>
                                
                            </ul>
                        </li>
                        <li>
                            <a class="js-arrow" href="#">
                             <i class="fas fa-table"></i>Invoice Management</a>
                                <ul class="list-unstyled navbar__sub-list js-sub-list">
                                     <li>

                                    <a href="?action=inp">Invoice Needs Processing</a>
                                </li>

                                <li>

                                    <a href="?action=oabd">Orders Are Being Delivered
</a>
                                </li>

                                
                                    

                                <li>

                                    <a href="?action=invoice">Data Order Table</a>
                                </li><li>

                                    <a href="?action=tip">Payment Needs Processing
</a>
                                </li>
                                <li>
                                    <a href="?action=tran">Data Transaction Table</a>
                                </li>
                                
                            </ul>
                        </li>
                        <li>
                            <a class="js-arrow" href="#">   
                             <i class="fa fa-star"></i>Feedback</a>   
                             <ul class="list-unstyled navbar__sub-list js-sub-list">
                                     <li>

                                    <a href="?action=feedback">Unviewed Feedback</a>
                                </li>

                                <li>

                                    <a href="?action=feedbackdata">Feedback Data
</a>
                                </li>

                                
                                    

                                <li>

                                    <a href="?action=repfb">Reply Feedback</a>
                                </li>                           
                            </ul>
                        </li>


                        
                        
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <form class="form-header" action="" method="POST">
                                
                            </form>
                            <div class="header-button">
                                <div class="noti-wrap">

                                    <?php

                                    echo'



                                    
                                    
                                   
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="images/icon/avatar-13.png" alt="avatar" />
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#">'. $_SESSION['fullname'] .'</a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                        <img src="images/icon/avatar-13.png" alt="avatar" />
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#">'. $_SESSION['fullname'] .'</a>
                                                    </h5>
                                                    <span class="email">'. $_SESSION['email'] .'</span>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="?action=acc&user='. $_SESSION['username'] .'">
                                                        <i class="zmdi zmdi-account"></i>Account Settings</a>
                                                </div>
                                                <div class="account-dropdown__item">
                                                    <a href="?action=cpass&user='. $_SESSION['username'] .'">
                                                        <i class="zmdi zmdi-settings"></i>Change Password</a>
                                                </div>
                                                
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="action/logout.php" >
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>';

                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        