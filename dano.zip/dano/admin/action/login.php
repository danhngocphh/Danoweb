
<!------ Include the above in your HEAD tag ---------->

<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/login.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->

    <!-- Icon -->
    <div class="fadeIn first"><br><br>
      <img src="img/dano01.png" height="50"  id="icon" alt="User Icon" /><br>
    </div><br><br>


    <style>


h6 {
  color: red;
 
}
</style>
<?php

if (isset($_SESSION['fail']))
{
  
   echo "<h6>Failed to login. Please try again.</h6>";
}


?>
    <!-- Login Form -->
    <form method="POST" action="action/log.php">
      <input type="text" id="user" class="fadeIn second" name="user" placeholder="Username" required="">
      <input type="password" id="password" class="fadeIn third" name="pass" placeholder="Password" required="">
      <input type="submit" class="fadeIn fourth" value="Log In">
    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="#"></a>
    </div>

  </div>
</div>




