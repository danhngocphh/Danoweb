    <style>


h6 {
  color: green;
 
}
</style>

 <?php

if(isset($_GET['id']))
   {
        $id = $_GET['id'];
        



   

            include 'db_connnection.php';
            $conn = OpenCon();

        
        

                $rows = mysqli_query($conn,"
                select * from trademark where id = '$id' 
                ");
            
        
            $rowsif = mysqli_fetch_assoc($rows);

            
            $name = $rowsif['name'];
           
            CloseCon($conn);    
            

            


        }

            
                
                    
                
        
    
       
            


           

   echo '<div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>Update Trade</strong>
                                    </div>
                                    <form action="action/handle.php?action=updatetrade&id='.$id.'" method="post" class="form-horizontal">';

                                   

                                   

                                    echo '<div class="card-body card-block">



                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label">Trademark ID: </label>
                                            ['.$id.']
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label">Trademark Name:</label>
                                            <input type="text" id="inputSuccess2i" name="name" class="form-control-success form-control" value="'. $name .'" >
                                        </div>
                                       
                        

                                        
                                        ';
                                    
                                    echo '
                                        <div class="form-actions form-group">
                                                <button type="submit" class="btn btn-success btn-sm">Update</button>
                                            </div>
                                    </div> 
                                    </form>
                                </div>
                            </div>
                                <!-- END DATA TABLE -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>










   ';


      




 ?>

 