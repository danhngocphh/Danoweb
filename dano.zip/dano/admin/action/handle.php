 <?php
        session_start();
        


        if($_GET['action'] == 'updateacc')
        {
            $user = $_GET['user'];
            $name = $_POST['fullname'];
            $email = $_POST['email'];
            $phone = $_POST['phone'];
            $address = $_POST['address'];
           
            $role = $_POST['role'];

            include 'db_connnection.php';
            $conn = OpenCon();
            $rows = mysqli_query($conn,"
            UPDATE member SET email ='$email',name='$name',phone='$phone',address='$address',roleuser ='$role' WHERE username = '$user'
            ");

            $_SESSION['updateaccss'] = 1;




           


            header("Location: " . $_SERVER["HTTP_REFERER"]);


        }

        if($_GET['action'] == 'updatetrade')
        {
            $id = $_GET['id'];
            $name = $_POST['name'];
            
            include 'db_connnection.php';
            $conn = OpenCon();
            $rows = mysqli_query($conn,"
            UPDATE trademark SET name='$name' WHERE id = '$id'
            ");

            $_SESSION['updateaccss'] = 1;




           


            header("Location: ../?action=trade");


        }
        if($_GET['action'] == 'updateitem')
        {
            $iditem = $_GET['iditem'];
            $watchname = $_POST['watchname'];
            $catalog_id = $_POST['catalog_id'];
            $price = $_POST['price'];
            $discount = $_POST['amount'];
            $image = $_POST['image'];
            $trademark_id = $_POST['trademark'];
             $total = $_POST['total'];
             $description = $_POST['description'];
            $ennergy = $_POST['ennergy'];
            $strap_material = $_POST['strap_material'];
            $glass_material = $_POST['glass_material'];
            $face_shape = $_POST['face_shape'];
            $size_face = $_POST['size_face'];
            $color_face = $_POST['color_face'];
            $waterproof = $_POST['waterproof'];
            $origin = $_POST['origin'];

include 'db_connnection.php';
            $conn = OpenCon();
                $rowscheck = mysqli_query($conn,"
                SELECT * FROM trademark WHERE id = '$trademark_id'
                ");

                while ( $row = mysqli_fetch_assoc($rowscheck)) {
                  $trademark = $row['name'];
                  # code...
                }
           

            
            $rows = mysqli_query($conn,"
            UPDATE product SET name ='$watchname', catalog_id ='$catalog_id',price='$price',discount='$discount',image ='$image', trademark = '$trademark', trademark_id = '$trademark_id', total = '$total',description ='$description', ennergy ='$ennergy',strap_material='$strap_material',glass_material ='$glass_material', face_shape ='$face_shape',size_face='$size_face',color_face ='$color_face', waterproof ='$waterproof',origin='$origin' WHERE id = '$iditem'
            ");

            $_SESSION['updateitemss'] = 1;


           


            header("Location: ../?action=item");

        }

        if($_GET['action'] == 'adduser')
        {
            $username = $_POST['username'];
            $name = $_POST['name'];
            $email = $_POST['email'];
            $phone = $_POST['phone'];
            $address = $_POST['address'];
             $role = $_POST['role'];
             $password = md5($_POST['password']);


            include 'db_connnection.php';
            $conn = OpenCon();
            $rowscheck = mysqli_query($conn,"
            SELECT * FROM member WHERE username = '$username'
            ");
            if(mysqli_num_rows($rowscheck) > 0)
            {
                 $_SESSION['adduserss'] = 0;
                 header("Location: " . $_SERVER["HTTP_REFERER"]);
                 die();    

            }else{

                $rows = mysqli_query($conn,"
                INSERT INTO member( username, roleuser, password, email, name, phone, address) VALUES ('$username','$role','$password','$email','$name','$phone','$address')");
                $_SESSION['adduserss'] = 1;

            }


            


           


            header("Location: " . $_SERVER["HTTP_REFERER"]);

        }
        if($_GET['action'] == 'additem')
        {
            $name = $_POST['name'];
            $catalog_id = $_POST['catalog_id'];
            $price = $_POST['price'];
            $discount = $_POST['discount'];
            $image_link = $_POST['image_link'];
            $trademark_id = $_POST['trademark'];
            $total = $_POST['total'];
            $description = $_POST['description'];
            $ennergy = $_POST['ennergy'];
            $strap_material = $_POST['strap_material'];
            $glass_material = $_POST['glass_material'];
            $face_shape = $_POST['face_shape'];
            $size_face = $_POST['size_face'];
            $color_face = $_POST['color_face'];
            $waterproof = $_POST['waterproof'];
            $origin = $_POST['origin'];
            


            include 'db_connnection.php';
            $conn = OpenCon();

            $rowscheck = mysqli_query($conn,"
                SELECT * FROM trademark WHERE id = '$trademark_id'
                ");

                while ( $row = mysqli_fetch_assoc($rowscheck)) {
                  $trademark = $row['name'];
                  # code...
                }


           

                $rows = mysqli_query($conn,"
                INSERT INTO product( name, catalog_id, price, discount, image, trademark, trademark_id, total, description, ennergy, strap_material, glass_material, face_shape, size_face, color_face, waterproof, origin) VALUES ('$name','$catalog_id','$price','$discount','$image_link','$trademark','$trademark_id','$total','$description','$ennergy','$strap_material','$glass_material','$face_shape','$size_face','$color_face','$waterproof','$origin')");
                $_SESSION['additemss'] = 1;

            


            


            header("Location: " . $_SERVER["HTTP_REFERER"]);


           

        }

        if($_GET['action'] == 'addtrade')
        {
            $name = $_POST['name'];
            
            


            include 'db_connnection.php';
            $conn = OpenCon();
           

                $rows = mysqli_query($conn,"
                INSERT INTO trademark( name ) VALUES ('$name')");
                $_SESSION['addtradess'] = 1;

            


            


            header("Location: ../?action=trade");


           

        }


        if($_GET['action'] == 'ansfb')
        {
            $feedback_id = $_GET['idfeedback'];
            $nameuser = $_GET['nameuser'];
            $userid = $_GET['idmember'];
            $content = 'Thanks for your feedback, '.$nameuser. '. '.$_POST["reply"];
            $date = date("Y-m-d");
            $namemem = $_SESSION['fullname'];
            
            


            include 'db_connnection.php';
            $conn = OpenCon();

            $rows1 = mysqli_query($conn,"
            UPDATE feedback SET status = 1 WHERE id = '$feedback_id'
            ");
           

                $rows = mysqli_query($conn,"
                INSERT INTO reply_feedback( feedback_id, content, created, member_id, member_name ) VALUES ('$feedback_id','$content','$date', '$userid', '$namemem')");
                

            


            


                        header("Location: ../?action=feedback" );



           

        }

        if($_GET['action'] == 'lockuser')
        {
            $user = $_GET['user'];
            

            include 'db_connnection.php';
            $conn = OpenCon();
            $rows = mysqli_query($conn,"
            UPDATE member SET lockuser = 1  WHERE username = '$user'
            ");

            $_SESSION['lockaccss'] = 1;


           


            header("Location: " . $_SERVER["HTTP_REFERER"]);

        }
        if($_GET['action'] == 'handleinp')
        {
            $id = $_GET['id'];
            
            $data = $_POST['data'];
            

            include 'db_connnection.php';
            $conn = OpenCon();
            $rows = mysqli_query($conn,"
            UPDATE detail_order SET data='$data', status = 2  WHERE id = '$id'
            ");

            


           


            header("Location: ../?action=inp" );

        }

        if($_GET['action'] == 'changepass')
        {
            $user = $_GET['user'];

            include 'db_connnection.php';
            $conn = OpenCon();
            $rowscheck = mysqli_query($conn,"
            SELECT * FROM member WHERE username = '$user'
            ");
            $row = mysqli_fetch_assoc($rowscheck);




            
            $oldpassword = md5($_POST['oldpassword']);
            $newpassword = md5($_POST['newpassword']);
            $renewpassword = md5($_POST['renewpassword']);

            if ( $newpassword != $renewpassword) {

                 $_SESSION['repassfail'] = 1;


                # code...
            }else{
               if ($oldpassword != $row['password'])
               {
                    $_SESSION['odlpassfail'] = 1;
               }else{

                 $rows = mysqli_query($conn,"
            UPDATE member SET password='$newpassword' WHERE username = '$user'
            ");
                 $_SESSION['uppassss'] = 1;
               }

            }
            

            
           

            


           


            header("Location: " . $_SERVER["HTTP_REFERER"]);

        }

        if($_GET['action'] == 'handleoabd')
        {
            $id = $_GET['id'];
            
            
            

            include 'db_connnection.php';
            $conn = OpenCon();
            $rows = mysqli_query($conn,"
            UPDATE detail_order SET status = 1 WHERE id = '$id'
            ");

            


           


            header("Location: ../?action=oabd" );

        }
        if($_GET['action'] == 'handletip')
        {
            $id = $_GET['id'];
            
            
            

            include 'db_connnection.php';
            $conn = OpenCon();

            $rowscheck = mysqli_query($conn,"
            SELECT * FROM detail_order WHERE transaction_id = '$id'
            ");
            while($row = mysqli_fetch_assoc($rowscheck))
            {
                $product_id = $row['product_id'];
                $qty = $row['qty'];
                $rowscheck2 = mysqli_query($conn,"
                SELECT * FROM product WHERE id = '$product_id'");
                while ($row2 = mysqli_fetch_assoc($rowscheck2)) {
                    # code...
                    $tam = $row2['total'] - $qty;
                    $update = mysqli_query($conn,"
                    UPDATE product SET total = '$tam' WHERE id = '$product_id'
                    ");

                     
                }


            }


            $rows = mysqli_query($conn,"
            UPDATE transaction SET status = 1 WHERE id = '$id'
            ");
            $rows2 = mysqli_query($conn,"
            UPDATE detail_order SET status = 1 WHERE transaction_id = '$id'
            ");

             $tam = $obj['total'] - $cart_itm["qty"];

            


           


            header("Location: ../?action=tip" );

        }

        if($_GET['action'] == 'handlefeedback')
        {
            $id = $_GET['id'];
            
            
            

            include 'db_connnection.php';
            $conn = OpenCon();
            $rows = mysqli_query($conn,"
            UPDATE feedback SET status = 1 WHERE id = '$id'
            ");
            

            


           


            header("Location: ../?action=feedback" );

        }


        if($_GET['action'] == 'unlockuser')
        {
            $user = $_GET['user'];
            

            include 'db_connnection.php';
            $conn = OpenCon();
            $rows = mysqli_query($conn,"
            UPDATE member SET lockuser = 0  WHERE username = '$user'
            ");

            $_SESSION['unlockaccss'] = 1;


           


            header("Location: " . $_SERVER["HTTP_REFERER"]);

        }

        if($_GET['action'] == 'hideitem')
        {
            $id = $_GET['id'];
            

            include 'db_connnection.php';
            $conn = OpenCon();
            $rows = mysqli_query($conn,"
            UPDATE product SET hide = 1  WHERE id = '$id'
            ");

            $_SESSION['hideitemss'] = 1;


           


            header("Location: " . $_SERVER["HTTP_REFERER"]);

        }
        if($_GET['action'] == 'hidetrade')
        {
            $id = $_GET['id'];
            

            include 'db_connnection.php';
            $conn = OpenCon();
            $rows = mysqli_query($conn,"
            UPDATE trademark SET hide = 1  WHERE id = '$id'
            ");

            $_SESSION['hideitemss'] = 1;


           


            header("Location: " . $_SERVER["HTTP_REFERER"]);

        }

        if($_GET['action'] == 'hidefeedback')
        {
            $id = $_GET['id'];
            

            include 'db_connnection.php';
            $conn = OpenCon();
            $rows = mysqli_query($conn,"
            UPDATE feedback SET hide = 1  WHERE id = '$id'
            ");

            


           


            header("Location: " . $_SERVER["HTTP_REFERER"]);

        }

        if($_GET['action'] == 'hidereplyfeedback')
        {
            $id = $_GET['id'];
            

            include 'db_connnection.php';
            $conn = OpenCon();
            $rows = mysqli_query($conn,"
            UPDATE reply_feedback SET hide = 1  WHERE id = '$id'
            ");

            


           


            header("Location: " . $_SERVER["HTTP_REFERER"]);

        }

        if($_GET['action'] == 'unhideitem')
        {
            $id = $_GET['id'];
            

            include 'db_connnection.php';
            $conn = OpenCon();
            $rows = mysqli_query($conn,"
            UPDATE product SET hide = 0  WHERE id = '$id'
            ");

            $_SESSION['unhideitemss'] = 1;


           


            header("Location: " . $_SERVER["HTTP_REFERER"]);

        }

         if($_GET['action'] == 'unhidetrade')
        {
            $id = $_GET['id'];
            

            include 'db_connnection.php';
            $conn = OpenCon();
            $rows = mysqli_query($conn,"
            UPDATE trademark SET hide = 0  WHERE id = '$id'
            ");

            $_SESSION['unhideitemss'] = 1;


           


            header("Location: " . $_SERVER["HTTP_REFERER"]);

        }

        


        if($_GET['action'] == 'unhidefeedback')
        {
            $id = $_GET['id'];
            

            include 'db_connnection.php';
            $conn = OpenCon();
            $rows = mysqli_query($conn,"
            UPDATE feedback SET hide = 0  WHERE id = '$id'
            ");

            


           


            header("Location: " . $_SERVER["HTTP_REFERER"]);

        }

         if($_GET['action'] == 'unhidereplyfeedback')
        {
            $id = $_GET['id'];
            

            include 'db_connnection.php';
            $conn = OpenCon();
            $rows = mysqli_query($conn,"
            UPDATE reply_feedback SET hide = 0  WHERE id = '$id'
            ");

            


           


            header("Location: " . $_SERVER["HTTP_REFERER"]);

        }



        CloseCon($conn);
            
 ?>       
            

            
          
            

            


      
