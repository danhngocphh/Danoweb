<style>
.pagination {
  display: inline-block;
    }

.pagination a {
  color: black;
  float: left;
  background: white;
  padding: 8px 16px;
  text-decoration: none;
  transition: background-color .3s;
  border: 1px solid #ddd;
}

.pagination a.active {
  background-color: #2b302b;
  color: white;
  border: 1px solid #2b302b;
}

.pagination a:hover:not(.active) {background-color: #ddd;}
</style>
<?php

if($_SESSION['role'] == 1)
                                                {
                                                    echo "<script> alert('You do not have permission to access !!!') </script>";
                                                    die();

                                                }


                                               
                                                include 'db_connnection.php';
                                                $conn = OpenCon();
  echo '                                              
 
 <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">

<div class="row">
                            <div class="col-md-12">
                                <!-- DATA TABLE -->
                                <h3 class="title-5 m-b-35">member data</h3>
                                <div class="table-data__tool">
                                    <div class="table-data__tool-left">
                                     <form method="POST" action="?action=em">
                                            <div class="has-success form-group">
                                            <input type="text" id="inputSuccess2i" name="search" class="form-control-success form-control" value="" >
                                        </div>
                                        <div class="rs-select2--light rs-select2--md">
                                            <select class="js-select2" name="role">
                                                <option value="-1">ROLE</option>
                                                <option value="0">Admin</option>
                                                <option value="1">Member</option>
                                                <option value="2">User</option>
                                            </select>
                                            <div class="dropDownSelect2"></div></div>
                                            

                                             <input type="submit" class="btn btn-success btn-sm" value="Search">
                                       

                                        </form>';

                                        if( isset($_POST["role"]))
                                        {
                                            
                                                # code...
                                                $linkcata = $_POST["role"];
                                            
                                            
                                            
                                        }


                                        echo '  
                                    </div>
                                    <div class="table-data__tool-right">
                                        <a href="?action=adduser"><button class="au-btn au-btn-icon au-btn--green au-btn--small">
                                            <i class="zmdi zmdi-plus"></i>add user</button></a>
                                        
                                    </div>
                                </div>
                                <div class="table-responsive table-responsive-data2">
                                    <table class="table table-data2">
                                        <thead>
                                                <tr>
                                                    <th>active</th>
                                                    <td>username</th>
                                                    <th>fullname</th>
                                                    <th>role</th>
                                                    
                                                    <th></th>
                                                </tr>
                                            </thead>
                                        <tbody>';



                                        if (isset($_POST["search"])) {
                                            if ($_POST["search"] != NULL) {

                                                if ($_POST["role"]>=0) {

                                                    $search = $_POST["search"];
                                                    $result = mysqli_query($conn, "select count(id) as total from member WHERE ( username like '%$search%' or name like '%$search%' or email like '%$search%' or phone like '%$search%' or id like '%$search%' ) and roleuser = '$linkcata' ");
                                                
                                                }else{
                                                
                                                $search = $_POST["search"];
                                                $result = mysqli_query($conn, "select count(id) as total from member WHERE ( username like '%$search%' or name like '%$search%' or email like '%$search%' or phone like '%$search%' or id like '%$search%') ");
                                            }

                                            }elseif (isset($_POST["role"])) {
                                                if ($_POST["role"]>=0) {
                                                    # code... 
                                                    $result = mysqli_query($conn, "select count(id) as total from member WHERE roleuser = '$linkcata' ");

                                                }else{
                                                    $result = mysqli_query($conn, "select count(id) as total from member WHERE 1 ");


                                                }
                                          }  # code..
                                        }
                                        
                                        else{
                                            $result = mysqli_query($conn, "select count(id) as total from member WHERE 1 ");


                                        }

                                            

                                                // PHẦN XỬ LÝ PHP
// BƯỚC 1: KẾT NỐI CSDL

 
// BƯỚC 2: TÌM TỔNG SỐ RECORDS
$result = mysqli_query($conn, 'select count(id) as total from member');
$row = mysqli_fetch_assoc($result);
$total_records = $row['total'];

 
// BƯỚC 3: TÌM LIMIT VÀ CURRENT_PAGE
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 10;
 
// BƯỚC 4: TÍNH TOÁN TOTAL_PAGE VÀ START
// tổng số trang
$total_page = ceil($total_records / $limit);
 
// Giới hạn current_page trong khoảng 1 đến total_page
if ($current_page > $total_page){
    $current_page = $total_page;
}
else if ($current_page < 1){
    $current_page = 1;
}
 
// Tìm Start
$start = ($current_page - 1) * $limit;
 
// BƯỚC 5: TRUY VẤN LẤY DANH SÁCH TIN TỨC
// Có limit và start rồi thì truy vấn CSDL lấy danh sách tin tức


                                        
                                        if (isset($_POST["search"])) {
                                            if ($_POST["search"] != NULL) {

                                                if ($_POST["role"]>=0) {

                                                    $search = $_POST["search"];
                                                    $result = mysqli_query($conn, "SELECT * FROM member WHERE ( username like '%$search%' or name like '%$search%' or email like '%$search%' or phone like '%$search%' or id like '%$search%' ) and roleuser = '$linkcata' LIMIT $start, $limit");
                                                
                                                }else{
                                                
                                                $search = $_POST["search"];
                                                $result = mysqli_query($conn, "SELECT * FROM member WHERE ( username like '%$search%' or name like '%$search%' or email like '%$search%' or phone like '%$search%' or id like '%$search%') LIMIT $start, $limit");
                                            }

                                            }elseif (isset($_POST["role"])) {
                                                if ($_POST["role"]>=0) {
                                                    # code... 
                                                    $result = mysqli_query($conn, "SELECT * FROM member WHERE roleuser = '$linkcata' LIMIT $start, $limit");

                                                }else{
                                                    $result = mysqli_query($conn, "SELECT * FROM member WHERE 1 LIMIT $start, $limit");


                                                }
                                          }  # code..
                                        }
                                        
                                        else{
                                            $result = mysqli_query($conn, "SELECT * FROM member WHERE 1 LIMIT $start, $limit");


                                        }



                                                

                                                while ($rowif = mysqli_fetch_array($result))
                                                {

                                                    echo'

                                                    <tr class="tr-shadow">

                                                    
                                                    <td>
                                                       
                                                            
                                                            <span>';

                                                            if ($rowif["lockuser"] == 0) {
                                                                echo '<i class="zmdi zmdi-check"></i>';
                                                                # code...
                                                            }else
                                                            {
                                                                echo '<i class="zmdi zmdi-close"></i>';
                                                            }
                                                            echo '



                                                            </span>
                                                       
                                                    </td>

                                                    <td>
                                                        <div class="block-email">
                                                            '.$rowif["username"].'
                                                            
                                                        </div>
                                                    </td>

                                                    <td>
                                                        <div class="table-data__info">
                                                            <h6>'.$rowif["name"].'</h6>
                                                            <span>
                                                                <a href="#">'.$rowif["email"].'</a>
                                                            </span>
                                                        </div>
                                                    </td>
                                                    <td>';

                                                    if($rowif["roleuser"]== 0)
                                                        echo '<span class="role admin">admin</span></td>
                                                    
                                                    <td>
                                                         
                                                        <div class="table-data-feature">
                                                        <button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
                                                            <a href="?action=ifcu&user='. $rowif["username"] .'"><i class="fa fa-info" aria-hidden="true"></i></a>

                                                            
                                                        </button>
                                                        <button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
                                                            <a href="?action=acc&user='.$rowif["username"].'"><i class="zmdi zmdi-edit"></i></a>

                                                            
                                                        </button>
                                                        
                                                        
                                                    </div>

                                                    </td>
                                                </tr>
                                                <tr class="spacer"></tr>';
                                                    elseif ($rowif["roleuser"]== 1) {
                                                        echo ' <span class="role member">member</span></td>
                                                   
                                                    <td>
                                                        <div class="table-data-feature">
                                                        <button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
                                                            <a href="?action=ifcu&user='. $rowif["username"] .'"><i class="fa fa-info" aria-hidden="true"></i></a>

                                                            
                                                        </button>
                                                        <button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
                                                            <a href="?action=acc&user='. $rowif["username"] .'"><i class="zmdi zmdi-edit"></i></a>

                                                            
                                                        </button>';


                                                        if ($rowif["lockuser"] == 0) {


                                                            echo '<button class="item" data-toggle="tooltip" data-placement="top" title="Lock">
                                                            <a href="action/handle.php?action=lockuser&user='. $rowif["username"] .'"><i class="zmdi zmdi-lock"></i></a>
                                                        </button>';
                                                        }
                                                        else{
                                                            echo '<button class="item" data-toggle="tooltip" data-placement="top" title="Unlock">
                                                            <a href="action/handle.php?action=unlockuser&user='. $rowif["username"] .'"><i class="fa fa-unlock"></i></a>
                                                        </button>';
                                                        }



                                                        }elseif ($rowif["roleuser"]== 2) {

                                                            echo ' <span class="role user">user</span></td>
                                                   
                                                    <td>
                                                        <div class="table-data-feature">
                                                        <button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
                                                            <a href="?action=ifcu&user='. $rowif["username"] .'"><i class="fa fa-info" aria-hidden="true"></i></a>

                                                            
                                                        </button>
                                                        <button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
                                                            <a href="?action=acc&user='. $rowif["username"] .'"><i class="zmdi zmdi-edit"></i></a>

                                                            
                                                        </button>';

                                                        if ($rowif["lockuser"] == 0) {


                                                            echo '<button class="item" data-toggle="tooltip" data-placement="top" title="Lock">
                                                            <a href="action/handle.php?action=lockuser&user='. $rowif["username"] .'"><i class="zmdi zmdi-lock"></i></a>
                                                        </button>';
                                                        }
                                                        else{
                                                            echo '<button class="item" data-toggle="tooltip" data-placement="top" title="Unlock">
                                                            <a href="action/handle.php?action=unlockuser&user='. $rowif["username"] .'"><i class="fa fa-unlock"></i></a>
                                                        </button>';
                                                        }













                                                        
                                                        
                                                 echo'   </div>
                                                        
                                                    </td>
                                                </tr>
                                                <tr class="spacer"></tr>';
                                                        # code...
                                                    }


                                                    

                                                   




                                                }               echo " </tbody></table>";

                                                // PHẦN HIỂN THỊ PHÂN TRANG
// BƯỚC 7: HIỂN THỊ PHÂN TRANG
 echo '<tr class="spacer"><br></tr>
  <div class="d-flex justify-content-center"><div class="pagination">';
// nếu current_page > 1 và total_page > 1 mới hiển thị nút prev
if ($current_page > 1 && $total_page > 1){
    echo '<a href="index.php?action=item&page='.($current_page-1).'">Prev</a>';
}
 
// Lặp khoảng giữa
for ($i = 1; $i <= $total_page; $i++){
    // Nếu là trang hiện tại thì hiển thị thẻ span
    // ngược lại hiển thị thẻ a
    if ($i == $current_page){
        echo '<a href="#" class="active"><span>'.$i.'</span></a>';
    }
    else{
        echo '<a href="index.php?action=item&page='.$i.'">'.$i.'</a>';
    }
}
 
// nếu current_page < $total_page và total_page > 1 mới hiển thị nút prev
if ($current_page < $total_page && $total_page > 1){
    echo '<a href="index.php?action=item&page='.($current_page+1).'">Next</a>';
}
echo '</div></div>';


CloseCon($conn);
                                            ?>
                                            
                                       
                                </div>
                                <!-- END DATA TABLE -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>