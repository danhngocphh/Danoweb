    <style>


h6 {
  color: green;
 
}
</style>

 <?php

if(isset($_GET['user']))
   {
        $user = $_GET['user'];
        



   

            include 'db_connnection.php';
            $conn = OpenCon();

        
        

        $rows = mysqli_query($conn,"
                select * from member where username = '$user' 
            ");
            
        
            $rowsif = mysqli_fetch_assoc($rows);

            
            $fullname = $rowsif['name'];
            $email = $rowsif['email'];
            $phone = $rowsif['phone'];
            $address = $rowsif['address'];
            
            $role = $rowsif['roleuser'];
            $lock = $rowsif['lockuser'];
            CloseCon($conn);    
            

            


        }

            
                
                    
                
        
    
       
            


            CloseCon($conn);

   echo '<div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>Account Settings</strong>
                                    </div>
                                    <form action="action/handle.php?action=updateacc&user='.$user.'" method="post" class="form-horizontal">';

                                   

                                    if(isset($_SESSION['updateaccss']))

                                    {
                                        if($_SESSION['updateaccss'] == 1)
                                           {
                                             echo "<div class='card-body card-block'><h6>Update Completed !!!</h6></div>";
                                             $_SESSION['updateaccss'] = 0;
                                           }
                                    }
                                    
                                   

                                    echo '<div class="card-body card-block">



                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label">Username: </label>
                                            ['.$user.']
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label">Email</label>
                                            <input type="email" id="inputSuccess2i" name="email" class="form-control-success form-control" value="'. $email .'" >
                                        </div>
                                        <div class="has-warning form-group">
                                            <label for="inputWarning2i" class=" form-control-label">Fullname</label>
                                            <input type="text" id="inputWarning2i" name="fullname" class="form-control-warning form-control" value="'. $fullname .'" >
                                        </div>
                                       
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Phone</label>
                                            <input type="number" id="inputError2i" name="phone" class="form-control-danger form-control" value="'. $phone .'" >
                                        </div>
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Address</label>
                                            <input type="text" id="inputError2i" name="address" class="form-control-danger form-control" value="'. $address .'" >
                                        </div>';
                        

                                        
                                        if($_SESSION['role']==0){

                                        echo '<div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Role</label>
                                            <div class="col-12 col-md-6">
                                                    <select name="role" id="select" class="form-control">
                                                        <option value="'. $role .'">';

                                                        if($role == 0)
                                                            echo "Admin";
                                                        elseif($role == 1)
                                                            echo "Member";
                                                        elseif($role == 2)
                                                            echo "User";







                                            echo'            </option>';

                                            if($lock == 0)
                                                echo ' <option value="0">Admin</option>';
                                                       echo '
                                                        <option value="1">Member</option>
                                                        <option value="2">User</option>
                                                        
                                                    </select>
                                                </div>
                                        </div>';
                                    }
                                    echo '
                                        <div class="form-actions form-group">
                                                <button type="submit" class="btn btn-success btn-sm">Update</button>
                                            </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                                <!-- END DATA TABLE -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>










   ';


      




 ?>

 