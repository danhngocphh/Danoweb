<style>
.pagination {
  display: inline-block;
    }

.pagination a {
  color: black;
  float: left;
  background: white;
  padding: 8px 16px;
  text-decoration: none;
  transition: background-color .3s;
  border: 1px solid #ddd;
}

.pagination a.active {
  background-color: #2b302b;
  color: white;
  border: 1px solid #2b302b;
}

.pagination a:hover:not(.active) {background-color: #ddd;}
</style>
<?php


                                               
                                                include 'db_connnection.php';
                                                $conn = OpenCon();
  echo '                                              
 
 <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">

<div class="row">
                            <div class="col-md-12">
                                <!-- DATA TABLE -->
                                <h3 class="title-5 m-b-35">trademark data</h3>
                                <div class="table-data__tool">
                                    <div class="table-data__tool-left">
                                     <form method="POST" action="?action=trade">
                                            <div class="has-success form-group">
                                            <input type="text" id="inputSuccess2i" name="search" class="form-control-success form-control" value="" >
                                        </div>
                                        
                                            

                                             <input type="submit" class="btn btn-success btn-sm" value="Search">
                                       

                                        </form>';

                                       


                                        echo '
                                    </div>
                                    <div class="table-data__tool-right">
                                        <a href="?action=addtrade"><button class="au-btn au-btn-icon au-btn--green au-btn--small">
                                            <i class="zmdi zmdi-plus"></i>add trademark</button></a>
                                        
                                    </div>
                                </div>
                                <div class="table-responsive table-responsive-data2">
                                    <table class="table table-data2">
                                        <thead>
                                            <tr>
                                               <th>active</th>
                                                <th>id</th>
                                                
                                                <th>name</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>';

                                        if (isset($_POST["search"])) {
                                           

                                                
                                                    $search = $_POST["search"];

                                                    
                                                    $result = mysqli_query($conn, "select count(id) as total from trademark WHERE ( name like '%$search%' or id like '%$search%')");
                                                
                                                
                                          
                                            # code..
                                        }
                                        
                                        else{
                                            $result = mysqli_query($conn, "select count(id) as total from trademark WHERE 1");


                                        }

                                            

                                                // PHẦN XỬ LÝ PHP
// BƯỚC 1: KẾT NỐI CSDL 
// BƯỚC 2: TÌM TỔNG SỐ RECORDS
$row = mysqli_fetch_assoc($result);
$total_records = $row['total'];

 
// BƯỚC 3: TÌM LIMIT VÀ CURRENT_PAGE
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 10;
 
// BƯỚC 4: TÍNH TOÁN TOTAL_PAGE VÀ START
// tổng số trang
$total_page = ceil($total_records / $limit);
 
// Giới hạn current_page trong khoảng 1 đến total_page
if ($current_page > $total_page){
    $current_page = $total_page;
}
else if ($current_page < 1){
    $current_page = 1;
}
 
// Tìm Start
$start = ($current_page - 1) * $limit;
 
// BƯỚC 5: TRUY VẤN LẤY DANH SÁCH TIN TỨC
// Có limit và start rồi thì truy vấn CSDL lấy danh sách tin tức


                                        
                                       if (isset($_POST["search"])) {
                                           

                                                
                                                    $search = $_POST["search"];

                                                    
                                                    $result = mysqli_query($conn, "select * from trademark WHERE ( name like '%$search%' or id like '%$search%')");
                                                
                                                
                                          
                                            # code..
                                        }
                                        
                                        else{
                                            $result = mysqli_query($conn, "select * from trademark WHERE 1 ");


                                        }



                                                

                                                while ($rowif = mysqli_fetch_array($result))
                                                {

                                                    echo '
                                                    <tr class="tr-shadow">

                                                    <td>
                                                       
                                                            
                                                            <span>';

                                                            if ($rowif["hide"] == 0) {
                                                                echo '<i class="zmdi zmdi-check"></i>';
                                                                # code...
                                                            }else
                                                            {
                                                                echo '<i class="zmdi zmdi-close"></i>';
                                                            }
                                                            echo '



                                                            </span>
                                                       
                                                    </td>

                                                
                                               
                                                    <td>'.$rowif["id"].'</td>
                                                <td>
                                                    <span class="block-email">'.$rowif["name"].'</span>
                                                </td>
                                                
                                                
                                                <td>
                                                    <div class="table-data-feature">
                                                        
                                                        <button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
                                                            <a href="?action=updatetrade&id='.$rowif["id"].'"><i class="zmdi zmdi-edit"></i></a>
                                                        </button>';


                                                        if ($rowif["hide"] == 0) {


                                                            echo '<button class="item" data-toggle="tooltip" data-placement="top" title="Hide">
                                                            <a href="action/handle.php?action=hidetrade&id='. $rowif["id"] .'"><i class="fa fa-eye-slash" aria-hidden="true"></i></a>
                                                        </button>';
                                                        }
                                                        else{
                                                            echo '<button class="item" data-toggle="tooltip" data-placement="top" title="Unhide">
                                                            <a href="action/handle.php?action=unhidetrade&id='. $rowif["id"] .'"><i class="fa fa-eye" aria-hidden="true"></i></a>
                                                        </button>';
                                                        }

                                                       


                                                        
                                                        
                                                    echo '</div>
                                                </td>

                                            </tr>
                                            <tr class="spacer"></tr>




                                                    ';





                                                }               echo " </tbody></table>";

                                                // PHẦN HIỂN THỊ PHÂN TRANG
// BƯỚC 7: HIỂN THỊ PHÂN TRANG


                                            
                                            
                                           


 echo '<tr class="spacer"><br></tr>
  <div class="d-flex justify-content-center"><div class="pagination">';
// nếu current_page > 1 và total_page > 1 mới hiển thị nút prev
if ($current_page > 1 && $total_page > 1){
    echo '<a href="index.php?action=trade&page='.($current_page-1).'">Prev</a>';
}
 
// Lặp khoảng giữa
for ($i = 1; $i <= $total_page; $i++){
    // Nếu là trang hiện tại thì hiển thị thẻ span
    // ngược lại hiển thị thẻ a
    if ($i == $current_page){
        echo '<a href="#" class="active"><span>'.$i.'</span></a>';
    }
    else{
        echo '<a href="index.php?action=trade&page='.$i.'">'.$i.'</a>';
    }
}
 
// nếu current_page < $total_page và total_page > 1 mới hiển thị nút prev
if ($current_page < $total_page && $total_page > 1){
    echo '<a href="index.php?action=trade&page='.($current_page+1).'">Next</a>';
}



echo '</div>



</div>';


CloseCon($conn);
                                            ?>
                                            
                                       
                                </div>
                                <!-- END DATA TABLE -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>