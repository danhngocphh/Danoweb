    <style>


h5 {
  color: green;
 
}
h6 {
  color: red;
 
}

</style>

 <?php


        



   

            include 'db_connnection.php';
            $conn = OpenCon();

        
        

        $rows = mysqli_query($conn,"
                select * from member
            ");
            
        
            $rowsif = mysqli_fetch_assoc($rows);

            
            $fullname = $rowsif['name'];
            $email = $rowsif['email'];
            $phone = $rowsif['phone'];
            $address = $rowsif['address'];

            

            


        

            
                
                    
                
        
    
       
            


            CloseCon($conn);

   echo '<div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>Add User</strong>
                                    </div>
                                    <form action="action/handle.php?action=adduser" method="post" class="form-horizontal">';

                                   

                                    if(isset($_SESSION['adduserss']))

                                    {
                                        if($_SESSION['adduserss'] == 1)
                                           {
                                             echo "<div class='card-body card-block'><h5>Add User Completed !!!</h5></div>";
                                             $_SESSION['adduserss'] = -1;
                                           }
                                        if($_SESSION['adduserss'] == 0)
                                           {
                                             echo "<div class='card-body card-block'><h6>Username Already Exists !!!</h6></div>";
                                             $_SESSION['adduserss'] = -1;
                                           }
                                    }
                                    
                                   

                                    echo '<div class="card-body card-block">



                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label">Username</label>
                                            <input type="text" id="inputSuccess2i" name="username" class="form-control-success form-control" value="" required >
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label">Password</label>
                                            <input type="password" id="inputSuccess2i" name="password" class="form-control-success form-control" value="" required >
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label">Email</label>
                                            <input type="email" id="inputSuccess2i" name="email" class="form-control-success form-control" value="" required>
                                        </div>
                                        <div class="has-warning form-group">
                                            <label for="inputWarning2i" class=" form-control-label">Fullname</label>
                                            <input type="text" id="inputWarning2i" name="name" class="form-control-warning form-control" value="" required>
                                        </div>
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Address</label>
                                            <input type="text" id="inputError2i" name="address" class="form-control-danger form-control" value="" required>
                                        </div>
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Phone</label>
                                            <input type="number" id="inputError2i" name="phone" class="form-control-danger form-control" value="" required>
                                        </div>
                                        
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Role</label>
                                            <div class="col-12 col-md-6">
                                                    <select name="role" id="role" class="form-control">
                                                       

                                                        






                                               
                                                        <option value="0">Admin</option>
                                                        <option value="1">Menber</option>
                                                        <option value="2">User</option>

                                                        
                                                    </select>
                                                </div>
                                        </div>
                                        <div class="form-actions form-group">
                                                <button type="submit" class="btn btn-success btn-sm">Add</button>
                                            </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                                <!-- END DATA TABLE -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>






   ';



 ?>

 