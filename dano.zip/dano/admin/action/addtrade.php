    <style>


h5 {
  color: green;
 
}
h6 {
  color: red;
 
}

</style>

 <?php


        



   

            include 'db_connnection.php';
            $conn = OpenCon();

        
        

        $rows = mysqli_query($conn,"
                select * from member
            ");
            
        
            $rowsif = mysqli_fetch_assoc($rows);

            
            $fullname = $rowsif['name'];
            $email = $rowsif['email'];
            $phone = $rowsif['phone'];
            $address = $rowsif['address'];

            

            


        

            
                
                    
                
        
    
       
            


            CloseCon($conn);

   echo '<div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>Add Trademark</strong>
                                    </div>
                                    <form action="action/handle.php?action=addtrade" method="post" class="form-horizontal">';

                                   

                                    
                                    
                                   

                                    echo '<div class="card-body card-block">



                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label">Trademark Name</label>
                                            <input type="text" id="inputSuccess2i" name="name" class="form-control-success form-control" value="" required >
                                        </div>
                                        
                                        
                                        
                                        
                                        <div class="form-actions form-group">
                                                <button type="submit" class="btn btn-success btn-sm">Add</button>
                                            </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                                <!-- END DATA TABLE -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>






   ';



 ?>

 