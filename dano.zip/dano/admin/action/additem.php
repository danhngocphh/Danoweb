    <style>


h5 {
  color: green;
 
}
h6 {
  color: red;
 
}

</style>

 <?php


        



   

            include 'db_connnection.php';
            $conn = OpenCon();

        
        

        $rows = mysqli_query($conn,"
                select * from member
            ");
            
        
            $rowsif = mysqli_fetch_assoc($rows);

            
            $fullname = $rowsif['name'];
            $email = $rowsif['email'];
            $phone = $rowsif['phone'];
            
            

            


        

            
                
                    
                
        
    
       
            


           

   echo '<div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>Add Item</strong>
                                    </div>
                                    <form action="action/handle.php?action=additem" method="post" class="form-horizontal">';

                                   

                                    if(isset($_SESSION['additemss']))

                                    {
                                        if($_SESSION['additemss'] == 1)
                                           {
                                             echo "<div class='card-body card-block'><h5>Add Item Completed !!!</h5></div>";
                                             $_SESSION['additemss'] = -1;
                                           }
                                        if($_SESSION['additemss'] == 0)
                                           {
                                             echo "<div class='card-body card-block'><h6>Failed !!!</h6></div>";
                                             $_SESSION['additemss'] = -1;
                                           }
                                    }
                                    
                                   

                                    echo '<div class="card-body card-block">



                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label">Watch Name</label>
                                            <input type="text" id="inputSuccess2i" name="name" class="form-control-success form-control" value="" required >
                                        </div>
                                         <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Catalog</label>
                                            <div class="col-12 col-md-6">
                                                    <select name="catalog_id" id="select" class="form-control">
                                                       

                                                        






                                               
                                                        <option value="1">Men</option>
                                                        <option value="2">Women</option>
                                                        <option value="3">Couple</option>
                                                        
                                                        
                                                    </select>
                                                </div>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label">Price</label>
                                            <input type="number" id="inputSuccess2i" name="price" class="form-control-success form-control" value="" required >
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label">Discount</label>
                                            <input type="text" id="inputSuccess2i" name="discount" class="form-control-success form-control" value="" required>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label">Trademark</label>
                                        </div>
                                        <div class="has-warning form-group"><div class="col-12 col-md-6">
                                                    <select name="trademark" id="select" class="form-control">';
                                                        


                $rowscheck = mysqli_query($conn,"
                SELECT * FROM trademark WHERE hide = 0
                ");

                while ( $row = mysqli_fetch_assoc($rowscheck)) {
                  echo ' 

                  <option value="'.$row['id'].'">'.$row['name'].'</option>


                  ';
                  # code...
                }

                 CloseCon($conn);


                                            
                                                 
                                                        
                                                        
                                             echo'       </select>
                                                </div>
                                        
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Image</label>
                                            <input type="text" id="inputError2i" name="image_link" class="form-control-danger form-control" value="" required>
                                        </div>
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Total</label>
                                            <input type="number" id="inputError2i" name="total" class="form-control-danger form-control" value="" required>
                                        </div>
                                        <div class="has-warning form-group">
                                            <label for="inputWarning2i" class=" form-control-label">Description</label>
                                            <input type="text" id="inputWarning2i" name="description" class="form-control-warning form-control" value="" >
                                        </div>
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Ennergy</label>
                                            <input type="text" id="inputError2i" name="ennergy" class="form-control-danger form-control" value="" >
                                        </div>
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Strap Material</label>
                                            <input type="text" id="inputError2i" name="strap_material" class="form-control-danger form-control" value="" >
                                        </div>
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Glass Material</label>
                                            <input type="text" id="inputError2i" name="glass_material" class="form-control-danger form-control" value="" >
                                        </div>
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Face Shape</label>
                                            <input type="text" id="inputError2i" name="face_shape" class="form-control-danger form-control" value"" >
                                        </div>
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Size Face</label>
                                            <input type="text" id="inputError2i" name="size_face" class="form-control-danger form-control" value="" >
                                        </div>
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Color Face</label>
                                            <input type="text" id="inputError2i" name="color_face" class="form-control-danger form-control" value="" >
                                        </div>
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Waterproof</label>
                                            <input type="text" id="inputError2i" name="waterproof" class="form-control-danger form-control" value="" >
                                        </div>
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Origin</label>
                                            <input type="text" id="inputError2i" name="origin" class="form-control-danger form-control" value="" >
                                        </div>

                                        
                                        <div class="form-actions form-group">
                                                <button type="submit" class="btn btn-success btn-sm">Add</button>
                                            </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                                <!-- END DATA TABLE -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>






   ';



 ?>

 