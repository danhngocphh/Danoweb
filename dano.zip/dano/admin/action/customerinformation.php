    <style>


h6 {
  color: green;
 
}
</style>

 <?php

if(isset($_GET['user']))
   {
        $user = $_GET['user'];
        



   

            include 'db_connnection.php';
            $conn = OpenCon();

        
        

        $rows = mysqli_query($conn,"
                select * from member where username = '$user' 
            ");
            
        
            $rowsif = mysqli_fetch_assoc($rows);

            $id = $rowsif['id'];


             $rows2 = mysqli_query($conn,"
                select * from transaction where user_id = '$id' 
            ");
            
        
            $rowsif2 = mysqli_fetch_assoc($rows2);

            
            $fullname = $rowsif['name'];
            $email = $rowsif['email'];
            $phone = $rowsif['phone'];
            $address = $rowsif['address'];
            
            $role = $rowsif['roleuser'];
            $lock = $rowsif['lockuser'];
            $payment_info = $rowsif2['payment_info'];
            $payment = $rowsif2['payment'];










            CloseCon($conn);    
            

            


        }

            
                
                    
                
        
    
       
            


           

   echo '<div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>Customer Information</strong>
                                    </div>
                                    <form action="action/handle.php?action=updateacc&user='.$user.'" method="post" class="form-horizontal">';

                                   

                                    
                                   

                                    echo '<div class="card-body card-block">



                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Username:</b> </label>
                                            ['.$user.']
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Email:</b> '. $email .'</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Fullname:</b> '. $fullname .'</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Phone:</b> '. $phone .'</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Address:</b> '. $address .'</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Payment:</b> '. $payment .'</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Payment Info:</b> '. $payment_info.'</label>
                                        </div>
                                         <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Role: </b>';

                                            if($role == 0)
                                                            echo "Admin";
                                                        elseif($role == 1)
                                                            echo "Member";
                                                        elseif($role == 2)
                                                            echo "User";



                                            echo '</label>
                                        </div>';
                                        

                                        
                                        







                                            
                                        
                                    
                                    echo '
                                        <div class="form-actions form-group">
                                                <a href="?action=acc&user='.$user.'"><button type="" class="btn btn-success btn-sm">Account Settings</button></a>
                                            </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                                <!-- END DATA TABLE -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>










   ';


      




 ?>

 