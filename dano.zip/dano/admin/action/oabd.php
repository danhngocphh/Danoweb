<style>
.pagination {
  display: inline-block;
    }

.pagination a {
  color: black;
  float: left;
  background: white;
  padding: 8px 16px;
  text-decoration: none;
  transition: background-color .3s;
  border: 1px solid #ddd;
}

.pagination a.active {
  background-color: #2b302b;
  color: white;
  border: 1px solid #2b302b;
}

.pagination a:hover:not(.active) {background-color: #ddd;}
</style>

 <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">

<div class="row">
                            <div class="col-md-12">
                                <!-- DATA TABLE -->
                                <h3 class="title-5 m-b-35">orders are being delivered</h3>
                                <?php
       echo '
                                <div class="table-data__tool">
                                     <div class="table-data__tool-left">
                                     <form method="POST" action="?action=oabd">
                                            <div class="has-success form-group">
                                            <input type="text" id="inputSuccess2i" name="search" class="form-control-success form-control" value="" >
                                        </div>
                                        
                                             <input type="submit" class="btn btn-success btn-sm" value="Search">
                                       

                                        </form>';

                                        


                                        echo '
                                    </div>
                                    
                                </div>
                                
                                
                                <div class="table-responsive table-responsive-data2">
                                    <table class="table table-data2">
                                        <thead>
                                            <tr>
                                                
                                                <th>id</th>
                                                <th>product id</th>
                                                <th>product </th>

                                                <th>transaction id</th>
                                                
                                                <th>qty</th>
                                                <th>amount</th>
                                                <th>data</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>';

                                            


                                               
                                                include 'db_connnection.php';
                                                $conn = OpenCon();


                                                 if (isset($_POST["search"])) {
                                            if ($_POST["search"] != NULL) {

                                               

                                                    $search = $_POST["search"];
                                                    $result = mysqli_query($conn, "select count(id) as total from detail_order WHERE ( id like '%$search%' or product_id like '%$search%' or product_name like '%$search%' or transaction_id like '%$search%' or data like '%$search%' ) and status = '2' ");
                                                
                                               

                                            }# code..
                                        }
                                        
                                        else{

                                            $result = mysqli_query($conn, "select count(id) as total from detail_order where status = '2'");

                                        }




                                                // PHẦN XỬ LÝ PHP
// BƯỚC 1: KẾT NỐI CSDL

 
// BƯỚC 2: TÌM TỔNG SỐ RECORDS
$result = mysqli_query($conn, 'select count(id) as total from detail_order where status = "2"');
$row = mysqli_fetch_assoc($result);
$total_records = $row['total'];

if($total_records > 0)
{

 
// BƯỚC 3: TÌM LIMIT VÀ CURRENT_PAGE
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 10;
 
// BƯỚC 4: TÍNH TOÁN TOTAL_PAGE VÀ START
// tổng số trang
$total_page = ceil($total_records / $limit);
 
// Giới hạn current_page trong khoảng 1 đến total_page
if ($current_page > $total_page){
    $current_page = $total_page;
}
else if ($current_page < 1){
    $current_page = 1;
}
 
// Tìm Start
$start = ($current_page - 1) * $limit;
 
// BƯỚC 5: TRUY VẤN LẤY DANH SÁCH TIN TỨC
// Có limit và start rồi thì truy vấn CSDL lấy danh sách tin tức
                                    if (isset($_POST["search"])) {
                                            if ($_POST["search"] != NULL) {

                                               

                                                    $search = $_POST["search"];
                                                    $result = mysqli_query($conn, "SELECT * FROM detail_order WHERE ( id like '%$search%' or product_id like '%$search%' or product_name like '%$search%' or transaction_id like '%$search%' or data like '%$search%' ) and status = '2' LIMIT $start, $limit");
                                                
                                               

                                            }# code..
                                        }
                                        
                                        else{

                                            $result = mysqli_query($conn, "SELECT * FROM detail_order where status = '2' LIMIT $start, $limit");

                                        }



                                                

                                                while ($rowif = mysqli_fetch_array($result))
                                                {
                                                    echo '
                                                    <tr class="tr-shadow">

                                                
                                                
                                                
                                                    <td>'.$rowif["id"].'</td>
                                                <td>
                                                    <span class="block-email">'.$rowif["product_id"].'</span>
                                                </td>

<td>
                                                    <span class="block-email">'.$rowif["product_name"].'</span>
                                                </td>                                                <td class="desc">'.$rowif["transaction_id"].'</td>
                                                <td>'.$rowif["qty"].'</td>
                                                <td>
                                                    <span class="status--process">'.$rowif["amount"].'</span>
                                                </td>
                                                <td>'.$rowif["data"].'</td>
                                                <td>
                                                        <div class="table-data-feature">
                                                        <button class="item" data-toggle="tooltip" data-placement="top" title="Check">
                                                            <a href="action/handle.php"><i class="fa fa-info" aria-hidden="true"></i></a>

                                                            
                                                        </button>
                                                        </div>
                                                </td>
                                                
                                            </tr>
                                            <tr class="spacer"></tr>




                                                    ';





                                                }               echo " </tbody></table>";

                                                // PHẦN HIỂN THỊ PHÂN TRANG
// BƯỚC 7: HIỂN THỊ PHÂN TRANG
 echo '<tr class="spacer"><br></tr>
  <div class="d-flex justify-content-center"><div class="pagination">';
// nếu current_page > 1 và total_page > 1 mới hiển thị nút prev
if ($current_page > 1 && $total_page > 1){
    echo '<a href="index.php?action=invoice&page='.($current_page-1).'">Prev</a>';
}
 
// Lặp khoảng giữa
for ($i = 1; $i <= $total_page; $i++){
    // Nếu là trang hiện tại thì hiển thị thẻ span
    // ngược lại hiển thị thẻ a
    if ($i == $current_page){
        echo '<a href="#" class="active"><span>'.$i.'</span></a>';
    }
    else{
        echo '<a href="index.php?action=invoice&page='.$i.'">'.$i.'</a>';
    }
}
 
// nếu current_page < $total_page và total_page > 1 mới hiển thị nút prev
if ($current_page < $total_page && $total_page > 1){
    echo '<a href="index.php?action=invoice&page='.($current_page+1).'">Next</a>';
}
echo '</div></div>';
}else{

    echo "<div class='col-md-12'> <h4>There are no invoices to handle<h4></div>";
}


CloseCon($conn);
                                           
                                            
                                       
                             echo '   </div>
                                <!-- END DATA TABLE -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
 ?>