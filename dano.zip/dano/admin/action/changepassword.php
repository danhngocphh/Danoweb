    <style>


h6 {
  color: red;
 
}
h5 {
  color: green;
 
}
</style>

 <?php

if(isset($_GET['user']))
   {
        $user = $_GET['user'];
        



   

            include 'db_connnection.php';
            $conn = OpenCon();

        
        

        $rows = mysqli_query($conn,"
                select * from memberadmin where username = '$user' 
            ");
            
        
            $rowsif = mysqli_fetch_assoc($rows);

            
          

            


        }

            
                
                    
                
        
    
       
            


            CloseCon($conn);

   echo '<div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>Change Password</strong>
                                    </div>
                                    <form action="action/handle.php?action=changepass&user='.$user.'" method="post" class="form-horizontal">';

                                   

                                    if(isset($_SESSION['uppassss']))

                                    {
                                        if($_SESSION['uppassss'] == 1)
                                           {
                                             echo "<div class='card-body card-block'><h5>Update Completed !!!</h5></div>";
                                             $_SESSION['uppassss'] = 0;
                                           }
                                    }


                                    if(isset($_SESSION['odlpassfail']))

                                    {
                                        if($_SESSION['odlpassfail'] == 1)
                                           {
                                             echo "<div class='card-body card-block'><h6>Incorrect Password !!!</h6></div>";
                                             $_SESSION['odlpassfail'] = 0;
                                           }
                                    }


                                    if(isset($_SESSION['repassfail']))

                                    {
                                        if($_SESSION['repassfail'] == 1)
                                           {
                                             echo "<div class='card-body card-block'><h6>Incorrect Retype Password !!!</h6></div>";
                                             $_SESSION['repassfail'] = 0;
                                           }
                                    }
                                    
                                   

                                    echo '<div class="card-body card-block">



                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label">Username: </label>
                                            ['.$user.']
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label">Old Password</label>
                                            <input type="password" id="inputSuccess2i" name="oldpassword" class="form-control-success form-control" >
                                        </div>
                                        <div class="has-warning form-group">
                                            <label for="inputWarning2i" class=" form-control-label">New Password</label>
                                            <input type="password" id="inputWarning2i" name="newpassword" class="form-control-warning form-control"  >
                                        </div>
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Retype New Password</label>
                                            <input type="password" id="inputError2i" name="renewpassword" class="form-control-danger form-control" >
                                        </div>
                                        
                                        <div class="form-actions form-group">
                                                <button type="submit" class="btn btn-success btn-sm">Update</button>
                                            </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                                <!-- END DATA TABLE -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>






   ';



 ?>

 