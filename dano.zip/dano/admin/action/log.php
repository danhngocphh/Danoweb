

<?php

session_start();
include 'db_connnection.php';	
$conn = OpenCon();

		if(isset($_POST['user']))
		{
			$tk = $_POST['user'];
			$mk = md5($_POST['pass']);
			
			
		
		$rows = mysqli_query ($conn, " select * from member where username = '$tk' and password = '$mk' and roleuser < '2'");	
			
		if(mysqli_num_rows($rows) == 1)
		{


			$rowsif = mysqli_fetch_assoc($rows);

			if($rowsif['lockuser'] == 1)
			{
				$_SESSION['fail'] = true;
				header("location: ../index.php");


				


			}else{
			$_SESSION['id'] = $rowsif['id'];

			$_SESSION['username'] = $rowsif['username'];
			$_SESSION['fullname'] = $rowsif['name'];
			$_SESSION['email'] = $rowsif['email'];
			$_SESSION['role'] = $rowsif['roleuser'];
			

			$_SESSION['active'] = 1;

			header("location: ../index.php");



			}



			



			
				
					
				
		
	
		}else{

			$_SESSION['fail'] = true;
			header("location: ../index.php");
			
			
		}
		}
			


			CloseCon($conn);

?>