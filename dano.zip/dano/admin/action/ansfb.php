    <style>


h6 {
  color: green;
 
}
</style>

 <?php

if(isset($_GET['id']))
   {
        $id = $_GET['id'];
        



   

            include 'db_connnection.php';
            $conn = OpenCon();

        
        

            $rows = mysqli_query($conn,"select * from feedback where id = '$id'");
            $rowsif = mysqli_fetch_assoc($rows);

            
            $user_id = $rowsif['user_id'];
            $product_id = $rowsif['product_id'];
            $content = $rowsif['content'];
            $rate = $rowsif['rate'];
            $created = $rowsif['date_created'];
            $date = date(DATA_ATOM);
            $idmember = $_SESSION['id'];


            $rows2 = mysqli_query($conn,"select * from member where id = '$user_id'");
            $rowsif2 = mysqli_fetch_assoc($rows2);

            $name = $rowsif2['name'];
            $phone = $rowsif2['phone'];
            $address = $rowsif2['address'];

            $rows3 = mysqli_query($conn,"select * from product where id = '$product_id'");
            $rowsif3 = mysqli_fetch_assoc($rows3);

            $product_name = $rowsif3['name'];
            $product_price = $rowsif3['price'];
            $product_image = $rowsif3['image'];


            
            
            

            


        }

            
                
                    
                
        
    
       
            


            CloseCon($conn);

   echo '<div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>Reply Feedback</strong>
                                    </div>
                                    <form action="action/handle.php?action=ansfb&nameuser='.$name.'&idfeedback='.$id.'&idmember='.$idmember.'" method="post" class="form-horizontal">';

                                   

                                    
                                   

                                    echo '<div class="card-body card-block">



                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Feedback ID:</b> </label>
                                            ['.$id.']
                                        </div>
                                         <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Product:</b> '. $product_name .'</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Image:</b> '. $product_image .'</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Price:</b> '. $product_price .'</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Customer:</b> '. $name .'</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Phone:</b> '. $phone .'</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Address:</b> '. $address .'</label>
                                        </div>
                                         <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Rate:</b> '. $rate .' Star</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Content:</b> '. $content .'</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Created:</b> '. $created .'</label>
                                        </div>
                                        
                                       
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Reply</label>
                                            <input type="text" id="inputError2i" name="reply" class="form-control-danger form-control"  >
                                        </div>
                                        
                        

                                        
                                        







                                        ';
                                    
                                    echo '
                                        <div class="form-actions form-group">
                                                

<button type="submit" class="btn btn-success btn-sm">Confirm </button> <button type="submit" class="btn btn-success btn-sm">Cancel</button>
                                            </div>

                                    </div>
                                    </form>
                                </div>
                            </div>
                                <!-- END DATA TABLE -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>










   ';


      




 ?>

 