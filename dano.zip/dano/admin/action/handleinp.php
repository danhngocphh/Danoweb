    <style>


h6 {
  color: green;
 
}
</style>

 <?php

if(isset($_GET['id']))
   {
        $id = $_GET['id'];
        



   

            include 'db_connnection.php';
            $conn = OpenCon();

        
        

            $rows = mysqli_query($conn,"select * from detail_order where id = '$id'");
            $rowsif = mysqli_fetch_assoc($rows);

            
            $transaction_id = $rowsif['transaction_id'];
            $product_id = $rowsif['product_id'];
            $qty = $rowsif['qty'];
            $amount = $rowsif['amount'];
            $data = $rowsif['data'];


            $rows2 = mysqli_query($conn,"select * from product where id = '$product_id'");
            $rowsif2 = mysqli_fetch_assoc($rows2);

            $product_name = $rowsif2['name'];
            $product_image = $rowsif2['image'];
            $product_total = $rowsif2['total'];

            $rows3 = mysqli_query($conn,"select * from transaction where id = '$transaction_id'");
            $rowsif3 = mysqli_fetch_assoc($rows3);

            $user_name = $rowsif3['user_name'];
            $user_email = $rowsif3['user_email'];
            $user_phone = $rowsif3['user_phone'];


            
            CloseCon($conn);    
            

            


        }

            
                
                    
                
        
    
       
            


            CloseCon($conn);

   echo '<div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>Invoice Processing</strong>
                                    </div>
                                    <form action="action/handle.php?action=handleinp&id='.$id.'" method="post" class="form-horizontal">';

                                   

                                    
                                   

                                    echo '<div class="card-body card-block">



                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label">Order ID: </label>
                                            ['.$id.']
                                        </div>
                                         <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Product:</b> '. $product_name .'</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Image:</b> '. $product_image .'</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Total:</b> '. $product_total .'</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Customer:</b> '. $user_name .'</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Email:</b> '. $user_email .'</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Phone:</b> '. $user_phone .'</label>
                                        </div>
                                         <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Qty:</b> '. $qty .'</label>
                                        </div>
                                        <div class="has-success form-group">
                                            <label for="inputSuccess2i" class=" form-control-label"><b>Amount:</b> '. $amount .'</label>
                                        </div>
                                        
                                       
                                        <div class="has-danger has-feedback form-group">
                                            <label for="inputError2i" class=" form-control-label">Note</label>
                                            <input type="text" id="inputError2i" name="data" class="form-control-danger form-control" value="'. $data .'" >
                                        </div>
                                        
                        

                                        
                                        







                                        ';
                                    
                                    echo '
                                        <div class="form-actions form-group">
                                                
                                                    <button type="submit" class="btn btn-success btn-sm">Print the invoice</button>

<button type="submit" class="btn btn-success btn-sm">Confirm </button> <button type="submit" class="btn btn-success btn-sm">Cancel</button>
                                            </div>

                                    </div>
                                    </form>
                                </div>
                            </div>
                                <!-- END DATA TABLE -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>










   ';


      




 ?>

 