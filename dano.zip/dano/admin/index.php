<?php

        session_start();
        include 'action/addcssjs.php';


if(!isset($_SESSION['active']))

{
    
    include 'action/login.php';


}else
{
    include 'widget/header.php';

     include 'sys/site.php';

    include 'widget/bottom.php';

}

?>
