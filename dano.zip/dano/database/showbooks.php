﻿<?php
require 'DataProvider.php';

$sql = "SELECT * FROM dongho";
if (isset($_GET['txtname']))
{
	$sql = $sql . " WHERE dano like '%" . $_GET['txtname'] . "%'";
}

$result = DataProvider::executeQuery($sql);

// Hien thi ket qua
echo '<table width="600" align="center" border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111">';
   echo "<tr>";
   echo "<th>STT</th>";
   echo "<th>Tựa sách</th>";   	   
   echo "<th>Mô tả</th>";
   echo "<th>Tác giả</th>";
   echo "<th>NXB</th>";
   echo "<th>Đơn giá</th>";   
   echo "<th>Ảnh bìa</th>";
   echo "</tr>";
   $i = 1;
   while ($row = mysql_fetch_array($result))
   {
   	    echo "<tr>";
   	   	echo "<td>" . $i . "</td>";
   	   	echo "<td>" . $row['madh'] . "</td>";
   	   	echo "<td>" . $row['loaidh'] . "</td>";
   	   	echo "<td>" . $row['soluong'] . "</td>";
   	   	echo "<td>" . $row['tendh'] . "</td>";
   	   	echo "<td>" . $row['hinh'] . "</td>";
            echo "<td>" . $row['gia'] . "</td>";
		
      	echo "</tr>";
      	
      	$i++;
   }
   echo "</table>";

?>