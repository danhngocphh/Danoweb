var donghonam =
[
    ["ĐỒNG HỒ LOUIS ERARD","ĐỒNG HỒ CITIZEN","ĐỒNG HỒ TISSOT","ĐỒNG HỒ SEIKO", "ĐỒNG HỒ ORIENT", "ĐỒNG HỒ OLYM PIANUS ", "ĐỒNG HỒ CASIO", "ĐỒNG HỒ CASIO", "ĐỒNG HỒ ORIENT", "ĐỒNG HỒ OLYM PIANUS ", "ĐỒNG HỒ CASIO", "ĐỒNG HỒ CASIO","ĐỒNG HỒ LOUIS ERARD","ĐỒNG HỒ CITIZEN","ĐỒNG HỒ TISSOT","ĐỒNG HỒ SEIKO"],
    ["10.990.000","14.690.000","12.990.000","10.090.000","14.590.000","44.490.000","14.590.000","44.490.000","14.590.000","44.490.000","14.590.000","44.490.000","10.990.000","14.690.000","12.990.000","10.090.000"],
    ["nam1.jpg","nam2.jpg","nam3.jpg","nam4.jpg","nam5.jpg","nam6.jpg","nam7.jpg","nam8.jpg","nam5.jpg","nam6.jpg","nam7.jpg","nam8.jpg","nam1.jpg","nam2.jpg","nam3.jpg","nam4.jpg"],
    ["","CITIZEN","TISSOT","SEIKO","ORIENT","OLYM PIANUS","CASIO","CASIO","ORIENT","OLYM PIANUS","CASIO","CASIO","LOUIS ERARD","CITIZEN","TISSOT","SEIKO"],
    ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16"]
];

var donghonu=
[
    ["ĐỒNG HỒ TISSOT","ĐỒNG HỒ CITIZEN","ĐỒNG HỒ OGIVAL","ĐỒNG HỒ CANDINO","ĐỒNG HỒ SKAGEN","ĐỒNG HỒ DANIEL","ĐỒNG HỒ CASIO","CASIO","ĐỒNG HỒ SKAGEN","ĐỒNG HỒ DANIEL","ĐỒNG HỒ CASIO","CASIO","ĐỒNG HỒ TISSOT","ĐỒNG HỒ CITIZEN","ĐỒNG HỒ OGIVAL","ĐỒNG HỒ CANDINO"],
    ["22.990.000","5.990.000","42.990.000","29.990.000","7.690.000","23.490.000","18.000.000","6.000.000","7.690.000","23.490.000","18.000.000","6.000.000","22.990.000","5.990.000","42.990.000","29.990.000"],
    ["nu1.jpg","nu2.jpg","nu3.jpg","nu4.jpg","nu5.jpg","nu6.jpg","nu7.jpg","nu8.jpg","nu5.jpg","nu6.jpg","nu7.jpg","nu8.jpg","nu1.jpg","nu2.jpg","nu3.jpg","nu4.jpg"],
    ["TISSOT","CITIZEN","OGIVAL","CANDINO","SKAGEN","DANIEL","CASIO","CASIO","TISSOT","CITIZEN","OGIVAL","CANDINO","SKAGEN","DANIEL","CASIO","CASIO","TISSOT","CITIZEN","OGIVAL","CANDINO"],
    ["110","120","130","140","150","160","17","18","19","110","111","112","113","114","115","116"]
];
var donghodoi=
[
    ["ĐỒNG HỒ ĐÔI ALEXANDRE","ĐỒNG HỒ ĐÔI SUNRISE","ĐỒNG HỒ ĐÔI OLYMPIA STAR ","ĐỒNG HỒ ĐÔI CITIZEN"],
    ["9.490.000","8.990.000","19.990.000","17.990.000"],
    ["doi1.jpg","doi2.jpg","doi3.jpg","doi4.jpg"],
    ["ALEXANDRE","SUNRISE","OLYMPIA STAR","CITIZEN"],
    ["1110","1120","1130","1140"]
]; 

var chitietdonghonam=
[
    ['Đây là dòng sản phẩm tuyệt vời cho những người đang tìm kiếm chiếc đồng hồ được thiết kế riêng mang đầy đủ sự “chất” Vintage cho đến hiện nay, đó là “chất cổ điển” và chỉ là “cổ điển” tinh khiết.'],
    ['Đồng hồ nam Citizen AU1080-20A nổi bật Pin sử dụng công nghệ hiện đại Eco-Drive (Năng Lượng Ánh Sáng), với thiết kế theo phong cách thời trang với dây đeo chất liệu bằng vải tông màu kem trẻ trung.'],
    ['Giản dị và thanh lịch đến từ mẫu đồng hồ Tissot T063.907.11.058.00, được gia công tạo hình với kiểu dáng mỏng tạo nên vẻ tinh tế đầy sang trọng cùng chi tiết kim chỉ vạch số được bao phủ vàng hồng.'],
    ['Đồng hồ Seiko SGEG99P1 dành cho nam, mặt đồng hồ màu đen, chữ số La Mã lớn màu trắng, vỏ thép không gỉ, dây da màu đen, mặt kính Sapphire chịu lực chống trầy, 1 ô lịch hiển thị ngày.'],
    ['Đồng hồ Orient FSTAA002W0 có vỏ kim loại phủ màu vàng sang trọng, kim chỉ và vạch số thanh mãnh nổi bật trên nền số, ô lịch ngày vị trí 3h tinh tế, dây đeo bằng chất liệu da cao cấp màu nâu đem lại phong cách lịch lãm, sang trọng cho phái mạnh'],
    ['Đồng hồ Orient FSTAA002W0 có vỏ kim loại phủ màu vàng sang trọng, kim chỉ và vạch số thanh mãnh nổi bật trên nền số, ô lịch ngày vị trí 3h tinh tế, dây đeo bằng chất liệu da cao cấp màu nâu đem lại phong cách lịch lãm, sang trọng cho phái mạnh'],
    ['Đồng hồ nam CASIO GA-110GB-1AVDF có thiết kế mới sử dụng kim loại màu vàng làm vạch số và kim nổi bật, sang trọng hơn so với thiết kế cũ nên mẫu GA-110GB-1AVDF rất được lòng giới trẻ hiện nay.'],
    ['Đồng hồ nam CASIO MTP-1374L-1AVDF thay cho thiết kế cửa sổ lich cổ điển là thiết kế mới lịch ngày và thứ đều sử dụng đồng hồ kim mang tính hiện đại, trẻ trung. Nổi bật trên nền mặt số đen là thiết kế phá cách kim giây đỏ làm điểm nhấn nổi bật. Dây đeo bằng da tạo vân cá sấu nổi bật với hai đường chỉ may trắng tinh xảo.'],
    ['Đồng hồ Orient FSTAA002W0 có vỏ kim loại phủ màu vàng sang trọng, kim chỉ và vạch số thanh mãnh nổi bật trên nền số, ô lịch ngày vị trí 3h tinh tế, dây đeo bằng chất liệu da cao cấp màu nâu đem lại phong cách lịch lãm, sang trọng cho phái mạnh'],
    ['Đồng hồ Orient FSTAA002W0 có vỏ kim loại phủ màu vàng sang trọng, kim chỉ và vạch số thanh mãnh nổi bật trên nền số, ô lịch ngày vị trí 3h tinh tế, dây đeo bằng chất liệu da cao cấp màu nâu đem lại phong cách lịch lãm, sang trọng cho phái mạnh'],
    ['Đồng hồ nam CASIO GA-110GB-1AVDF có thiết kế mới sử dụng kim loại màu vàng làm vạch số và kim nổi bật, sang trọng hơn so với thiết kế cũ nên mẫu GA-110GB-1AVDF rất được lòng giới trẻ hiện nay.'],
    ['Đồng hồ nam CASIO MTP-1374L-1AVDF thay cho thiết kế cửa sổ lich cổ điển là thiết kế mới lịch ngày và thứ đều sử dụng đồng hồ kim mang tính hiện đại, trẻ trung. Nổi bật trên nền mặt số đen là thiết kế phá cách kim giây đỏ làm điểm nhấn nổi bật. Dây đeo bằng da tạo vân cá sấu nổi bật với hai đường chỉ may trắng tinh xảo.'],
    ['Đây là dòng sản phẩm tuyệt vời cho những người đang tìm kiếm chiếc đồng hồ được thiết kế riêng mang đầy đủ sự “chất” Vintage cho đến hiện nay, đó là “chất cổ điển” và chỉ là “cổ điển” tinh khiết.'],
    ['Đồng hồ nam Citizen AU1080-20A nổi bật Pin sử dụng công nghệ hiện đại Eco-Drive (Năng Lượng Ánh Sáng), với thiết kế theo phong cách thời trang với dây đeo chất liệu bằng vải tông màu kem trẻ trung.'],
    ['Giản dị và thanh lịch đến từ mẫu đồng hồ Tissot T063.907.11.058.00, được gia công tạo hình với kiểu dáng mỏng tạo nên vẻ tinh tế đầy sang trọng cùng chi tiết kim chỉ vạch số được bao phủ vàng hồng.'],
    ['Đồng hồ Seiko SGEG99P1 dành cho nam, mặt đồng hồ màu đen, chữ số La Mã lớn màu trắng, vỏ thép không gỉ, dây da màu đen, mặt kính Sapphire chịu lực chống trầy, 1 ô lịch hiển thị ngày.']
    
];
var chitietdonghonam2 =
[
    ["Pin (Quartz)","Năng Lượng Ánh Sáng","Dây Vải","ĐỒNG HỒ SEIKO", "ĐỒNG HỒ ORIENT", "ĐỒNG HỒ OLYM PIANUS ", "ĐỒNG HỒ CASIO", "ĐỒNG HỒ CASIO", "ĐỒNG HỒ ORIENT", "ĐỒNG HỒ OLYM PIANUS ", "ĐỒNG HỒ CASIO", "ĐỒNG HỒ CASIO","ĐỒNG HỒ LOUIS ERARD","ĐỒNG HỒ CITIZEN","ĐỒNG HỒ TISSOT","ĐỒNG HỒ SEIKO"],
    ["Dây Da","Dây Vải","12.990.000","10.090.000","14.590.000","44.490.000","14.590.000","44.490.000","14.590.000","44.490.000","14.590.000","44.490.000","10.990.000","14.690.000","12.990.000","10.090.000"],
    ["Kính Sapphire","Kính Sapphire","nam3.jpg","nam4.jpg","nam5.jpg","nam6.jpg","nam7.jpg","nam8.jpg","nam5.jpg","nam6.jpg","nam7.jpg","nam8.jpg","nam1.jpg","nam2.jpg","nam3.jpg","nam4.jpg"],
    ["Nam","Nam","TISSOT","SEIKO","ORIENT","OLYM PIANUS","CASIO","CASIO","ORIENT","OLYM PIANUS","CASIO","CASIO","LOUIS ERARD","CITIZEN","TISSOT","SEIKO"],
    ["Tròn","Tròn","3","4","5","6","7","8","9","10","11","12","13","14","15","16"],
    ["40 - 43 mm","40 – 43 mm","3","4","5","6","7","8","9","10","11","12","13","14","15","16"],
    ["Xanh","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16"],
    ["Đi tắm (5 ATM)","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16"],
    ["Louis Erard","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16"],
    ["Thụy Sĩ","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16"]
];


function luuGioHang()
{
    alert("Đã thêm vào giỏ hàng!");
    location.reload();
    var url = window.location.href;
    var params = url.split('?');
    for(i=0; i<dienthoai[0].length; i++)
    {
        if(params[1]==donghodoi[0][i].replace(/ /g,"-"))
        {
            localStorage.setItem('tenDT'+i,donghonam[0][i]);
            localStorage.setItem('giaDT'+i,donghonam[1][i]);
        }
    }
    for(i=0; i<laptop[0].length; i++)
    {
        if(params[1]==donghonu[0][i].replace(/ /g,"-"))
        {
            localStorage.setItem('tenLT'+i,donghonu[0][i]);
            localStorage.setItem('giaLT'+i,donghonu[1][i]);
        }
    }
    for(i=0; i<donghodoi[0].length; i++)
    {
        if(params[1]==donghodoi[0][i].replace(/ /g,"-"))
        {
            localStorage.setItem('tenTL'+i,donghodoi[0][i]);
            localStorage.setItem('giaTL'+i,donghodoi[1][i]);
        }
    }
       
}

function hienThiVaoGio ()
{
    var total = 0;
    var d = "";
            d += '<div style="float:left; width:70%;text-align: left;"><b>Tên sản phẩm</b></div>';
            d += '<div style="float:left; width:30%;text-align: right;"><b>Đơn giá</b></div>';
            d += '<div style="float:left; width:50%;text-align: left;">ĐỒNG HỒ LOUIS ERARD</div>';
            d += '<div style="float:right; width:50%;text-align: right;">10.990.000 ₫</div>';
            d += '<div style="float:left; width:50%;text-align: left;">ĐỒNG HỒ TISSOT</div>';
            d += '<div style="float:right; width:50%;text-align: right;">12.990.000 ₫</div>';

    
    document.getElementById("cart").innerHTML = d;
}


function aa()
{
    var url = window.location.href;
    var params = url.split('?');
    var s='';
    switch(params[1])
    {
        case 'timkiemnangcao':
        {
            s=s+'<div class="mono"></div><div><div class="cantrai_50"><span class="cochu"><span class="xam">KẾT QUẢ TÌM KIẾM NÂNG CAO</span><span> (4 sản phẩm)</span></span></div></div><div class="mono"></div>';
            for(i=0; i<4; i++)
            {
                s=s+'<a href="chitiet.html?'+donghodoi[4][i].replace(/ /g,"-")+'"><div class="sanpham"><img src="images/'+donghodoi[2][i]+'" width="220px" height="220px"/><p>'+donghodoi[0][i]+'</p><p><b class="gia">'+donghodoi[1][i]+'₫</p><p><b class="gia"><img src="images/add.png" width="100px" height="30px"/></b></p></b></div></a>';
            }
            s=s+'<div class="mono"></div><div class="pagination"><a href="#" class="page active">1</a><a href="#" class="page">2</a><a href="#" class="page ">3</a><a href="#" class="page">4</a><a href="#" class="page">5</a><a href="#" class="page">>></a></div>';
        }
        break;

        case 'timkiem&1':
        {
            s=s+'<div class="mono"></div><div><div class="cantrai_50"><span class="cochu"><span class="xam">KẾT QUẢ TÌM KIẾM &nbsp;</span><span>(16 sản phảm)</span></span></div></div><div class="mono"></div>';
            for(i=0; i<8; i++)
            {
                s=s+'<a href="chitiet.html?'+donghonam[4][i].replace(/ /g,"-")+'"><div class="sanpham"><img src="images/'+donghonam[2][i]+'" width="220px" height="220px"/><p>'+donghonam[0][i]+'</p><p><b class="gia">'+donghonam[1][i]+'₫</p><p><b class="gia"><img src="images/add.png" width="100px" height="30px"/></b></p></b></div></a>';
            }
            s=s+'<div class="mono"></div><div class="pagination"><a href="#" class="page active">1</a><a href="?timkiem&2" class="page">2</a><a href="#" class="page ">3</a><a href="#" class="page">4</a><a href="#" class="page">5</a><a href="?timkiem&2" class="page">>></a></div>';
        }
        break;
        case 'timkiem&2':
        {
            s=s+'<div class="mono"></div><div><div class="cantrai_50"><span class="cochu"><span class="xam">KẾT QUẢ TÌM KIẾM &nbsp;</span><span>(16 sản phẩm)</span></span></div></div><div class="mono"></div>';
            for(i=8; i<16; i++)
            {
                s=s+'<a href="chitiet.html?'+donghonam[4][i].replace(/ /g,"-")+'"><div class="sanpham"><img src="images/'+donghonam[2][i]+'" width="220px" height="220px"/><p>'+donghonam[0][i]+'</p><p><b class="gia">'+donghonam[1][i]+'₫</p><p><b class="gia"><img src="images/add.png" width="100px" height="30px"/></b></p></b></div></a>';
            }
            s=s+'<div class="mono"></div><div class="pagination"><a href="?timkiem&1" class="page"><<</a><a href="?timkiem&1" class="page">1</a><a href="#" class="page active">2</a><a href="#" class="page ">3</a><a href="#" class="page">4</a><a href="#" class="page">5</a><a href="#" class="page">>></a></div>';
        }
        break;

        //dt
        case 'donghonam&1':
        {
            s=s+'<div class="mono"></div><div><div class="cantrai_50"><a href="./index.html" ><span class="cochu"><span class="xam">TRANG CHỦ / &nbsp;</a><a href="?donghonam&1" ><span class="xam">ĐỒNG HỒ NAM</span></a></span></div></div><div class="mono"></div>';
            for(i=0; i<8; i++)
            {
                s=s+'<a href="chitiet.html?'+donghonam[4][i].replace(/ /g,"-")+'"><div class="sanpham"><img src="images/'+donghonam[2][i]+'" width="220px" height="220px"/><p>'+donghonam[0][i]+'</p><p><b class="gia">'+donghonam[1][i]+'₫</p><p><b class="gia"><img src="images/add.png" width="100px" height="30px"/></b></p></b></div></a>';
            }
            s=s+'<div class="mono"></div><div class="pagination"><a href="#" class="page active">1</a><a href="?donghonam&2" class="page">2</a><a href="#" class="page ">3</a><a href="#" class="page">4</a><a href="#" class="page">5</a><a href="?donghonam&2" class="page">>></a></div>';
        }
        break;
        case 'donghonam&2':
        {
            s=s+'<div class="mono"></div><div><div class="cantrai_50"><a href="./index.html" ><span class="cochu"><span class="xam">TRANG CHỦ / &nbsp;</a><a href="?donghonam&1" ><span class="xam">ĐỒNG HỒ NAM</span></a></span></div></div><div class="mono"></div>';
            for(i=8; i<16; i++)
            {
                s=s+'<a href="chitiet.html?'+donghonam[4][i].replace(/ /g,"-")+'"><div class="sanpham"><img src="images/'+donghonam[2][i]+'" width="220px" height="220px"/><p>'+donghonam[0][i]+'</p><p><b class="gia">'+donghonam[1][i]+'₫</p><p><b class="gia"><img src="images/add.png" width="100px" height="30px"/></b></p></b></div></a>';
            }
            s=s+'<div class="mono"></div><div class="pagination"><a href="?donghonam&1" class="page"><<</a><a href="?donghonam&1" class="page">1</a><a href="#" class="page active">2</a><a href="#" class="page ">3</a><a href="#" class="page">4</a><a href="#" class="page">5</a><a href="#" class="page">>></a></div>';
        }
        break;
        case 'donghonu&1':
        {
            s=s+'<div class="mono"></div><div><div class="cantrai_50"><a href="./index.html" ><span class="cochu"><span class="xam">TRANG CHỦ / &nbsp;</a><a href="?donghonu&1" ><span class="xam">ĐỒNG HỒ NỮ</span></a></span></div></div><div class="mono"></div>';
            for(i=0; i<8; i++)
            {
                s=s+'<a href="chitiet.html?'+donghonu[4][i].replace(/ /g,"-")+'"><div class="sanpham"><img src="images/'+donghonu[2][i]+'" width="220px" height="220px"/><p>'+donghonu[0][i]+'</p><p><b class="gia">'+donghonu[1][i]+'₫</p><p><b class="gia"><img src="images/add.png" width="100px" height="30px"/></b></p></b></div></a>';
            }
            s=s+'<div class="mono"></div><div class="pagination"><a href="#" class="page active">1</a><a href="?donghonu&2" class="page">2</a><a href="#" class="page ">3</a><a href="#" class="page">4</a><a href="#" class="page">5</a><a href="?donghonu&2" class="page">>></a></div>';
        }
        break;
        case 'donghonu&2':
        {
            s=s+'<div class="mono"></div><div><div class="cantrai_50"><a href="./index.html" ><span class="cochu"><span class="xam">TRANG CHỦ / &nbsp;</a><a href="?donghonu&1" ><span class="xam">ĐỒNG HỒ NỮ</span></a></span></div></div><div class="mono"></div>';
            for(i=8; i<16; i++)
            {
                s=s+'<a href="chitiet.html?'+donghonu[4][i].replace(/ /g,"-")+'"><div class="sanpham"><img src="images/'+donghonu[2][i]+'" width="220px" height="220px"/><p>'+donghonu[0][i]+'</p><p><b class="gia">'+donghonu[1][i]+'₫</p><p><b class="gia"><img src="images/add.png" width="100px" height="30px"/></b></p></b></div></a>';
            }
            s=s+'<div class="mono"></div><div class="pagination"><a href="?donghonu&1" class="page"><<</a><a href="?donghonu&1" class="page">1</a><a href="#" class="page active">2</a><a href="#" class="page ">3</a><a href="#" class="page">4</a><a href="#" class="page">5</a><a href="#" class="page">>></a></div>';
        }
        break;
       case 'donghodoi':
        {
            s=s+'<div class="mono"></div><div><div class="cantrai_50"><a href="./index.html" ><span class="cochu"><span class="xam">TRANG CHỦ / &nbsp;</a><a href="?donghodoi" ><span class="xam">ĐỒNG HỒ ĐÔI</span></a></span></div></div><div class="mono"></div>';
            for(i=0; i<4; i++)
            {
                s=s+'<a href="chitiet.html?'+donghodoi[4][i].replace(/ /g,"-")+'"><div class="sanpham"><img src="images/'+donghodoi[2][i]+'" width="220px" height="220px"/><p>'+donghodoi[0][i]+'</p><p><b class="gia">'+donghodoi[1][i]+'₫</p><p><b class="gia"><img src="images/add.png" width="100px" height="30px"/></b></p></b></div></a>';
            }
            s=s+'<div class="mono"></div><div class="pagination"><a href="#" class="page active">1</a><a href="#" class="page">2</a><a href="#" class="page ">3</a><a href="#" class="page">4</a><a href="#" class="page">5</a><a href="#" class="page">>></a></div>';
        }
        break;
        
        default:
        {     
            var s='';
            s=s+'<div class="mono2"><a href="?donghonam&1" ><img src="images/dhnam.png" /></a></div>';
            for(i=0; i<donghonam[0].length&&i<8; i++)
            {
                s=s+'<a href="chitiet.html?'+donghonam[4][i].replace(/ /g,"-")+'"><div class="sanpham"><img src="images/'+donghonam[2][i]+'" width="220px" height="220px"/><p>'+donghonam[0][i]+'</p><p><b class="gia">'+donghonam[1][i]+'₫</b></p><p><b class="gia"><img src="images/add.png" width="100px" height="30px"/></b></p></div></a>';
            }
            s=s+'<div class="float_left_01"><img src="images/giua.png" width="1180px" /></div>';
            s=s+'<div class="mono2"><a href="?donghonu&1" ><img src="images/dhnu.png" width="421px" height="145px"/></a></div>';
            for(i=0; i<donghonu[0].length&&i<8; i++)
            {
            s=s+'<a href="chitiet.html?'+donghonu[4][i].replace(/ /g,"-")+'"><div class="sanpham"><img src="images/'+donghonu[2][i]+'" width="220px" height="220px"/><p>'+donghonu[0][i]+'</p><p><b class="gia">'+donghonu[1][i]+'₫</p><p><b class="gia"><img src="images/add.png" width="100px" height="30px"/></b></p></b></div></a>';
            }
            s=s+'<div class="float_left_01"><img src="images/giua2.png" width="1180px" /></div>';
            s=s+'<div class="mono2"><a href="?donghodoi" ><img src="images/dhdoi.png" /></a></div>';
            
            for(i=0; i<donghodoi[0].length&&i<4; i++)
            {
            s=s+'<a href="chitiet.html?'+donghodoi[4][i].replace(/ /g,"-")+'"><div class="sanpham"><img src="images/'+donghodoi[2][i]+'" width="220px" height="220px"/><p>'+donghodoi[0][i]+'</p><p><b class="gia">'+donghodoi[1][i]+'₫</p><p><b class="gia"><img src="images/add.png" width="100px" height="30px"/></b></p></b></div></a>';
            }
            
        }
        break;
    }
    document.getElementById("noidung").innerHTML=s;
}

function bb()
{
    var url = window.location.href;
    var params = url.split('?');
    var s='';
    switch(params[1])
    {
        case 'timkiemnangcao':
        {
            s=s+'<div class="mono"></div><div><div class="cantrai_50"><span class="cochu"><span class="xam">KẾT QUẢ TÌM KIẾM NÂNG CAO</span><span> (4 sản phẩm)</span></span></div></div><div class="mono"></div>';
            for(i=0; i<4; i++)
            {
                s=s+'<a href="chitiet.html?'+donghodoi[4][i].replace(/ /g,"-")+'"><div class="sanpham"><img src="images/'+donghodoi[2][i]+'" width="220px" height="220px"/><p>'+donghodoi[0][i]+'</p><p><b class="gia">'+donghodoi[1][i]+'₫</p><p><b class="gia"><img src="images/add.png" width="100px" height="30px"/></b></p></b></div></a>';
            }
            s=s+'<div class="mono"></div><div class="pagination"><a href="#" class="page active">1</a><a href="#" class="page">2</a><a href="#" class="page ">3</a><a href="#" class="page">4</a><a href="#" class="page">5</a><a href="#" class="page">>></a></div>';
        }
        break;

        case 'timkiem&1':
        {
            s=s+'<div class="mono"></div><div><div class="cantrai_50"><span class="cochu"><span class="xam">KẾT QUẢ TÌM KIẾM &nbsp;</span><span>(16 sản phảm)</span></span></div></div><div class="mono"></div>';
            for(i=0; i<8; i++)
            {
                s=s+'<a href="chitiet.html?'+donghonam[4][i].replace(/ /g,"-")+'"><div class="sanpham"><img src="images/'+donghonam[2][i]+'" width="220px" height="220px"/><p>'+donghonam[0][i]+'</p><p><b class="gia">'+donghonam[1][i]+'₫</p><p><b class="gia"><img src="images/add.png" width="100px" height="30px"/></b></p></b></div></a>';
            }
            s=s+'<div class="mono"></div><div class="pagination"><a href="#" class="page active">1</a><a href="?timkiem&2" class="page">2</a><a href="#" class="page ">3</a><a href="#" class="page">4</a><a href="#" class="page">5</a><a href="?timkiem&2" class="page">>></a></div>';
        }
        break;
        case 'timkiem&2':
        {
            s=s+'<div class="mono"></div><div><div class="cantrai_50"><span class="cochu"><span class="xam">KẾT QUẢ TÌM KIẾM &nbsp;</span><span>(16 sản phẩm)</span></span></div></div><div class="mono"></div>';
            for(i=8; i<16; i++)
            {
                s=s+'<a href="chitiet.html?'+donghonam[4][i].replace(/ /g,"-")+'"><div class="sanpham"><img src="images/'+donghonam[2][i]+'" width="220px" height="220px"/><p>'+donghonam[0][i]+'</p><p><b class="gia">'+donghonam[1][i]+'₫</p><p><b class="gia"><img src="images/add.png" width="100px" height="30px"/></b></p></b></div></a>';
            }
            s=s+'<div class="mono"></div><div class="pagination"><a href="?timkiem&1" class="page"><<</a><a href="?timkiem&1" class="page">1</a><a href="#" class="page active">2</a><a href="#" class="page ">3</a><a href="#" class="page">4</a><a href="#" class="page">5</a><a href="#" class="page">>></a></div>';
        }
        break;
     }


    for(i=0; i<donghonam[0].length; i++)
    {
        if(params[1]==donghonam[4][i].replace(/ /g,"-"))
        {
            s=s+'<img class="float_left_13" src="images/'+donghonam[2][i]+'"width="400px" height="400px">';
            s=s+'<div class="float_left_09"><span class="cochu"><a href="./index.html" ><span class="xam">TRANG CHỦ /</span></a><a href="./index.html?donghonam&1" ><span class="xam">ĐỒNG HỒ NAM</span></a></span><h2>'+donghonam[0][i]+'</h2><img src="images/mini.png"/><div><span class="xam">'+donghonam[1][i]+' ₫ </span></div><div><img src="images/mini.png"/></div><span class="xam2">'+chitietdonghonam[i]+'</span><br><img src="images/mini.png"/><br/><a onClick="luuGioHang(), hienThiVaoGio()" class="themgiohang"><img src="images/add.png"/></a></div> </div></div>';
            s=s+'<div class="float_left_02"><img src="images/thongtinchitiet.png"  /><br /><table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><br><strong>BỘ MÁY & NĂNG LƯỢNG</strong></td><td width="290px" ><br>'+chitietdonghonam2[0][0]+'</td></tr></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>CHẤT LIỆU DÂY</strong></td><td width="290px" >'+chitietdonghonam2[1][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>CHẤT LIỆU MẶT KÍNH</strong></td><td width="290px" >'+chitietdonghonam2[2][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>GIỚI TÍNH</strong></td><td width="290px" >'+chitietdonghonam2[3][i]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>HÌNH DẠNG MẶT SỐ</strong></td><td width="290px" >'+chitietdonghonam2[4][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>KÍCH THƯỚC MẶT SỐ</strong></td><td width="290px" >'+chitietdonghonam2[5][0]+'</td></tr> </table><img src="images/ngang.png" width="1000px"/>';
            s=s+' <table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>MÀU MẶT SỐ</strong></td><td width="290px" >'+chitietdonghonam2[6][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>MỨC CHÓNG NƯỚC</strong></td><td width="290px" >'+chitietdonghonam2[7][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>THƯƠNG HIỆU</strong></td><td width="290px" >'+chitietdonghonam2[8][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><STRONG>XUẤT XỨ</STRONG></td><td width="290px" >'+chitietdonghonam2[9][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/></div>';
            s=s+'<div class="float_left_02"><img src="images/thamkhao.png"  /><br /><div class="float_left_07"><a href="#" target="_parent"><img src="images/next1.png"  /></a><br/></div><div class="float_left_04"><a href="./chitiet.html?3"><img src="images/nam3.jpg" width="220px" height="220px" /></a><br /><span class="chu">ĐỒNG HỒ TISSOT</span><br />21,940,000 ₫</div><div class="float_left_04"><a href="./chitiet.html?4"><img src="images/nam4.jpg" width="220px" height="220px" /></a><br /><span class="chu">ĐỒNG HỒ SEIKO</span><br />3,684,000 ₫</div><div class="float_left_04"><a href="./chitiet.html?5"><img src="images/nam5.jpg" width="220px" height="220px" /></a><br /><span class="chu">ĐỒNG HỒ ORIENT</span><br />2,737,000 ₫</div><div class="float_left_07"><a href="#" target="_parent"><img src="images/next2.png"  /><br/></a></div></div>';
        }
    }
     for(i=0; i<donghonu[0].length; i++)
    {
        if(params[1]==donghonu[4][i].replace(/ /g,"-"))
        {
            s=s+'<img class="float_left_13" src="images/'+donghonu[2][i]+'"width="400px" height="400px">';
            s=s+'<div class="float_left_09"><span class="cochu"><a href="./index.html" ><span class="xam">TRANG CHỦ /</span></a><a href="./index.html?donghonu&1" ><span class="xam">ĐỒNG HỒ NỮ</span></a></span><h2>'+donghonu[0][i]+'</h2><img src="images/mini.png"/><div><span class="xam">'+donghonu[1][i]+' ₫ </span></div><div><img src="images/mini.png"/></div><span class="xam2">'+chitietdonghonam[i]+'</span><br><img src="images/mini.png"/><br/><a onClick="luuGioHang(), hienThiVaoGio()" class="themgiohang"><img src="images/add.png"/></a></div> </div></div>';
            s=s+'<div class="float_left_02"><img src="images/thongtinchitiet.png"  /><br /><table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><br><strong>BỘ MÁY & NĂNG LƯỢNG</strong></td><td width="290px" ><br>'+chitietdonghonam2[0][0]+'</td></tr></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>CHẤT LIỆU DÂY</strong></td><td width="290px" >'+chitietdonghonam2[1][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>CHẤT LIỆU MẶT KÍNH</strong></td><td width="290px" >'+chitietdonghonam2[2][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>GIỚI TÍNH</strong></td><td width="290px" >Nữ</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>HÌNH DẠNG MẶT SỐ</strong></td><td width="290px" >'+chitietdonghonam2[4][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>KÍCH THƯỚC MẶT SỐ</strong></td><td width="290px" >'+chitietdonghonam2[5][0]+'</td></tr> </table><img src="images/ngang.png" width="1000px"/>';
            s=s+' <table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>MÀU MẶT SỐ</strong></td><td width="290px" >'+chitietdonghonam2[6][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>MỨC CHÓNG NƯỚC</strong></td><td width="290px" >'+chitietdonghonam2[7][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>THƯƠNG HIỆU</strong></td><td width="290px" >'+chitietdonghonam2[8][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><STRONG>XUẤT XỨ</STRONG></td><td width="290px" >'+chitietdonghonam2[9][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/></div>';
            s=s+'<div class="float_left_02"><img src="images/thamkhao.png"  /><br /><div class="float_left_07"><a href="#" target="_parent"><img src="images/next1.png"  /></a><br/></div><div class="float_left_04"><a href="./chitiet.html?3"><img src="images/nam3.jpg" width="220px" height="220px" /></a><br /><span class="chu">ĐỒNG HỒ TISSOT</span><br />21,940,000 ₫</div><div class="float_left_04"><a href="./chitiet.html?4"><img src="images/nam4.jpg" width="220px" height="220px" /></a><br /><span class="chu">ĐỒNG HỒ SEIKO</span><br />3,684,000 ₫</div><div class="float_left_04"><a href="./chitiet.html?5"><img src="images/nam5.jpg" width="220px" height="220px" /></a><br /><span class="chu">ĐỒNG HỒ ORIENT</span><br />2,737,000 ₫</div><div class="float_left_07"><a href="#" target="_parent"><img src="images/next2.png"  /><br/></a></div></div>';
        }
    }
     for(i=0; i<donghodoi[0].length; i++)
    {
        if(params[1]==donghodoi[4][i].replace(/ /g,"-"))
        {
            s=s+'<img class="float_left_13" src="images/'+donghodoi[2][i]+'"width="400px" height="400px">';
            s=s+'<div class="float_left_09"><span class="cochu"><a href="./index.html" ><span class="xam">TRANG CHỦ /</span></a><a href="./index.html?donghodoi" ><span class="xam">ĐỒNG HỒ ĐÔI</span></a></span><h2>'+donghodoi[0][i]+'</h2><img src="images/mini.png"/><div><span class="xam">'+donghodoi[1][i]+' ₫ </span></div><div><img src="images/mini.png"/></div><span class="xam2">'+chitietdonghonam[i]+'</span><br><img src="images/mini.png"/><br/><a onClick="luuGioHang(), hienThiVaoGio()" class="themgiohang"><img src="images/add.png"/></a></div> </div></div>';
            s=s+'<div class="float_left_02"><img src="images/thongtinchitiet.png"  /><br /><table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><br><strong>BỘ MÁY & NĂNG LƯỢNG</strong></td><td width="290px" ><br>'+chitietdonghonam2[0][0]+'</td></tr></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>CHẤT LIỆU DÂY</strong></td><td width="290px" >'+chitietdonghonam2[1][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>CHẤT LIỆU MẶT KÍNH</strong></td><td width="290px" >'+chitietdonghonam2[2][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>GIỚI TÍNH</strong></td><td width="290px" >Nam, Nữ</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>HÌNH DẠNG MẶT SỐ</strong></td><td width="290px" >'+chitietdonghonam2[4][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>KÍCH THƯỚC MẶT SỐ</strong></td><td width="290px" >'+chitietdonghonam2[5][0]+'</td></tr> </table><img src="images/ngang.png" width="1000px"/>';
            s=s+' <table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>MÀU MẶT SỐ</strong></td><td width="290px" >'+chitietdonghonam2[6][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>MỨC CHÓNG NƯỚC</strong></td><td width="290px" >'+chitietdonghonam2[7][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><strong>THƯƠNG HIỆU</strong></td><td width="290px" >'+chitietdonghonam2[8][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/>';
            s=s+'<table border="0px"><tr  height="30px"><td class="thongtin1" width="690px"><STRONG>XUẤT XỨ</STRONG></td><td width="290px" >'+chitietdonghonam2[9][0]+'</td></tr></table><img src="images/ngang.png" width="1000px"/></div>';
            s=s+'<div class="float_left_02"><img src="images/thamkhao.png"  /><br /><div class="float_left_07"><a href="#" target="_parent"><img src="images/next1.png"  /></a><br/></div><div class="float_left_04"><a href="./chitiet.html?3"><img src="images/nam3.jpg" width="220px" height="220px" /></a><br /><span class="chu">ĐỒNG HỒ TISSOT</span><br />21,940,000 ₫</div><div class="float_left_04"><a href="./chitiet.html?4"><img src="images/nam4.jpg" width="220px" height="220px" /></a><br /><span class="chu">ĐỒNG HỒ SEIKO</span><br />3,684,000 ₫</div><div class="float_left_04"><a href="./chitiet.html?5"><img src="images/nam5.jpg" width="220px" height="220px" /></a><br /><span class="chu">ĐỒNG HỒ ORIENT</span><br />2,737,000 ₫</div><div class="float_left_07"><a href="#" target="_parent"><img src="images/next2.png"  /><br/></a></div></div>';
        }
    }
    
    document.getElementById("noidung").innerHTML=s;
}
function timkiem()
{
    var s='';
    s=s+'<div class="loai">&nbsp</div>';
    var a=document.getElementById('search').value;
    for(i=0; i<donghonam[0].length||i<donghonu[0].length||i<donghodoi[0].length; i++)
    {
        if(donghonam[0][i].toLocaleUpperCase().indexOf(a.toLocaleUpperCase())>=0)
        {
            s=s+'<a href="chitiet.html?'+donghonam[4][i].replace(/ /g,"-")+'"><div class="sanpham"><img src="images/'+donghonam[2][i]+'" width="100%" height="60%"/><p>'+donghonam[0][i]+'</p><hr><p><b class="gia">'+donghonam[1][i]+'</p></b></div></a>';
        }
        if(donghonu[0][i].toLocaleUpperCase().indexOf(a.toLocaleUpperCase())>=0)
        {
            s=s+'<a href="chitietsanpham.html?'+donghonu[4][i].replace(/ /g,"-")+'"><div class="sanpham"><img src="images/'+donghonu[2][i]+'" width="100%" height="60%"/><p>'+donghonu[0][i]+'</p><hr><p><b class="gia">'+donghonu[1][i]+'</p></b></div></a>';
        }
        if(donghodoi[0][i].toLocaleUpperCase().indexOf(a.toLocaleUpperCase())>=0)
        {
            s=s+'<a href="chitietsanpham.html?'+donghodoi[4][i].replace(/ /g,"-")+'"><div class="sanpham"><img src="image/'+donghodoi[2][i]+'" width="100%" height="60%"/><p>'+donghodoi[0][i]+'</p><hr><p><b class="gia">'+donghodoi[1][i]+'</p></b></div></a>';
        }
        
    }
    document.getElementById("noidung").innerHTML=s;
}



function checkSignUp()
{

	var a=1,i=1;
	user1 = document.getElementById('user1').value;
	pass1 = document.getElementById('pass1').value;
   
	while(a == 1)
	{
		if(localStorage.getItem('tenTK'+i) == null)
		{
			localStorage.setItem('tenTK'+i,user1);
			localStorage.setItem('tenTK'+'MK'+i, pass1);
			a=0;
		}
		i++;
	}
	alert("Đăng ký thành công");
}
function checkLogin()
{
	var i = 1;
	user2 = document.getElementById('user2').value;
	pass2 = document.getElementById('pass2').value;  
	while (true) 
	{
		if (localStorage.getItem('tenTK'+i) == user2 || localStorage.getItem('tenTK'+i) == null)
			break;
		i++;
	}
   

	if (localStorage.getItem('tenTK'+i) == null) 
	{
		alert ("Tài khoản này chưa được đăng ký!");
        location.reload();
		return false;
	}
    if (user2 == "") 
    {
        alert ("Vui lòng nhập tên đăng nhập");
        location.reload();
        return false;
    }

	if (localStorage.getItem ('tenTK'+'MK'+i) != pass2)
	{
		alert ("Tên tài khoản hoặc mật khẩu không chính xác!");
        location.reload();
		return false;
	}
	else
	{
		localStorage.setItem ('currentUser', user2);
		return false;
	}
}


function loggout()
{
	location.reload();
	return localStorage.removeItem('currentUser');
}
function xoaGioHang()
{
    alert("Đã xóa giỏ hàng!")
    for(i = 0; i<10; i++)
    {
        localStorage.removeItem('tenLT'+i);
        localStorage.removeItem('giaLT'+i);
        localStorage.removeItem('tenDT'+i);
        localStorage.removeItem('giaDT'+i);
        localStorage.removeItem('tenTL'+i);
        localStorage.removeItem('giaTL'+i);
        localStorage.removeItem('tenPK'+i);
        localStorage.removeItem('giaPK'+i);
    }
	location.reload();
}
function xoaGioHang2()
{
    for(i = 0; i<10; i++)
    {
        localStorage.removeItem('tenLT'+i);
        localStorage.removeItem('giaLT'+i);
        localStorage.removeItem('tenDT'+i);
        localStorage.removeItem('giaDT'+i);
        localStorage.removeItem('tenTL'+i);
        localStorage.removeItem('giaTL'+i);
        localStorage.removeItem('tenPK'+i);
        localStorage.removeItem('giaPK'+i);
    }
	location.reload();
}

function thanhToan()
{
    if(localStorage.getItem ('currentUser') != null)
    {
        alert("Cảm ơn bạn đã mua hàng!");
        location.reload();
        xoaGioHang2();
    }
    else
        alert("Vui lòng đăng nhập để mua hàng!");
}
function giohang()
{
    
        alert("Vui lòng đăng nhập để mua hàng!");
}


function signin()
{
	var a ="",b="", c="";
	if(localStorage.getItem ('currentUser') != null)
	{	
		a = localStorage.getItem ('currentUser');
		b +=`<div class="float_right">
        <button onClick="document.getElementById('id03').style.display='block'" style = "width:auto;"><img src="images/mua.png" width="50px" height="50px" /></button></div><div class="float_right"><span onClick="loggout()"><h3>Thoát</h3></span>`;
		document.getElementById("taikhoan").innerHTML = "<div class='float_right'>"+b+"</div><div class='float_right'><span><h3>Xin chào "+a+" | </h3></span></div>";
	}
	else
	{
		c += `
		<div>
        
		         <div class="float_right"><button  type="submit" onClick="giohang()"><img src="images/mua.png" width="50px" height="50px" /></button></div>

		<div class="float_right"><button onClick="document.getElementById('id02').style.display='block'" style="width:auto";><img src="images/dangky.png" height="40px" /></button></div>
        <div class="float_right"><button onClick="document.getElementById('id01').style.display='block'" style="width:auto";><img src="images/dangnhap.png" height="40px" /></button></div>

        
        </div>`;
		document.getElementById("taikhoan").innerHTML = c;
	}
}




