<?php
	session_start();
	require_once "GoogleAPI/vendor/autoload.php";
	$gClient = new Google_Client();
	$gClient->setClientId("1081826110164-f4ro4f1qc8p0arctf4iubmq2rgls07ap.apps.googleusercontent.com");
	$gClient->setClientSecret("50fDpGzSUXSvo0Sbuh5qiv1E");
	$gClient->setApplicationName("CPI Login Tutorial");
	$gClient->setRedirectUri("http://localhost/google/g-callback.php");
	$gClient->addScope("https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/userinfo.email");
?>
